<?php
ini_set('display_errors', 0); ini_set('display_startup_errors', 0);
error_reporting(E_ALL); ini_set('log_errors', 1);

session_start();
require __DIR__ . '/auth_check.php';
include 'db.php';
$conn = getDB();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {
    header("Location: login.php"); exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($csrf, $_POST['csrf_token'])) {
        header("Location: pic_criteria.php"); exit();
    }
    session_write_close();

    if ($_POST['action'] === 'add') {
        $name = trim($_POST['criteria_name']);
        if ($name) { 
            $stmt = $conn->prepare("INSERT INTO criteria (test_id, criteria_name) VALUES (?, ?)"); 
            $stmt->bind_param('is', $_POST['test_id'], $name); 
            $stmt->execute(); 
            $stmt->close(); 
        }
    }
    
    if ($_POST['action'] === 'delete') {
        $stmt = $conn->prepare("DELETE FROM criteria WHERE criteria_id=?"); 
        $stmt->bind_param('i', $_POST['criteria_id']); 
        $stmt->execute(); 
        $stmt->close();
    }
    
    if ($_POST['action'] === 'save_all' && isset($_POST['criteria'])) {
        $stmt = $conn->prepare("UPDATE criteria SET criteria_name=? WHERE criteria_id=?");
        foreach ($_POST['criteria'] as $id => $c) {
            $name = trim($c['criteria_name']); 
            $id = (int)$id;
            if ($name) { 
                $stmt->bind_param('si', $name, $id); 
                $stmt->execute(); 
            }
        }
        $stmt->close();
    }
    header("Location: pic_criteria.php"); exit();
}

session_write_close();

// ── AJAX: return sessions (sidang) list scoped to a siri ──────────────────
if (isset($_GET['ajax_sessions'])) {
    header('Content-Type: application/json');
    $siriId = (int)($_GET['siri'] ?? 0);
    $out = [];
    if ($siriId > 0) {
        $stmt = $conn->prepare("SELECT session_id, session_name FROM sessions WHERE siri_id = ? ORDER BY session_name");
        $stmt->bind_param('i', $siriId);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $out[] = $row;
        $stmt->close();
    }
    echo json_encode($out);
    exit();
}

// ── AJAX rows ─────────────────────────────────────────────────────────────
if (isset($_GET['ajax'])) {
    $search  = $_GET['search'] ?? '';
    $level   = $_GET['level']  ?? '';
    $testF   = $_GET['test']   ?? '';
    $siriF     = $_GET['siri']    ?? '';
    $sessionF  = $_GET['session'] ?? '';

    // Scope to "Siri Aktif" — both queries below (and the merged $iterArr
    // copy further down) always have "l" (levels) joined, so filter via
    // l.session_id rather than a sessions-table alias that isn't always present.
    $active_siri = (int)($_SESSION['active_siri_id'] ?? 0);

    $cWhereArr = ["1=1"]; $cTypes = ''; $cVals = [];
    if ($search !== '') { $cWhereArr[] = "c.criteria_name LIKE ?"; $cTypes .= 's'; $cVals[] = '%'.$search.'%'; }
    if ($testF  !== '') { $cWhereArr[] = "c.test_id = ?";          $cTypes .= 'i'; $cVals[] = (int)$testF;    }
    if ($level  !== '') { $cWhereArr[] = "l.level_id = ?";         $cTypes .= 'i'; $cVals[] = (int)$level;    }
    if ($sessionF !== '') { $cWhereArr[] = "l.session_id = ?";     $cTypes .= 'i'; $cVals[] = (int)$sessionF; }
    elseif ($siriF !== '') { $cWhereArr[] = "l.session_id IN (SELECT session_id FROM sessions WHERE siri_id = ?)"; $cTypes .= 'i'; $cVals[] = (int)$siriF; }
    elseif ($active_siri > 0) { $cWhereArr[] = "l.session_id IN (SELECT session_id FROM sessions WHERE siri_id = ?)"; $cTypes .= 'i'; $cVals[] = $active_siri; }

    $cWhereSql = implode(" AND ", $cWhereArr);

    $stmt = $conn->prepare("
        SELECT DISTINCT t.test_id, t.test_name, l.level_name, s.session_name, si.siri_name
        FROM criteria c
        JOIN tests t ON c.test_id=t.test_id
        JOIN levels l ON t.level_id=l.level_id
        LEFT JOIN sessions s ON l.session_id = s.session_id
        LEFT JOIN siri si ON s.siri_id = si.siri_id
        WHERE $cWhereSql
        ORDER BY l.level_name, t.test_name
    ");
    
    if ($cTypes) $stmt->bind_param($cTypes, ...$cVals);
    $stmt->execute(); 
    $tests_list = $stmt->get_result(); 
    $stmt->close();

    $found = false;

    // Fetch ALL matching criteria in one query and group by test_id, instead
    // of running a separate "criteria for this test" query per test in the
    // loop below — that used to re-hit the DB once per test row.
    $stmtAll = $conn->prepare("
        SELECT c.*
        FROM criteria c
        JOIN tests t ON c.test_id=t.test_id
        JOIN levels l ON t.level_id=l.level_id
        WHERE $cWhereSql
        ORDER BY c.test_id, c.criteria_name
    ");
    if ($cTypes) $stmtAll->bind_param($cTypes, ...$cVals);
    $stmtAll->execute();
    $allCriteriaRes = $stmtAll->get_result();
    $stmtAll->close();
    $criteriaByTest = [];
    while ($c = $allCriteriaRes->fetch_assoc()) {
        $criteriaByTest[$c['test_id']][] = $c;
    }

    while ($t = $tests_list->fetch_assoc()) {
        $tid = $t['test_id'];
        $criteriaRows = $criteriaByTest[$tid] ?? [];

        if (empty($criteriaRows)) continue;
        $found = true;
        $criteriaCount = count($criteriaRows);
        $siriLabel   = !empty($t['siri_name'])    ? htmlspecialchars($t['siri_name'])    : '— Tiada Siri —';
        $sidangLabel = !empty($t['session_name']) ? htmlspecialchars($t['session_name']) : '— Tiada Sidang —';

        echo "<div class='accordion-card'>
                <div class='level-header' onclick=\"toggleBlock('test_$tid', this)\">
                    <span class='acc-icon'>&#9658;</span>
                    <strong>" . htmlspecialchars($t['level_name']) . " – " . htmlspecialchars($t['test_name']) . "</strong>
                    <div class='header-badges'>
                        <span class='badge-siri' title='Siri'>🗓️ {$siriLabel}</span>
                        <span class='badge-sidang' title='Sidang'>📁 {$sidangLabel}</span>
                        <span class='count-badge'>{$criteriaCount} Kriteria</span>
                    </div>
                </div>
                <div id='test_$tid' class='acc-body' style='display:none;'>
                    <div class='table-responsive'>
                        <table class='tests-table'>
                            <thead>
                                <tr>
                                    <th style='width:50px; text-align:center;'>No</th>
                                    <th>Nama Kriteria</th>
                                    <th style='width:100px; text-align:center;'>Tindakan</th>
                                </tr>
                            </thead>
                            <tbody>";
        $no = 1;
        foreach ($criteriaRows as $c) {
            $cid = $c['criteria_id'];
            $safeName = htmlspecialchars($c['criteria_name'], ENT_QUOTES);

            echo "<tr data-id='$cid'>
                    <td class='col-no' style='text-align:center; color:var(--c-text-faint);'>$no</td>
                    <td><input name='criteria[$cid][criteria_name]' value='$safeName' data-orig='$safeName' class='criteria-input'></td>
                    <td class='col-actions' style='text-align:center;'>
                        <button type='button' class='pm-btn pm-btn-danger btn-sm' style='padding:5px 12px; font-size:0.78rem;' onclick=\"delRow('$cid')\">Padam</button>
                    </td>
                  </tr>";
            $no++;
        }
        echo "          </tbody>
                        </table>
                    </div>
                </div>
              </div>";
    }
    
    if (!$found) {
        echo "<p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Tiada kriteria ditemui untuk carian ini.</p>";
    }
    exit();
}

$pm_page = 'criteria';
include 'layout.php';
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<style>
    /* ── Page header ── */
    .pic-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 20px;
    }
    .pic-section-header h2 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.8rem;
        color: var(--c-white);
        letter-spacing: 0.05em;
        margin: 0;
    }
    .pic-section-sub {
        color: var(--c-text-faint);
        font-size: 0.82rem;
        margin-top: 2px;
    }

    /* ── Filter card ── */
    .filter-card{
        background:var(--c-surface-1);
        border:1px solid var(--c-border-strong);
        border-radius:12px;
        padding:20px;
        margin-bottom:24px;
        box-shadow:0 4px 12px rgba(0,0,0,.08);
    }

    .filter-card-title{
        font-size:.72rem;
        font-weight:700;
        text-transform:uppercase;
        letter-spacing:.12em;
        color:var(--c-text-faint);
        margin-bottom:16px;
    }

    .pic-filter-bar{
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(250px,1fr));
        gap:16px;
        align-items:end;
    }

    .pic-filter-bar > div{
        min-width:0;
    }

    .pic-filter-bar label{
        display:block;
        margin-bottom:6px;
        font-size:.75rem;
        font-weight:600;
        text-transform:uppercase;
        letter-spacing:.08em;
        color:var(--c-text-faint);
    }
    .pic-filter-bar input,
    .pic-filter-bar select {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-white);
        border-radius: 6px;
        padding: 8px 10px;
        font-size: 0.875rem;
        outline: none;
        width: 100%;
        transition: border-color .2s;
        box-sizing: border-box;
    }
    .pic-filter-bar input:focus,
    .pic-filter-bar select:focus { border-color: var(--c-red); }
    .pic-filter-bar select option { background: var(--c-surface-2); color: var(--c-white); }
    .pic-filter-bar input::placeholder { color: var(--c-text-faint); }

    /* ── Add card ── */
    .pic-add-card {
        display: none;
        background: var(--c-surface-1);
        border: 1px solid var(--c-red-border);
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 18px;
    }
    .pic-add-card h3 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.1rem;
        color: var(--c-white);
        margin-bottom: 14px;
        letter-spacing: 0.05em;
    }
    .pic-add-form {
        display: grid;
        grid-template-columns: 1fr 2fr auto;
        gap: 10px;
        align-items: end;
    }
    @media (max-width: 768px) {
        .pic-add-form { grid-template-columns: 1fr; }
    }
    .pic-add-form input,
    .pic-add-form select {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-white);
        border-radius: 6px;
        padding: 9px 12px;
        font-size: 0.875rem;
        outline: none;
        width: 100%;
        transition: border-color .2s;
    }
    .pic-add-form input:focus,
    .pic-add-form select:focus { border-color: var(--c-red); box-shadow: 0 0 0 3px var(--c-red-dim); }
    .pic-add-form select option { background: var(--c-surface-2); }
    .pic-add-form label {
        display: block;
        font-size: 0.75rem;
        color: var(--c-text-faint);
        margin-bottom: 4px;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.07em;
    }

    /* ── Main card & Accordions ── */
    .tests-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border-strong);
        border-radius: 10px;
        overflow: hidden;
        position: relative;
        margin-top:20px;
    }

    /* Save bar — always visible */
    .tests-save-bar {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 16px;
        background: var(--c-surface-2);
        border-bottom: 2px solid var(--c-border-strong);
        position: sticky;
        top: 0;
        z-index: 10;
        transition: border-bottom-color .25s;
    }
    .tests-save-bar.dirty { border-bottom-color: var(--c-red); }
    .tests-save-bar .save-msg { font-size: 0.82rem; color: var(--c-text-faint); flex: 1; }
    .tests-save-bar .save-msg strong { color: var(--c-white); }
    .tests-save-bar .btn-discard {
        display: none;
        padding: 5px 12px;
        background: transparent;
        color: var(--c-text-faint);
    }
    .tests-save-bar.dirty .btn-discard { display: inline-flex; }

    /* Scrollable Container */
    .tests-table-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
        scrollbar-color: var(--c-surface-3) transparent;
        padding: 12px;
    }

    /* Accordion Style */
    .accordion-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border);
        border-radius: 8px;
        margin-bottom: 8px;
        overflow: hidden;
        transition: border-color 0.2s;
    }
    .accordion-card.has-changes {
        border-color: var(--c-red);
        box-shadow: 0 0 0 1px var(--c-red);
    }
    .level-header {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 16px;
        background: var(--c-surface-2);
        cursor: pointer;
        color: var(--c-white);
        font-weight: 600;
        font-size: 0.92rem;
        transition: background .15s;
    }
    .level-header:hover { background: var(--c-surface-3); }
    .level-header .acc-icon {
        color: var(--c-text-muted);
        font-size: 0.8rem;
        transition: transform .2s ease;
        display: inline-block;
    }
    .level-header .header-badges {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap;
    }
    .level-header .count-badge {
        background: var(--c-surface-0);
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        color: var(--c-text-muted);
        border: 1px solid var(--c-border);
        white-space: nowrap;
    }
    .level-header .badge-siri,
    .level-header .badge-sidang {
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.72rem;
        font-weight: 600;
        white-space: nowrap;
        background: var(--c-surface-0);
        border: 1px solid var(--c-border);
    }
    .level-header .badge-siri {
        color: var(--c-red);
        border-color: var(--c-red-border);
    }
    .level-header .badge-sidang {
        color: var(--c-text-muted);
        border-color: var(--c-border-strong);
    }

    /* ── Table inside Accordion ── */
    .table-responsive { width: 100%; overflow-x: auto; }
    .tests-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.875rem;
        min-width: 400px;
    }
    .tests-table thead th {
        background: var(--c-surface-3);
        color: var(--c-text-muted);
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        padding: 10px 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid var(--c-border-strong);
    }
    .tests-table td {
        padding: 8px 14px;
        color: var(--c-text-muted);
        background: var(--c-surface-1);
        border-bottom: 1px solid var(--c-border);
        vertical-align: middle;
        transition: background .1s;
    }
    .tests-table tbody tr:last-child td { border-bottom: none; }
    .tests-table tbody tr:hover td { background: var(--c-surface-2); }
    .tests-table tbody tr.row-dirty td { background: rgba(214, 40, 40, 0.06) !important; }
    .tests-table td.col-no { width: 50px; }
    .tests-table td.col-actions { width: 100px; white-space: nowrap; }
    .tests-table input {
        background: var(--c-surface-0) !important;
        border: 1px solid var(--c-border-strong) !important;
        color: var(--c-white) !important;
        border-radius: 4px !important;
        padding: 5px 8px !important;
        font-size: 0.82rem !important;
        outline: none !important;
        width: 100%;
        transition: border-color .2s;
    }
    .tests-table input:focus { border-color: var(--c-red) !important; }

    #ajaxSpinner { display: none; padding: 30px; text-align: center; color: var(--c-text-faint); margin: 0; }

    /* ── PAGINATION (matches pic_view_marks.php exactly) ── */
    .vm-pagination {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 14px;
        padding: 12px 16px;
        border-top: 1px solid var(--c-border);
    }
    .vm-page-info {
        font-size: 0.8rem;
        color: var(--c-text-faint);
        font-weight: 500;
    }
    .vm-page-btns {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-wrap: wrap;
    }
    .vm-page-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 34px;
        height: 34px;
        padding: 0 10px;
        border-radius: 6px;
        font-size: 0.82rem;
        font-weight: 600;
        color: var(--c-text-muted);
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        text-decoration: none;
        cursor: pointer;
        transition: all 0.15s;
        white-space: nowrap;
    }
    .vm-page-btn:hover:not(:disabled) {
        color: #fff;
        border-color: var(--c-red);
        background: var(--c-red-dim);
    }
    .vm-page-btn.vm-page-active {
        background: var(--c-red);
        border-color: var(--c-red);
        color: #fff;
        cursor: default;
        pointer-events: none;
    }
    .vm-page-btn:disabled { opacity: 0.4; cursor: not-allowed; }
    .vm-page-ellipsis {
        display: inline-flex;
        align-items: center;
        height: 34px;
        color: var(--c-text-faint);
        font-size: 0.85rem;
        padding: 0 4px;
    }
    html.pm-light .vm-page-info { color: #6b7280; }
    html.pm-light .vm-page-btn { background: #ffffff; border-color: #d1d5db; color: #374151; }
    html.pm-light .vm-page-btn:hover:not(:disabled) { background: #fee2e2; border-color: #e2581e; color: #b91c1c; }
    html.pm-light .vm-page-btn.vm-page-active { background: #e2581e; border-color: #e2581e; color: #ffffff; }
    html.pm-light .vm-page-ellipsis { color: #9ca3af; }
    html.pm-light .vm-pagination { border-top-color: #e5e7eb; }
    @media (max-width: 640px) {
        .vm-pagination { flex-direction: column; align-items: flex-start; }
        .vm-page-btns { width: 100%; }
    }

    /* ── LIGHT MODE ── */
    html.pm-light .pic-section-header h2 { color: #111; }
    html.pm-light .pic-section-sub { color: #555; }
    html.pm-light .filter-card { background: #fff; border-color: #e5e7eb; border-top-color: var(--c-red); box-shadow: 0 1px 4px rgba(0,0,0,0.06); }
    html.pm-light .filter-card-title { color: #888; }
    html.pm-light .pic-filter-bar label { color: #555; }
    html.pm-light .pic-filter-bar input, html.pm-light .pic-filter-bar select { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .pic-filter-bar input::placeholder { color: #9ca3af; }
    html.pm-light .pic-filter-bar select option { background: #fff; color: #111; }
    html.pm-light .pic-add-card { background: #fff; border-color: var(--c-red-border); }
    html.pm-light .pic-add-card h3 { color: #111; }
    html.pm-light .pic-add-form label { color: #555; }
    html.pm-light .pic-add-form input, html.pm-light .pic-add-form select { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .pic-add-form select option { background: #fff; }
    html.pm-light .tests-card { background: #fff; border-color: #e5e7eb; }
    html.pm-light .tests-save-bar { background: #f3f4f6; border-bottom-color: #e5e7eb; }
    html.pm-light .tests-save-bar.dirty { border-bottom-color: var(--c-red); }
    html.pm-light .tests-save-bar .save-msg { color: #555; }
    html.pm-light .tests-save-bar .save-msg strong { color: #111; }
    html.pm-light .accordion-card { background: #fff; border-color: #e5e7eb; }
    html.pm-light .level-header { background: #f9fafb; color: #111; }
    html.pm-light .level-header:hover { background: #f3f4f6; }
    html.pm-light .level-header .count-badge { background: #fff; color: #555; border-color: #d1d5db; }
    html.pm-light .level-header .badge-siri { background: #fff; border-color: #fca5a5; }
    html.pm-light .level-header .badge-sidang { background: #fff; color: #555; border-color: #d1d5db; }
    html.pm-light .tests-table thead th { background: #374151; color: #f9fafb; border-bottom-color: #e5e7eb; }
    html.pm-light .tests-table td { background: #fff; color: #222; border-bottom-color: #e5e7eb; }
    html.pm-light .tests-table tbody tr:hover td { background: #f9fafb; }
    html.pm-light .tests-table tbody tr.row-dirty td { background: rgba(214, 40, 40, 0.04) !important; }
    html.pm-light .tests-table input { background: #fff !important; border-color: #d1d5db !important; color: #111 !important; }
    html.pm-light .tests-table input:focus { border-color: var(--c-red) !important; box-shadow: 0 0 0 2px var(--c-red-dim) !important; }

    /* ── Searchable dropdown ── */
    .dd-wrap { position: relative; }
    .dd-trigger{
        display:flex;
        align-items:center;
        justify-content:space-between;
        min-height:46px;
        width:100%;
        padding:0 14px;
        background:var(--c-surface-2);
        border:1px solid var(--c-border-strong);
        border-radius:8px;
        color:var(--c-white);
        font-size:.875rem;
        cursor:pointer;
        user-select:none;
        transition: border-color .2s, box-shadow .2s, background .2s;
    }
    .dd-trigger:hover { border-color:var(--c-red); }
    .dd-trigger.open { border-color:var(--c-red); box-shadow:0 0 0 3px var(--c-red-dim); }
    .dd-trigger .dd-arrow { color: var(--c-text-faint); font-size: 0.7rem; transition: transform .2s; }
    .dd-trigger.open .dd-arrow { transform: rotate(180deg); }
    
    .dd-panel {
        display:none;
        position:absolute;
        top:calc(100% + 6px);
        left:0;
        right:0;
        background:var(--c-surface-2);
        border:1px solid var(--c-red);
        border-radius:8px;
        overflow:hidden;
        z-index:999;
        box-shadow:0 10px 30px rgba(0,0,0,.25);
    }
    .dd-panel.open { display:block; }
    .dd-search-box { padding: 8px; border-bottom: 1px solid var(--c-border-strong); }
    .dd-search-box input {
        width: 100%; background: var(--c-surface-0); border: 1px solid var(--c-border-strong);
        color: var(--c-white); border-radius: 4px; padding: 6px 8px; font-size: 0.8rem;
        outline: none; box-sizing: border-box; transition: border-color .2s;
    }
    .dd-search-box input:focus { border-color: var(--c-red); }
    .dd-search-box input::placeholder { color: var(--c-text-faint); }
    .dd-options { max-height: 180px; overflow-y: auto; scrollbar-width: thin; }
    .dd-opt { padding: 9px 12px; font-size: 0.875rem; color: var(--c-white); cursor: pointer; transition: background .1s; }
    .dd-opt:hover { background: var(--c-surface-3); }
    .dd-opt.selected { color: var(--c-red); font-weight: 600; }
    .dd-opt.hidden { display: none; }
    .dd-empty { padding: 10px 12px; color: var(--c-text-faint); font-size: 0.82rem; display: none; text-align: center; }

    html.pm-light .dd-trigger { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .dd-panel { background: #fff; box-shadow: 0 6px 20px rgba(0,0,0,0.12); }
    html.pm-light .dd-search-box { border-bottom-color: #e5e7eb; }
    html.pm-light .dd-search-box input { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .dd-opt { color: #111; }
    html.pm-light .dd-opt:hover { background: #f3f4f6; }
    
    /* ── SELECT2 NATIVE THEME (Matches pic_criteria sizing) ── */
    .select2-container .select2-selection--single {
        background: var(--c-surface-2) !important;
        border: 1px solid var(--c-border-strong) !important;
        border-radius: 6px !important;
        height: 38px !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: var(--c-white) !important;
        line-height: 36px !important;
        padding-left: 10px !important;
        font-size: 0.875rem !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 36px !important;
    }
    .select2-dropdown {
        background: var(--c-surface-1) !important;
        border: 1px solid var(--c-border-strong) !important;
        border-radius: 6px !important;
        margin-top: 4px !important; /* THE GAP */
        box-shadow: 0 4px 12px rgba(0,0,0,0.2) !important;
    }
    .select2-results__option {
        color: var(--c-text) !important;
        font-size: 0.875rem !important;
    }
    .select2-results__option--highlighted {
        background: var(--c-red) !important; 
        color: #fff !important;
    }
    .select2-search__field {
        background: var(--c-surface-2) !important;
        color: var(--c-text) !important; 
        border: 1px solid var(--c-border-strong) !important;
        padding: 6px !important;
        outline: none !important;
        border-radius: 6px !important;
        font-size: 0.875rem !important;
    }
    .select2-search__field:focus {
        border-color: var(--c-red) !important;
    }

    /* ── SELECT2 LIGHT MODE OVERRIDES ── */
    html.pm-light .select2-container .select2-selection--single {
        background: #f9fafb !important; /* Pure white/light grey background */
        border-color: #d1d5db !important;
    }
    html.pm-light .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: #111 !important; /* Dark text */
    }
    html.pm-light .select2-dropdown {
        background: #ffffff !important; /* Pure white list background */
        border-color: #d1d5db !important;
        box-shadow: 0 4px 12px rgba(0,0,0,0.08) !important;
    }
    html.pm-light .select2-results__option {
        color: #111 !important;
    }
    html.pm-light .select2-search__field {
        background: #f9fafb !important;
        color: #111 !important;
        border-color: #d1d5db !important;
    }
    html.pm-light .select2-container--open .select2-selection--single,
    html.pm-light .select2-search__field:focus {
        border-color: var(--c-red) !important;
        box-shadow: 0 0 0 2px var(--c-red-dim) !important; /* Soft glow focus */
    }
</style>

<form id='saveAllForm' method='POST' style='display:none;'>
    <input type='hidden' name='action' value='save_all'>
    <input type='hidden' name='csrf_token' value='<?= htmlspecialchars($csrf) ?>'>
</form>
<form id='delFrm' method='POST' style='display:none;'>
    <input type='hidden' name='action' value='delete'>
    <input type='hidden' name='criteria_id' value=''>
    <input type='hidden' name='csrf_token' value='<?= htmlspecialchars($csrf) ?>'>
</form>

<div class='pic-section-header'>
    <div>
        <h2>📋 Pengurusan Kriteria</h2>
        <div class='pic-section-sub'>Kriteria pecahan markah bagi setiap ujian</div>
    </div>
    <button type='button' class='pm-btn pm-btn-primary' onclick="toggleAddCard()">+ Tambah Kriteria</button>
</div>

<div class="filter-card">
    <div class="filter-card-title">
        Penapis Kriteria
    </div>

    <div class="pic-filter-bar">

        <div>
            <label>Siri</label>
            <select id="f_siri" class="select-search" onchange="onSiriChange()">
                <option value="">-- Semua Siri --</option>
                <?php
                $siri_list_f = $conn->query("SELECT siri_id, siri_name FROM siri ORDER BY siri_year DESC, siri_name");
                while ($sr = $siri_list_f->fetch_assoc()) {
                    echo "<option value='{$sr['siri_id']}'>" . htmlspecialchars($sr['siri_name']) . "</option>";
                }
                ?>
            </select>
        </div>

        <div>
            <label>Sidang</label>
            <select id="f_session" class="select-search" onchange="ajaxFilter()">
                <option value="">-- Semua Sidang --</option>
            </select>
        </div>

        <div>
            <label>Peringkat</label>
            <select id="f_level" class="select-search" onchange="ajaxFilter()">
                <option value="">-- Semua Peringkat --</option>
                <?php
                // Scope to "Siri Aktif"; tag levels/tests with their siri when
                // "Semua Siri" is active so same-named levels aren't ambiguous.
                $active_siri_main = (int)($_SESSION['active_siri_id'] ?? 0);
                $lvls = $active_siri_main > 0
                    ? $conn->query("SELECT l.* FROM levels l JOIN sessions s ON l.session_id = s.session_id WHERE s.siri_id = $active_siri_main ORDER BY l.level_name")
                    : $conn->query("SELECT l.*, si.siri_name FROM levels l LEFT JOIN sessions s ON l.session_id = s.session_id LEFT JOIN siri si ON s.siri_id = si.siri_id ORDER BY l.level_name");
                while ($l = $lvls->fetch_assoc()) {
                    $optLabel = htmlspecialchars($l['level_name']);
                    if ($active_siri_main === 0 && !empty($l['siri_name'])) {
                        $optLabel .= " — " . htmlspecialchars($l['siri_name']);
                    }
                    echo "<option value='{$l['level_id']}'>$optLabel</option>";
                }
                ?>
            </select>
        </div>

        <div>
            <label>Ujian</label>
            <select id="f_test" class="select-search" onchange="ajaxFilter()">
                <option value="">-- Semua Ujian --</option>
                <?php
                $tests_all = $active_siri_main > 0
                    ? $conn->query("SELECT t.test_id, t.test_name, l.level_name FROM tests t JOIN levels l ON t.level_id=l.level_id JOIN sessions s ON l.session_id = s.session_id WHERE s.siri_id = $active_siri_main ORDER BY l.level_name, t.test_name")
                    : $conn->query("SELECT t.test_id, t.test_name, l.level_name, si.siri_name FROM tests t JOIN levels l ON t.level_id=l.level_id LEFT JOIN sessions s ON l.session_id = s.session_id LEFT JOIN siri si ON s.siri_id = si.siri_id ORDER BY l.level_name, t.test_name");
                while ($t = $tests_all->fetch_assoc()) {
                    $name = htmlspecialchars($t['level_name']) . " - " . htmlspecialchars($t['test_name']);
                    if ($active_siri_main === 0 && !empty($t['siri_name'])) {
                        $name .= " — " . htmlspecialchars($t['siri_name']);
                    }
                    echo "<option value='{$t['test_id']}'>{$name}</option>";
                }
                ?>
            </select>
        </div>

        <div>
            <label>Cari Kriteria</label>
            <select id="f_search" class="select-search" onchange="ajaxFilter()">
                <option value="">-- Semua Kriteria --</option>
                <?php
                $crit = $conn->query("SELECT DISTINCT criteria_name FROM criteria ORDER BY criteria_name");
                while ($c = $crit->fetch_assoc()) {
                    $name = htmlspecialchars($c['criteria_name']);
                    echo "<option value='{$name}'>{$name}</option>";
                }
                ?>
            </select>
        </div>

    </div>
</div>

<div id='addCriteria' class='pic-add-card'>
    <h3>+ Tambah Kriteria Baru</h3>
    <form method='POST' class='pic-add-form'>
        <input type='hidden' name='action' value='add'>
        <input type='hidden' name='csrf_token' value='<?= htmlspecialchars($csrf) ?>'>
        <div>
            <label>Ujian</label>
            <select name='test_id' class="select-search" required>
                <option value="">-- Pilih Ujian --</option>
                <?php
                $tests_all2 = $active_siri_main > 0
                    ? $conn->query("SELECT t.test_id, t.test_name, l.level_name FROM tests t JOIN levels l ON t.level_id=l.level_id JOIN sessions s ON l.session_id = s.session_id WHERE s.siri_id = $active_siri_main ORDER BY l.level_name, t.test_name")
                    : $conn->query("SELECT t.test_id, t.test_name, l.level_name, si.siri_name FROM tests t JOIN levels l ON t.level_id=l.level_id LEFT JOIN sessions s ON l.session_id = s.session_id LEFT JOIN siri si ON s.siri_id = si.siri_id ORDER BY l.level_name, t.test_name");
                while ($t = $tests_all2->fetch_assoc()) {
                    $name = htmlspecialchars($t['level_name']) . " - " . htmlspecialchars($t['test_name']);
                    if ($active_siri_main === 0 && !empty($t['siri_name'])) {
                        $name .= " — " . htmlspecialchars($t['siri_name']);
                    }
                    echo "<option value='{$t['test_id']}'>$name</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label>Nama Kriteria</label>
            <input name='criteria_name' placeholder='Contoh: Ketepatan Masa' required>
        </div>
        <div style='display:flex;align-items:flex-end;'>
            <button class='pm-btn pm-btn-primary' style="width: 100%;">Tambah Kriteria</button>
        </div>
    </form>
</div>

<div class='tests-card'>
    <div class='tests-save-bar' id='saveDirtyBar'>
        <span class='save-msg' id='saveMsg'>Tiada perubahan</span>
        <button type='button' class='pm-btn btn-sm btn-discard' onclick="discardAll()">Batal</button>
        <button type='button' class='pm-btn pm-btn-primary btn-sm' style='padding:5px 12px;' onclick="submitSaveAll()">💾 Simpan Semua</button>
    </div>

    <div class='tests-table-wrap' id='criteriaList'>
        <p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Memuatkan...</p>
    </div>
    <div id='ajaxSpinner'>⏳ Mencari...</div>

    <div class="vm-pagination" id="criteriaPaginationContainer" style="display:none;">
        <div class="vm-page-info" id="criteriaPageInfo"></div>
        <div class="vm-page-btns" id="criteriaPaginationButtons"></div>
    </div>
</div>

<script>
let _t = null;
let _dirtyRows = new Set();

function ajaxFilter() {
    clearTimeout(_t);
    _t = setTimeout(_load, 400);
}

function _load() {
    const params = new URLSearchParams({
        ajax: '1',
        search: document.getElementById('f_search').value,
        level: document.getElementById('f_level').value,
        test: document.getElementById('f_test').value,
        siri: document.getElementById('f_siri').value,
        session: document.getElementById('f_session').value
    });

    const wrapper = document.getElementById('criteriaList');
    const spinner = document.getElementById('ajaxSpinner');

    wrapper.style.display = 'none';
    spinner.style.display = 'block';

    fetch('pic_criteria.php?' + params)
        .then(r => r.text())
        .then(html => {
            wrapper.innerHTML = html;
            wrapper.style.display = 'block';
            spinner.style.display = 'none';
            _dirtyRows.clear();
            updateDirtyBar();
            attachListeners();
            criteriaCurrentPage = 1;
            updateCriteriaPagination();
        });
}

// ── PAGINATION (client-side, 20 accordions per page) ──
let criteriaCurrentPage = 1;
const criteriaPerPage = 20;

function updateCriteriaPagination() {
    const cards = Array.from(document.querySelectorAll('#criteriaList > .accordion-card'));
    const container = document.getElementById('criteriaPaginationContainer');
    const info = document.getElementById('criteriaPageInfo');
    const btns = document.getElementById('criteriaPaginationButtons');

    if (cards.length === 0) { container.style.display = 'none'; return; }

    const total = cards.length;
    const totalPages = Math.max(1, Math.ceil(total / criteriaPerPage));
    if (criteriaCurrentPage > totalPages) criteriaCurrentPage = totalPages;
    if (criteriaCurrentPage < 1) criteriaCurrentPage = 1;

    container.style.display = totalPages <= 1 ? 'none' : 'flex';

    const start = (criteriaCurrentPage - 1) * criteriaPerPage;
    const end   = start + criteriaPerPage;
    cards.forEach((c, i) => { c.style.display = (i >= start && i < end) ? '' : 'none'; });

    const s = start + 1;
    const e = Math.min(end, total);
    info.innerHTML = `Memaparkan <b>${s}–${e}</b> daripada <b>${total}</b> ujian`;

    let html = `<button class="vm-page-btn" ${criteriaCurrentPage === 1 ? 'disabled' : ''} onclick="criteriaGoToPage(${criteriaCurrentPage - 1})">&laquo;</button>`;
    let sp = Math.max(1, criteriaCurrentPage - 2);
    let ep = Math.min(totalPages, sp + 4);
    if (ep - sp < 4) sp = Math.max(1, ep - 4);
    if (sp > 1) {
        html += `<button class="vm-page-btn" onclick="criteriaGoToPage(1)">1</button>`;
        if (sp > 2) html += `<span class="vm-page-ellipsis">&hellip;</span>`;
    }
    for (let i = sp; i <= ep; i++) {
        html += `<button class="vm-page-btn ${i === criteriaCurrentPage ? 'vm-page-active' : ''}" onclick="criteriaGoToPage(${i})">${i}</button>`;
    }
    if (ep < totalPages) {
        if (ep < totalPages - 1) html += `<span class="vm-page-ellipsis">&hellip;</span>`;
        html += `<button class="vm-page-btn" onclick="criteriaGoToPage(${totalPages})">${totalPages}</button>`;
    }
    html += `<button class="vm-page-btn" ${criteriaCurrentPage === totalPages ? 'disabled' : ''} onclick="criteriaGoToPage(${criteriaCurrentPage + 1})">&raquo;</button>`;
    btns.innerHTML = html;
}

function criteriaGoToPage(page) {
    criteriaCurrentPage = page;
    updateCriteriaPagination();
}

function attachListeners() {
    document.querySelectorAll('.criteria-input').forEach(el => {
        if (el.dataset.listening) return;
        el.dataset.listening = '1';
        el.addEventListener('input', onInputChange);
    });
}

function onInputChange(e) {
    const row = e.target.closest('tr');
    if (!row) return;
    const id = row.dataset.id;
    const orig = e.target.dataset.orig ?? '';
    const accCard = e.target.closest('.accordion-card');

    if (e.target.value !== orig) {
        _dirtyRows.add(id);
        row.classList.add('row-dirty');
        if(accCard) accCard.classList.add('has-changes');
    } else {
        _dirtyRows.delete(id);
        row.classList.remove('row-dirty');
        if(accCard && accCard.querySelectorAll('.row-dirty').length === 0) {
            accCard.classList.remove('has-changes');
        }
    }
    updateDirtyBar();
}

function updateDirtyBar() {
    const bar = document.getElementById('saveDirtyBar');
    const msg = document.getElementById('saveMsg');
    bar.classList.toggle('dirty', _dirtyRows.size > 0);
    msg.innerHTML = _dirtyRows.size > 0
        ? `Ada <strong>${_dirtyRows.size}</strong> perubahan belum disimpan`
        : 'Tiada perubahan';
}

function submitSaveAll() {
    const form = document.getElementById('saveAllForm');
    form.querySelectorAll('.dyn-input').forEach(el => el.remove());
    document.querySelectorAll('.criteria-input').forEach(el => {
        const h = document.createElement('input');
        h.type = 'hidden';
        h.name = el.name;
        h.value = el.value;
        h.className = 'dyn-input';
        form.appendChild(h);
    });
    form.submit();
}

function discardAll() {
    document.querySelectorAll('.criteria-input').forEach(el => {
        if (el.dataset.orig !== undefined) el.value = el.dataset.orig;
        el.closest('tr')?.classList.remove('row-dirty');
    });
    document.querySelectorAll('.accordion-card').forEach(acc => {
        acc.classList.remove('has-changes');
    });
    _dirtyRows.clear();
    updateDirtyBar();
}

function delRow(id) {
    if (!confirm('Padam kriteria ini?')) return;
    document.getElementById('delFrm').querySelector('[name=criteria_id]').value = id;
    document.getElementById('delFrm').submit();
}

function toggleAddCard() {
    const el = document.getElementById('addCriteria');
    el.style.display = (el.style.display === 'block') ? 'none' : 'block';
}

function toggleBlock(id, headerEl) {
    const bodyEl = document.getElementById(id);
    const iconEl = headerEl.querySelector('.acc-icon');
    if (bodyEl) {
        if (bodyEl.style.display === 'none' || bodyEl.style.display === '') {
            bodyEl.style.display = 'block';
            if (iconEl) iconEl.style.transform = 'rotate(90deg)';
        } else {
            bodyEl.style.display = 'none';
            if (iconEl) iconEl.style.transform = 'rotate(0deg)';
        }
    }
}

// Custom Dropdown Functions
function ddToggle(name) {
    const panel = document.getElementById('ddPanel_' + name);
    const trigger = document.getElementById('ddTrigger_' + name);
    const isOpen = panel.classList.contains('open');
    document.querySelectorAll('.dd-panel.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.dd-trigger.open').forEach(t => t.classList.remove('open'));
    if (!isOpen) {
        panel.classList.add('open'); trigger.classList.add('open');
        setTimeout(() => panel.querySelector('.dd-search-box input')?.focus(), 50);
    }
}

function ddFilter(name, val) {
    const opts = document.querySelectorAll('#ddOpts_' + name + ' .dd-opt');
    const empty = document.getElementById('ddEmpty_' + name);
    let any = false;
    opts.forEach(o => { 
        const m = o.textContent.toLowerCase().includes(val.toLowerCase()); 
        o.classList.toggle('hidden', !m); 
        if(m) any = true; 
    });
    if(empty) empty.style.display = any ? 'none' : 'block';
}

function ddSelect(name, value, label) {
    if (name === 'level' || name === 'test') {
        document.getElementById('f_' + name).value = value;
    }
    const lbl = document.getElementById('ddLabel_' + name);
    lbl.textContent = label;
    lbl.style.color = value === '' ? 'var(--c-text-faint)' : '';
    document.querySelectorAll('#ddOpts_' + name + ' .dd-opt').forEach(o => o.classList.toggle('selected', o.dataset.value === value));
    document.getElementById('ddPanel_' + name).classList.remove('open');
    document.getElementById('ddTrigger_' + name).classList.remove('open');
    ajaxFilter();
}

function onSiriChange() {
    const siriId = document.getElementById('f_siri').value;
    const sessSel = $('#f_session');
    sessSel.empty().append('<option value="">-- Semua Sidang --</option>');
    if (!siriId) { sessSel.trigger('change'); ajaxFilter(); return; }
    fetch('pic_criteria.php?ajax_sessions=1&siri=' + encodeURIComponent(siriId))
        .then(r => r.json())
        .then(list => {
            list.forEach(s => sessSel.append(new Option(s.session_name, s.session_id)));
            sessSel.trigger('change');
            ajaxFilter();
        });
}

function ddSearchInput(val) {
    const lbl = document.getElementById('ddLabel_search');
    lbl.textContent = val || '-- Semua Kriteria --';
    lbl.style.color = val ? '' : 'var(--c-text-faint)';
    ajaxFilter();
}

document.addEventListener('click', e => {
    if (!e.target.closest('.dd-wrap')) {
        document.querySelectorAll('.dd-panel.open').forEach(p => p.classList.remove('open'));
        document.querySelectorAll('.dd-trigger.open').forEach(t => t.classList.remove('open'));
    }
});

$(document).ready(function() {
    
    // Custom Matcher: Ensures the empty/default option is always visible during search
    function alwaysShowAll(params, data) {
        // If there's no search term, return all data
        if ($.trim(params.term) === '') {
            return data;
        }
        // If this is the "Semua" option (value is empty string), NEVER hide it
        if (data.id === '') {
            return data;
        }
        // Otherwise, do the standard text matching
        if (data.text.toLowerCase().indexOf(params.term.toLowerCase()) > -1) {
            return data;
        }
        // No match
        return null;
    }

    // Initialize Select2 with the custom matcher
    $('.select-search').select2({
        width: '100%',
        matcher: alwaysShowAll
    });

    // Bind Select2 changes to your ajaxFilter function for ALL filters
    $('#f_level, #f_test, #f_search, #f_session').on('select2:select', function (e) {
        ajaxFilter();
    });
});

document.addEventListener('DOMContentLoaded', _load);
</script>

</main>
</body>
</html>