<?php
ini_set("display_errors", 0);
error_reporting(E_ALL);
ini_set("log_errors", 1);

session_start();
require __DIR__ . '/auth_check.php';
date_default_timezone_set("Asia/Kuala_Lumpur");

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'judge') {
    header("Location: login.php");
    exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

include "db.php";
$conn = getDB();

// ── AJAX ENDPOINTS FOR ADDING NEW UJIAN/KRITERIA ──
// ── ajax_add_parameter is now a NO-OP — parameter inserts happen only
//    inside save_scores.php when the judge actually submits marks.
//    We keep this endpoint so old JS calls don't 404, but it returns
//    immediately without touching the database.
if (isset($_POST["ajax_add_parameter"])) {
    header("Content-Type: application/json");
    echo json_encode(["status" => "deferred"]);
    exit();
}

$judge_id = (int) $_SESSION["user_id"];
$stmt = $conn->prepare("SELECT name FROM judges WHERE id = ?");
$stmt->bind_param("i", $judge_id);
$stmt->execute();
$judge_name = $stmt->get_result()->fetch_assoc()["name"] ?? "Judge";
$stmt->close();

// ── INTERNAL AJAX ENDPOINTS FOR FORM DROPDOWNS ──
if (isset($_GET["ajax_levels"])) {
    $sid = (int) $_GET["session_id"];
    $stmt = $conn->prepare(
        "SELECT * FROM levels WHERE session_id = ? ORDER BY level_name ASC",
    );
    if ($stmt) {
        $stmt->bind_param("i", $sid);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($r = $result->fetch_assoc()) {
            echo "<option value='{$r["level_id"]}'>" .
                htmlspecialchars($r["level_name"]) .
                "</option>";
        }
        $stmt->close();
    }
    exit();
}

if (isset($_GET["ajax_groups"])) {
    $lid = (int) $_GET["level_id"];
    $stmt = $conn->prepare(
        "SELECT group_id, group_name, judge_id FROM `groups` WHERE level_id = ? ORDER BY group_name ASC"
    );
    if ($stmt) {
        $stmt->bind_param("i", $lid);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($r = $result->fetch_assoc()) {
            $unassigned = empty($r["judge_id"]) ? "1" : "0";
            $ownedByMe  = (!empty($r["judge_id"]) && (int)$r["judge_id"] === $judge_id) ? "1" : "0";
            $label = htmlspecialchars($r["group_name"]);
            if ($unassigned === "1") $label .= " ⚠ (Belum Ditetapkan)";
            echo "<option value='{$r["group_id"]}' data-unassigned='{$unassigned}' data-own='{$ownedByMe}'>{$label}</option>";
        }
        $stmt->close();
    }
    exit();
}

// ── AJAX: Modal cascade — tests for a level ──
if (isset($_GET["ajax_modal_tests"])) {
    $lid = (int) $_GET["level_id"];
    $stmt = $conn->prepare(
        "SELECT test_id, test_name FROM tests WHERE level_id = ? ORDER BY test_name ASC",
    );
    if ($stmt) {
        $stmt->bind_param("i", $lid);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows = [];
        while ($r = $result->fetch_assoc()) {
            $rows[] = ["id" => $r["test_id"], "name" => $r["test_name"]];
        }
        $stmt->close();
        header("Content-Type: application/json");
        echo json_encode($rows);
    }
    exit();
}

// ── AJAX: Modal cascade — criteria for a test ──
if (isset($_GET["ajax_modal_criteria"])) {
    $tid = (int) $_GET["test_id"];
    $stmt = $conn->prepare(
        "SELECT criteria_id, criteria_name FROM criteria WHERE test_id = ? ORDER BY criteria_name ASC",
    );
    if ($stmt) {
        $stmt->bind_param("i", $tid);
        $stmt->execute();
        $result = $stmt->get_result();
        $rows = [];
        while ($r = $result->fetch_assoc()) {
            $rows[] = ["id" => $r["criteria_id"], "name" => $r["criteria_name"]];
        }
        $stmt->close();
        header("Content-Type: application/json");
        echo json_encode($rows);
    }
    exit();
}

// ── AJAX: Sessions filtered by siri_id ──
if (isset($_GET['ajax_sessions'])) {
    $sid = (int) $_GET['siri_id'];
    $stmt = $conn->prepare(
        "SELECT session_id, session_name FROM sessions WHERE siri_id = ? ORDER BY session_name ASC"
    );
    if ($stmt) {
        $stmt->bind_param("i", $sid);
        $stmt->execute();
        $result = $stmt->get_result();
        while ($r = $result->fetch_assoc()) {
            echo "<option value='{$r["session_id"]}'>" . htmlspecialchars($r["session_name"]) . "</option>";
        }
        $stmt->close();
    }
    exit();
}

$current_session = $_POST["session_id"] ?? null;
$current_level = $_POST["level_id"] ?? null;
$current_group = $_POST["group_id"] ?? null;
$marking_active = !empty($_POST["start_marking"]);

$session_label = "-";
$group_label = "-";
if ($current_session) {
    $stmt = $conn->prepare(
        "SELECT session_name FROM sessions WHERE session_id = ?",
    );
    if ($stmt) {
        $stmt->bind_param("i", $current_session);
        $stmt->execute();
        $session_label =
            $stmt->get_result()->fetch_assoc()["session_name"] ?? "-";
        $stmt->close();
    }
}
if ($current_group) {
    $stmt = $conn->prepare(
        "SELECT group_name FROM `groups` WHERE group_id = ?",
    );
    if ($stmt) {
        $stmt->bind_param("i", $current_group);
        $stmt->execute();
        $group_label = $stmt->get_result()->fetch_assoc()["group_name"] ?? "-";
        $stmt->close();
    }
}

$pm_page = "judge";
$_SESSION["judge_name"] = $judge_name;

// ── SIRI / YEAR CASCADE LOGIC ──
// Moved above the stats query below so the identity-card numbers can be
// scoped to the siri the judge currently has selected, instead of summing
// groups across every siri the judge has ever been assigned to.
$all_siri = [];
$siri_res = $conn->query("SELECT siri_id, siri_name, siri_year FROM siri ORDER BY siri_year DESC, siri_name ASC");
while ($sr = $siri_res->fetch_assoc()) {
    $all_siri[] = $sr;
}

// Distinct years from siri table
$all_years = array_unique(array_column($all_siri, 'siri_year'));
rsort($all_years);

$show_year_dropdown = count($all_years) > 1;
$show_siri_dropdown = count($all_siri) > 1;

// Determine active siri_id for session filtering
// Priority: POST (user just selected) > session > auto (only one siri)
$current_siri_id = null;
if (isset($_POST['siri_id']) && is_numeric($_POST['siri_id'])) {
    $current_siri_id = (int) $_POST['siri_id'];
} elseif (isset($_POST['start_marking']) && isset($_POST['siri_id'])) {
    $current_siri_id = (int) $_POST['siri_id'];
}

// If only one siri exists, auto-select it
if (!$current_siri_id && count($all_siri) === 1) {
    $current_siri_id = (int) $all_siri[0]['siri_id'];
}

$current_year = null;
if ($current_siri_id) {
    foreach ($all_siri as $sr) {
        if ($sr['siri_id'] === $current_siri_id) {
            $current_year = $sr['siri_year'];
            break;
        }
    }
}

// ── JUDGE STATS FOR IDENTITY CARD — scoped to the selected siri ──
$stat_total = 0;
$stat_done = 0;
$stat_pending = 0;
$statsSql = "
    SELECT
        COUNT(DISTINCT g.group_id) AS total_groups,
        SUM(CASE WHEN EXISTS (
            SELECT 1 FROM scores sc2 WHERE sc2.group_id = g.group_id AND sc2.submitted = 1 LIMIT 1
        ) THEN 1 ELSE 0 END) AS done_groups
    FROM `groups` g
    WHERE g.judge_id = ?
";
if ($current_siri_id) {
    $statsSql .= " AND g.level_id IN (SELECT level_id FROM levels WHERE session_id IN (SELECT session_id FROM sessions WHERE siri_id = ?))";
}
$sqStats = $conn->prepare($statsSql);
if ($sqStats) {
    if ($current_siri_id) {
        $sqStats->bind_param("ii", $judge_id, $current_siri_id);
    } else {
        $sqStats->bind_param("i", $judge_id);
    }
    $sqStats->execute();
    $statRow = $sqStats->get_result()->fetch_assoc();
    $sqStats->close();
    $stat_total = (int) ($statRow["total_groups"] ?? 0);
    $stat_done = (int) ($statRow["done_groups"] ?? 0);
    $stat_pending = $stat_total - $stat_done;
}
$stat_pct = $stat_total > 0 ? round(($stat_done / $stat_total) * 100) : 0;

include "layout.php";
?>

<style>
    /* ─────────────────────────────────────────────────
       JUDGE PAGE — REDESIGN
       Philosophy: scorecard, not dashboard.
       One accent colour, used only for meaning.
       Cards are ledger surfaces, not chrome.
    ───────────────────────────────────────────────── */

    /* Light mode token overrides */
    html.pm-light {
        --c-surface-0:    #f0f0f0;
        --c-surface-1:    #ffffff;
        --c-surface-2:    #f5f5f5;
        --c-surface-3:    #ebebeb;
        --c-red:          #b30000;
        --c-red-dark:     #800000;
        --c-red-dim:      rgba(179,0,0,0.08);
        --c-red-border:   rgba(179,0,0,0.25);
        --c-text:         #111111;
        --c-text-muted:   #555555;
        --c-border:       #e0e0e0;
        --c-border-strong:#cccccc;
    }

    /* ── Toast / alert colour tokens ── */
    .pm-toast-success, .pm-lock-alert {
        background: rgba(16,185,129,0.1);
        border-left: 3px solid #10B981;
        color: #059669;
    }
    .pm-toast-danger {
        background: rgba(239,68,68,0.1);
        border-left: 3px solid #EF4444;
        color: #DC2626;
    }
    html.pm-light .pm-toast-success,
    html.pm-light .pm-lock-alert {
        background: rgba(16,185,129,0.12);
        border-left: 3px solid #059669;
        color: #065F46;
    }
    html.pm-light .pm-toast-danger {
        background: rgba(239,68,68,0.12);
        border-left: 3px solid #DC2626;
        color: #991B1B;
    }

    /* ── Page heading ── */
    .pm-page-heading {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.5rem;
        letter-spacing: 0.08em;
        color: var(--c-text);
        margin-bottom: 20px;
        padding-bottom: 10px;
        border-bottom: 1px solid var(--c-border);
    }

    /* ── Section card — minimal frame ── */
    .judge-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border);
        border-radius: 6px;
        padding: 20px 24px;
        margin-bottom: 16px;
        color: var(--c-text);
    }

    .judge-card h3.pm-card-title {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1rem;
        letter-spacing: 0.12em;
        color: var(--c-text-muted);
        text-transform: uppercase;
        margin-bottom: 16px;
        padding-bottom: 8px;
        border-bottom: 2px solid var(--c-red);
        display: inline-block;
    }

    /* ── Top dashboard row ── */
    .top-dashboard-row {
        display: grid;
        grid-template-columns: 1fr 2fr;  /* was: 260px 1fr */
        gap: 16px;
        margin-bottom: 16px;
        align-items: stretch;
    }
    
    @media (max-width: 860px) {
        .top-dashboard-row { grid-template-columns: 1fr; }
    }

    .identity-col, .summary-col {
        display: flex;
        flex-direction: column;
    }
    
    .identity-col .judge-card,
    .summary-col .judge-card {
        margin-bottom: 0;
        flex-grow: 1;
        height: 100%;
        box-sizing: border-box;
    }

    /* ── Identity card ── */
    .judge-identity-card {
        border-left: none;
        padding-left: 20px;
    }

    .identity-top {
        font-size: 0.65rem;
        font-weight: 700;
        letter-spacing: 0.15em;
        text-transform: uppercase;
        color: var(--c-text-muted);
    }

    .identity-name {
        font-size: 1.4rem;
        font-weight: 700;
        color: var(--c-text);
        margin: 4px 0 12px;
        line-height: 1.2;
    }

    .identity-meta {
        display: grid;
        grid-template-columns: auto 1fr;
        gap: 4px 16px;
        font-size: 0.8rem;
    }
    .identity-meta span { color: var(--c-text-muted); }
    .identity-meta b    { color: var(--c-text); font-weight: 500; }

    .identity-divider {
        border: none;
        border-top: 1px solid var(--c-border);
        margin: 14px 0;
    }

    /* Stat row — numbers only, no boxes */
    /* ── Stat row ── */
    .identity-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 0;
        border: 1px solid var(--c-border);
        border-radius: 4px;
        overflow: hidden;
        margin-top: 14px;   /* consistent with divider spacing */
    }
    
    .identity-stat-box {
        padding: 10px 8px;
        text-align: center;
        border-right: 1px solid var(--c-border);
        background: var(--c-surface-2);
    }
    .identity-stat-box:last-child { border-right: none; }
    
    .identity-stat-box .stat-val {
        font-family: 'DM Mono', monospace;
        font-size: 1.3rem;
        font-weight: 600;
        line-height: 1;
        display: block;
    }
    .identity-stat-box:nth-child(1) .stat-val { color: var(--c-text); }
    .identity-stat-box:nth-child(2) .stat-val { color: #16a34a; }
    .identity-stat-box:nth-child(3) .stat-val { color: var(--c-red); }
    
    .identity-stat-box .stat-label {
        font-size: 0.58rem;
        color: var(--c-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.08em;
        margin-top: 4px;
        display: block;
        line-height: 1.3;
    }

    /* Progress bar */
    .identity-progress-wrap { margin-top: 12px; }
    .identity-progress-label {
        display: flex;
        justify-content: space-between;
        font-size: 0.72rem;
        color: var(--c-text-muted);
        margin-bottom: 5px;
    }
    .identity-progress-bar {
        height: 3px;
        background: var(--c-border);
        border-radius: 99px;
        overflow: hidden;
    }
    .identity-progress-fill {
        height: 100%;
        background: var(--c-red);
        border-radius: 99px;
        transition: width 0.5s ease;
    }

    /* ── Accordion summary & Search ── */
    .summary-search-wrap { 
        position: relative;
        margin-bottom: 16px; 
    }
    .summary-search-wrap::before {
        content: '🔍';
        position: absolute;
        left: 12px;
        top: 50%;
        transform: translateY(-50%);
        font-size: 0.85rem;
        color: var(--c-text-muted);
        pointer-events: none;
        opacity: 0.6;
    }
    .summary-search-wrap input {
        width: 100%;
        background: var(--c-surface-1);
        border: 1px solid var(--c-border);
        border-radius: 6px;
        padding: 10px 14px 10px 38px; /* Extra left padding for the icon */
        color: var(--c-text);
        font-size: 0.85rem;
        outline: none;
        transition: all 0.2s ease;
        box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        box-sizing: border-box;
    }
    .summary-search-wrap input:focus {
        border-color: var(--c-red);
        box-shadow: 0 0 0 3px var(--c-red-dim);
    }
    .summary-search-wrap input::placeholder {
        color: var(--c-text-muted);
        opacity: 0.7;
    }

    .pm-accordion-container {
        min-height: 60px;
        max-height: 380px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
        scrollbar-color: var(--c-border-strong) transparent;
        padding-right: 4px;
    }
    .pm-accordion-container::-webkit-scrollbar { width: 4px; }
    .pm-accordion-container::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 4px;
    }

    .pm-accordion-block {
        border: 1px solid var(--c-border);
        border-radius: 6px;
        margin-bottom: 8px;
        overflow: visible;
        background: var(--c-surface-1);
        transition: box-shadow 0.2s ease;
    }
    .pm-accordion-block:hover {
        box-shadow: 0 2px 8px rgba(0,0,0,0.04);
    }
    .pm-accordion-block .pm-table-wrap {
        min-height: unset !important;
        padding-bottom: 0 !important;
        border: none;
        border-top: 1px solid var(--c-border);
        border-radius: 0 0 6px 6px;
    }

    /* Upgraded Header Layout */
    .pm-accordion-header {
        position: sticky;
        top: 0;
        z-index: 20;
        background: var(--c-surface-2);
        padding: 12px 16px;
        display: flex;
        align-items: center;
        justify-content: space-between; /* Pushes count badge to the right */
        cursor: pointer;
        border-bottom: 1px solid transparent;
        border-radius: 6px;
        transition: background 0.15s;
    }
    .pm-accordion-header:hover { background: var(--c-surface-3); }
    .pm-accordion-header.active {
        background: var(--c-surface-2);
        border-bottom: 1px solid var(--c-border);
        border-radius: 6px 6px 0 0;
    }

    .pm-accordion-header-left {
        display: flex;
        align-items: center;
        gap: 12px;
    }

    .pm-accordion-arrow {
        font-size: 0.65rem;
        color: var(--c-text-muted);
        transition: transform 0.2s ease;
    }
    .pm-accordion-header.active .pm-accordion-arrow {
        color: var(--c-red);
    }

    /* New Badges */
    /* New Badges */
    .pm-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px; /* Space between dot and text */
        font-size: 0.65rem;
        font-weight: 700;
        text-transform: uppercase;
        padding: 4px 8px;
        border-radius: 4px;
        letter-spacing: 0.05em;
    }
    .pm-badge-year {
        background: var(--c-surface-1);
        color: var(--c-text-muted);
        border: 1px solid var(--c-border-strong);
    }
    /* Generates the grey dot inside the Year badge */
    .pm-badge-year::before {
        content: '';
        display: inline-block;
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: var(--c-text-muted);
    }
    .pm-badge-siri {
        background: var(--c-red-dim);
        color: var(--c-red);
        border: 1px solid var(--c-red-border);
    }
    /* Generates the red dot inside the Siri badge */
    .pm-badge-siri::before {
        content: '';
        display: inline-block;
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: var(--c-red);
    }
    .pm-accordion-title {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--c-text);
    }
    .pm-count-badge {
        font-size: 0.72rem;
        font-weight: 600;
        color: var(--c-text-muted);
        background: var(--c-surface-1);
        border: 1px solid var(--c-border);
        padding: 4px 12px;
        border-radius: 99px; /* Perfect pill shape */
        box-shadow: 0 1px 2px rgba(0,0,0,0.02); /* Slight shadow for depth */
    }

    /* ── Base table ── */
    .pm-table-wrap {
        background: var(--c-surface-1);
        border-radius: 0 0 6px 6px;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        min-height: unset;
    }
    .student-list-wrap {
        min-height: unset !important;
        padding-bottom: 0 !important;
        border: 1px solid var(--c-border);
        border-radius: 4px;
    }
    .pm-table-wrap::-webkit-scrollbar { height: 4px; }
    .pm-table-wrap::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 2px;
    }

    .pm-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 600px; /* Slightly wider to accommodate spacious rows */
    }
    .pm-table th {
        background: #f8f9fa; /* Very subtle light grey for the header like the screenshot */
        color: var(--c-text-muted);
        border-bottom: 1px solid var(--c-border);
        padding: 10px 16px; /* More breathing room */
        text-align: left;
        white-space: nowrap;
        font-size: 0.65rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em; /* Wider tracking for that modern look */
    }
    .pm-table td {
        color: var(--c-text);
        border-bottom: 1px solid var(--c-border);
        padding: 16px 16px; /* Spacious vertical padding */
        font-size: 0.85rem;
        vertical-align: middle;
    }
    .pm-table tr:hover td { background: var(--c-surface-2); }
    
    /* Remove bottom border on the very last row so it doesn't double up with the container border */
    .pm-accordion-content .pm-table tbody tr:last-child td {
        border-bottom: none; 
    }
    
    /* Make the active header background slightly distinct to match the open state */
    .pm-accordion-header.active {
        background: #fafafa;
        border-bottom: 1px solid var(--c-border);
        border-radius: 6px 6px 0 0;
    }
    
    /* Fix Arrow centering during rotation */
    .pm-accordion-arrow {
        display: inline-block;
        font-size: 0.55rem;
        color: var(--c-text-muted);
        transition: transform 0.2s ease, color 0.2s ease;
        transform-origin: center;
    }

    /* ── Select2 theme ── */
    .select2-container .select2-selection--single {
        background: var(--c-surface-2) !important;
        border: 1px solid var(--c-border-strong) !important;
        border-radius: 4px !important;
        height: 38px !important;
    }
    .select2-container--open .select2-selection--single {
        border-color: var(--c-red) !important;
        box-shadow: none !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: var(--c-text) !important;
        line-height: 36px !important;
        font-size: 0.82rem !important;
        padding-left: 10px !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 36px !important;
        right: 8px !important;
    }
    .select2-dropdown {
        background: var(--c-surface-1) !important;
        border: 1px solid var(--c-border-strong) !important;
        border-radius: 4px !important;
        box-shadow: 0 4px 16px rgba(0,0,0,0.12) !important;
    }
    .select2-results__option {
        padding: 8px 12px !important;
        font-size: 0.82rem !important;
        color: var(--c-text) !important;
    }
    .select2-container--default .select2-results__option--highlighted[aria-selected] {
        background-color: var(--c-surface-3) !important;
        color: var(--c-text) !important;
    }
    .select2-container--default .select2-results__option[aria-selected="true"] {
        background-color: var(--c-red) !important;
        color: #fff !important;
        font-weight: 600;
    }
    .form-btn-submit {
        height: 38px !important;
        padding: 0 18px !important;
        font-size: 0.82rem !important;
    }

    /* ── Marking table (desktop only — see #desktopMarkingTable below) ── */
    .marking-table { min-width: 900px; }
    .marking-table th {
        text-align: center !important;
        vertical-align: middle !important;
        padding: 7px 6px !important;
    }
    .sticky-col {
        position: sticky !important;
        left: 0;
        z-index: 10 !important;
        background: var(--c-surface-1) !important;
        color: var(--c-text) !important;
        border-right: 1px solid var(--c-border-strong) !important;
        box-shadow: 2px 0 8px rgba(0,0,0,0.06);
        min-width: 160px;
        width: 200px;
        white-space: normal;
    }
    th.sticky-col {
        background: var(--c-surface-2) !important;
        z-index: 12 !important;
    }
    .marking-table tr:nth-child(even) td.sticky-col {
        background: var(--c-surface-2) !important;
    }
    .mark-cell {
        min-width: 160px;
        vertical-align: top !important;
        padding: 8px 5px !important;
    }

    /* ── Desktop table vs. mobile/tablet ribbon: exactly one is shown.
       Breakpoint matches the rest of this page's tablet cutoff (860px used
       by .top-dashboard-row above) bumped slightly since a marking grid
       needs more room before a table stops being viable — 1024px covers
       phones and tablets (portrait AND landscape), leaving only genuine
       desktop widths on the wide table. The actual DOM nodes (checkbox +
       keypad + hidden input) are NOT duplicated between the two layouts —
       JS physically relocates the single live node into whichever
       container is visible, so there's only ever one source of truth. ── */
    #desktopMarkingTable { display: block; }
    #mobileMarkingUI { display: none; }
    @media (max-width: 1024px) {
        #desktopMarkingTable { display: none !important; }
        #mobileMarkingUI { display: block !important; }

        /* ── Center and stack summary pills ── */
        .marking-summary {
            display: flex !important;
            flex-direction: column !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 10px !important;
            padding: 14px 16px !important;
        }
        .summary-pill {
            width: 100% !important;
            max-width: 600px !important;
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            padding: 10px 18px !important;
            box-sizing: border-box !important;
            margin: 0 auto !important;
        }
        .summary-pill-name {
            text-align: left;
            white-space: normal;
            line-height: 1.3;
            padding-right: 12px;
            flex: 1;
        }
        .summary-pill .overall-total {
            flex-shrink: 0;
        }

        /* ── Tabs as independent rounded chips, not a seamless segmented
           control ── A shared-border segmented control (each tab's radius
           patched per position) looks fine for exactly one row, but the
           moment it wraps, the second row reads as a disconnected floating
           piece no matter how the seam is patched — the wrap boundary IS
           a visual break. Giving every tab its own full rounded corners +
           consistent gap sidesteps that entirely: it wraps to any number
           of rows and still looks like one coherent, deliberate group. */
        .ujian-tabs {
            display: grid !important;
            grid-template-columns: repeat(2, minmax(0, 1fr)) !important;
            justify-content: center !important;
            gap: 8px !important;
            max-width: 600px;
            margin: 0 auto;
            padding: 12px 16px !important;
        }
        .ujian-tab-btn {
            max-width: none !important;
            width: 100% !important;
            text-align: center !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 8px !important;
            box-shadow: 0 1px 2px rgba(0,0,0,0.05);
        }
        .ujian-tab-btn.active {
            box-shadow: 0 2px 6px rgba(214,40,40,0.25);
        }
        /* An odd tab out (no partner in its row) spans both columns instead
           of sitting centered at half-width. */
        .ujian-tab-btn:last-child:nth-child(odd) {
            grid-column: 1 / -1 !important;
        }

        /* ── Center Accordion Cards and Labels to match the column ── */
        .student-mark-card {
            width: 100% !important;
            max-width: 600px !important;
            margin: 0 auto 14px auto !important; /* Centers the card horizontally */
        }
        .criteria-row-label {
            text-align: center !important;
        }
    }

    /* ── Ujian ribbon (tabs) + vertical marking cards — mobile/tablet only.
       Deliberately has NO horizontal scroll anywhere: the tab row wraps
       onto new lines instead of scrolling sideways, and every panel stacks
       students top-to-bottom. This is specifically to stop fat-finger
       mis-taps that happened when judges had to scroll right across a
       dense grid to reach a student/criteria. */
    /* Wraps .marking-summary + .ujian-tabs so both stick together as one
       unit right below the site header — a single sticky container instead
       of two independently-sticky elements, which avoids needing to
       measure either one's height in JS to stack them correctly. */
    .sticky-marking-header {
        position: sticky;
        /* The site header is position:fixed at top:0 with height var(--header-h)
           and z-index:200 — stick right below it, not underneath it. */
        top: var(--header-h, 64px);
        z-index: 50;
        background: var(--c-surface-2);
    }
    .marking-summary {
        display: flex;
        flex-wrap: wrap;
        gap: 8px;
        padding: 14px 16px;
        background: var(--c-surface-2);
        border-bottom: 1px solid var(--c-border);
    }
    .summary-pill {
        appearance: none;
        -webkit-appearance: none;
        display: flex;
        align-items: center;
        gap: 8px;
        background: var(--c-surface-1);
        border: 1px solid var(--c-border-strong);
        border-radius: 99px;
        padding: 5px 12px;
        font-size: 0.78rem;
        cursor: pointer;
        box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        font-family: inherit;
        touch-action: manipulation;
        transition: border-color 0.15s, background 0.15s;
    }
    .summary-pill:hover { background: var(--c-surface-3); border-color: var(--c-red); }
    .summary-pill:active { transform: scale(0.97); }
    .summary-pill-name { color: var(--c-text-muted); font-weight: 600; }
    .summary-pill .overall-total { color: var(--c-red); font-weight: 700; font-family: 'DM Mono', monospace; }

    /* Brief highlight when a summary pill jumps the judge to a student card */
    .student-mark-card.flash-highlight {
        animation: flashHighlight 1.1s ease;
    }
    @keyframes flashHighlight {
        0%   { box-shadow: 0 0 0 3px var(--c-red); }
        100% { box-shadow: 0 0 0 0 transparent; }
    }

    .ujian-tabs {
        display: flex;
        flex-wrap: wrap;
        gap: 6px;
        padding: 12px 16px;
        background: var(--c-surface-2);
        border-bottom: 1px solid var(--c-border);
    }
    .ujian-tab-btn {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border-strong);
        border-bottom-width: 3px;
        color: var(--c-text-muted);
        font-weight: 700;
        font-size: 0.8rem;
        padding: 9px 16px;
        border-radius: 6px 6px 0 0;
        cursor: pointer;
        transition: background 0.15s, color 0.15s, border-color 0.15s;
        touch-action: manipulation;
    }
    .ujian-tab-btn:hover { background: var(--c-surface-3); }
    .ujian-tab-btn.active {
        background: var(--c-red);
        color: #fff;
        border-color: var(--c-red-dark, var(--c-red));
    }

    .ujian-tab-panel { padding: 16px; }

    .student-mark-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border);
        border-radius: 8px;
        margin-bottom: 14px;
        /* NOT overflow:hidden — that would clip/break the expanded header's
           sticky positioning below, same issue as the earlier judge-card
           sticky bug. Corners are rounded explicitly on the header/content
           instead of relying on the parent to clip them. */
        box-shadow: 0 1px 3px rgba(0,0,0,0.04);
    }
    /* Collapsed by default — tap to expand one student at a time */
    .student-mark-card-header {
        appearance: none;
        -webkit-appearance: none;
        width: 100%;
        display: flex;
        align-items: center;
        gap: 10px;
        background: var(--c-surface-2);
        padding: 12px 14px;
        font-weight: 700;
        font-size: 0.9rem;
        color: var(--c-text);
        border: none;
        border-bottom: 1px solid var(--c-border);
        border-radius: 8px 8px 0 0;
        cursor: pointer;
        text-align: left;
        touch-action: manipulation;
    }
    .student-mark-card-header:hover { background: var(--c-surface-3); }
    /* While expanded, the header sticks below the summary/tabs sticky bar
       so the judge always knows whose marks they're entering, even after
       scrolling past a long criteria list. --sticky-header-h is measured
       and set in JS (see applyResponsiveMarkingLayout). */
    .student-mark-card.expanded .student-mark-card-header {
        border-bottom-color: var(--c-red);
        position: sticky;
        top: calc(var(--header-h, 64px) + var(--sticky-header-h, 0px));
        z-index: 40;
        border-radius: 8px 8px 0 0;
    }
    .student-mark-card-arrow {
        font-size: 0.65rem;
        color: var(--c-text-muted);
        transition: transform 0.15s ease;
        flex-shrink: 0;
    }
    .student-mark-card.expanded .student-mark-card-arrow { color: var(--c-red); }
    .student-mark-card-name { flex: 1; }
    .student-mark-card-header .test-total {
        color: var(--c-red);
        font-family: 'DM Mono', monospace;
        font-weight: 700;
        font-size: 0.82rem;
    }
    .student-mark-card-content { padding-top: 2px; border-radius: 0 0 8px 8px; overflow: hidden; }

    .criteria-row {
        padding: 10px 14px;
        border-bottom: 1px solid var(--c-border);
    }
    .criteria-row:last-of-type { border-bottom: none; }
    .criteria-row-label {
        font-size: 1.05rem;
        font-weight: 700;
        color: var(--c-text);
        margin-bottom: 8px;
    }

    .absent-students-list {
        padding: 14px 16px;
        border-top: 1px solid var(--c-border);
    }
    .absent-students-title {
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--c-text-muted);
        margin-bottom: 8px;
    }
    .absent-student-row {
        padding: 6px 0;
        color: var(--c-text-muted);
        font-size: 0.85rem;
        opacity: 0.6;
    }

    .pm-nilai-wrap {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        margin-bottom: 8px;
        cursor: pointer;
        width: max-content;
        margin-left: auto;
        margin-right: auto;
    }
    .pm-nilai-checkbox { display: none; }
    .pm-toggle-switch {
        position: relative;
        width: 44px;
        height: 24px;
        background: var(--c-surface-3);
        border-radius: 24px;
        border: 1px solid var(--c-border-strong);
        transition: 0.2s;
    }
    .pm-toggle-switch::after {
        content: '';
        position: absolute;
        top: 2px;
        left: 2px;
        width: 18px;
        height: 18px;
        background: var(--c-text-muted);
        border-radius: 50%;
        transition: 0.2s;
    }
    .pm-nilai-checkbox:checked + .pm-toggle-switch {
        background: rgba(16,185,129,0.15);
        border-color: #10B981;
    }
    .pm-nilai-checkbox:checked + .pm-toggle-switch::after {
        transform: translateX(20px);
        background: #10B981;
    }
    .pm-toggle-label {
        font-size: 0.85rem;
        font-weight: 700;
        color: var(--c-text-muted);
        text-transform: uppercase;
        letter-spacing: 0.08em;
    }
    .pm-nilai-checkbox:checked ~ .pm-toggle-label { color: #10B981; }
    .pm-nilai-checkbox:disabled ~ .pm-toggle-switch,
    .pm-nilai-checkbox:disabled ~ .pm-toggle-label {
        opacity: 0.45;
        cursor: not-allowed;
    }

    /* ── Keypad ── */
    .pm-keypad {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 4px; /* still enough to prevent accidental adjacent taps */
        max-width: 200px; /* Much wider, comfortable thumb reach — kept as-is,
                              this is what sets button size, don't shrink it */
        margin: 6px auto;
    }
    .pm-keypad.locked { pointer-events: none; opacity: 0.6; }

    .pm-key-btn {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border);
        color: var(--c-text);
        padding: 0;
        min-height: 48px; /* Standard mobile touch target height */
        border-radius: 6px; /* Slightly rounder to look native */
        font-family: 'DM Mono', monospace;
        font-size: 1.25rem; /* Larger, clearer numbers */
        font-weight: 600;
        cursor: pointer;
        transition: background 0.1s, border-color 0.1s;
        touch-action: manipulation;
    }
    
    .pm-key-btn:hover:not(:disabled) {
        background: var(--c-surface-3);
        border-color: var(--c-border-strong);
    }
    .pm-key-btn.active {
        background: var(--c-red);
        color: #fff;
        border-color: var(--c-red);
        box-shadow: none;
        transform: none;
        z-index: 1;
    }
    .pm-key-btn.clear-btn {
        color: var(--c-red);
        background: transparent;
        border-color: var(--c-border);
    }
    .pm-key-btn:disabled { opacity: 0.4; cursor: not-allowed; }

    /* ── Desktop table: shrink the toggle/keypad back down ──
       The base sizes above (48px buttons, 200px keypad, 44px toggle) are
       sized for mobile/tablet thumbs. The markctrl node is the SAME shared
       element on desktop (see applyResponsiveMarkingLayout in the script
       below) — it just physically sits inside #desktopMarkingTable's <td>
       there, so scoping by that ancestor shrinks it back to a size that
       doesn't blow out every table column, without touching the mobile
       ribbon's sizing (#mobileMarkingUI) at all. */
    #desktopMarkingTable .pm-nilai-wrap { gap: 6px; margin-bottom: 8px; }
    #desktopMarkingTable .pm-toggle-switch { width: 37px; height: 20px; }
    #desktopMarkingTable .pm-toggle-switch::after { width: 15px; height: 15px; }
    #desktopMarkingTable .pm-nilai-checkbox:checked + .pm-toggle-switch::after { transform: translateX(17px); }
    #desktopMarkingTable .pm-toggle-label { font-size: 0.72rem; letter-spacing: 0.06em; }
    #desktopMarkingTable .pm-keypad { max-width: 148px; gap: 4px; margin: 6px auto; }
    #desktopMarkingTable .pm-key-btn { min-height: 37px; font-size: 1rem; border-radius: 4px; }

    /* ── Buttons ── */
    .mark-action-btn {
        padding: 7px 16px !important;
        font-size: 0.82rem !important;
        line-height: 1.4 !important;
    }

    /* ── Mobile overrides ── */
    .pm-accordion-container { overflow-x: hidden !important; }
    .pm-accordion-block .pm-table-wrap { overflow-x: auto !important; }

    @media (max-width: 768px) {
        .mark-actions-row { flex-wrap: wrap !important; gap: 6px !important; justify-content: center; }
        .mark-action-btn  { padding: 6px 12px !important; font-size: 0.78rem !important; }

        /* Fix overflowing student summary pills by stacking them vertically */
        .marking-summary { padding: 12px; flex-direction: column; align-items: stretch; gap: 8px; }
        .summary-pill { width: 100%; justify-content: space-between; box-sizing: border-box; }
        .summary-pill-name { text-align: left; white-space: normal; line-height: 1.3; padding-right: 10px; }

        /* Center tabs and force them to fit equally within the screen */
        .ujian-tabs { padding: 10px 12px; display: flex; justify-content: center; flex-wrap: nowrap; }
        .ujian-tab-btn { flex: 1; display: flex; align-items: center; justify-content: center; text-align: center; padding: 10px 6px; font-size: 0.75rem; word-break: break-word; line-height: 1.3; }
        
        .ujian-tab-panel { padding: 10px 12px; }
    }
    
    /* ── Parameter form grid ── */
    .param-grid {
        display: flex;
        flex-wrap: wrap;
        gap: 16px;
        align-items: flex-end;
        width: 100%;
    }
    
    .param-field {
        flex: 1 1 160px; /* Grow to fill space, shrink if needed, base width 160px */
        display: flex;
        flex-direction: column;
        min-width: 0; /* Prevents Select2 from breaking the layout */
    }
    
    .param-field--wide {
        flex: 2 1 240px; /* Grows twice as fast for the 'Kumpulan' dropdown so it has more room */
    }
    
    .param-field--btn {
        flex: 1 1 140px; 
    }
    
    .param-label {
        font-size: 0.65rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: var(--c-text-muted);
        margin-bottom: 6px;
        display: block;
    }
    
    @media (max-width: 640px) {
        /* On mobile, stack everything vertically */
        .param-field, .param-field--wide, .param-field--btn {
            flex: 1 1 100%; 
        }
        .param-field--btn {
            margin-top: 4px;
        }
    }
</style>

<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<h2 class="pm-page-heading">Sistem Pemarkahan</h2>

<?php if (isset($_GET["status"]) && $_GET["status"] === "success"): ?>
    <div id="toastNotification" class="pm-alert pm-toast-success" style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-radius: 8px;">
        <span>✅ <strong>Berjaya!</strong> Markah pemarkahan telah selamat disimpan ke dalam pangkalan data.</span>
        <button onclick="this.parentElement.style.display='none'" style="background:transparent; border:none; color:inherit; font-size:1.5rem; cursor:pointer; padding:0; line-height:1;">&times;</button>
    </div>
    <script>
        setTimeout(() => {
            const toast = document.getElementById('toastNotification');
            if(toast) toast.style.display = 'none';
        }, 5000);
        if (window.history.replaceState) {
            const url = new URL(window.location.href);
            url.searchParams.delete('status');
            window.history.replaceState({path: url.href}, '', url.href);
        }
    </script>
<?php endif; ?>

<?php if (isset($_GET["msg"]) && $_GET["msg"] === "access_denied"): ?>
    <div id="toastError" class="pm-alert pm-toast-danger" style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-radius: 8px;">
        <span>🔒 <strong>Akses Ditolak!</strong> Kumpulan ini telah ditetapkan kepada juri lain. Anda tidak dibenarkan mengubah markahnya.</span>
        <button onclick="this.parentElement.style.display='none'" style="background:transparent; border:none; color:inherit; font-size:1.5rem; cursor:pointer; padding:0; line-height:1;">&times;</button>
    </div>
<?php endif; ?>

<?php if (isset($_GET["msg"]) && $_GET["msg"] === "edit_locked"): ?>
    <div id="toastError" class="pm-alert pm-toast-danger" style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-radius: 8px;">
        <span>🔒 <strong>Dikunci Sepenuhnya!</strong> Hak mengedit telah digunakan. Markah tidak boleh diubah lagi.</span>
        <button onclick="this.parentElement.style.display='none'" style="background:transparent; border:none; color:inherit; font-size:1.5rem; cursor:pointer; padding:0; line-height:1;">&times;</button>
    </div>
<?php endif; ?>

<?php if (isset($_GET["msg"]) && $_GET["msg"] === "empty_submission"): ?>
    <div id="toastError" class="pm-alert pm-toast-danger" style="margin-bottom: 20px; display: flex; justify-content: space-between; align-items: center; padding: 12px 16px; border-radius: 8px;">
        <span>⚠️ <strong>Ralat!</strong> Tiada markah dimasukkan. Sila masukkan sekurang-kurangnya satu markah sebelum menyimpan.</span>
        <button onclick="this.parentElement.style.display='none'" style="background:transparent; border:none; color:inherit; font-size:1.5rem; cursor:pointer; padding:0; line-height:1;">&times;</button>
    </div>
    <script>
        if (window.history.replaceState) {
            const url = new URL(window.location.href);
            url.searchParams.delete('msg');
            window.history.replaceState({path: url.href}, '', url.href);
        }
    </script>
<?php endif; ?>

<div class="top-dashboard-row">
    <div class="identity-col">
        <div class="judge-card judge-identity-card">
            <div class="identity-top">Selamat Datang</div>
            <div class="identity-name"><?= htmlspecialchars(
                $judge_name,
            ) ?></div>
            <div class="identity-meta">
                <span>Sidang</span> <b><?= htmlspecialchars(
                    $session_label,
                ) ?></b>
                <span>Status</span> <b
                    style="color: <?= $marking_active
                        ? "#4ade80"
                        : "#f87171" ?>;"><?= $marking_active
    ? "🟢 Sedia"
    : "🔴 Belum" ?></b>
                <span>Tarikh</span> <b><span id="liveDate"></span></b>
                <span>Masa</span> <b><span id="liveTime"></span></b>
            </div>

            <hr class="identity-divider">

            <div class="identity-stats">
                <div class="identity-stat-box">
                    <div class="stat-val"><?= $stat_total ?></div>
                    <div class="stat-label">Jumlah Kumpulan</div>
                </div>
                <div class="identity-stat-box">
                    <div class="stat-val"><?= $stat_done ?></div>
                    <div class="stat-label">Selesai</div>
                </div>
                <div class="identity-stat-box">
                    <div class="stat-val"><?= $stat_pending ?></div>
                    <div class="stat-label">Belum Ditanda</div>
                </div>
            </div>

            <div class="identity-progress-wrap">
                <div class="identity-progress-label">
                    <span>Kemajuan Pemarkahan</span>
                    <span><?= $stat_pct ?>%</span>
                </div>
                <div class="identity-progress-bar">
                    <div class="identity-progress-fill" style="width:<?= $stat_pct ?>%;"></div>
                </div>
            </div>
        </div>
    </div>

    <div class="summary-col">
        <div class="judge-card">
            <h3 class="pm-card-title">Kemajuan Pemarkahan Mengikut Tahun, Siri & Sidang</h3>

            <div class="summary-search-wrap">
                <input type="text" id="summarySearchInput"
                    placeholder="Cari tahun / siri / sidang / peringkat / kumpulan / juri..." autocomplete="off">
            </div>

            <div class="pm-accordion-container" id="summaryAccordionContainer">
                <?php
                // Fetch and group data by Year, Siri, and Session
                $sqSummary = $conn->prepare("
                    SELECT sr.siri_year, sr.siri_name, s.session_name, l.level_name, g.group_name, j.name AS judge_name,
                           GROUP_CONCAT(
                               DISTINCT CONCAT(
                                   '• ', REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(t.test_name,'&','&amp;'),'<','&lt;'),'>','&gt;'),'\"','&quot;'),'\'','&#39;'),
                                   CASE WHEN EXISTS (
                                       SELECT 1 FROM scores sc
                                       JOIN criteria c3 ON sc.criteria_id = c3.criteria_id
                                       WHERE sc.group_id = g.group_id AND c3.test_id = t.test_id AND sc.submitted = 1
                                   ) THEN ' <span style=\"color:#10B981;font-weight:600;\">(☑ Selesai)</span>'
                                   ELSE ' <span style=\"color:var(--c-text-muted);\">(☐ Belum)</span>' END
                               ) SEPARATOR '<br>'
                           ) as status_list,
                           (SELECT GROUP_CONCAT(DISTINCT sc2.school_name SEPARATOR ', ')
                            FROM group_students gs2
                            JOIN students st2 ON gs2.student_id = st2.student_id
                            JOIN schools sc2 ON st2.school_id = sc2.school_id
                            WHERE gs2.group_id = g.group_id) as school_names
                    FROM sessions s
                    LEFT JOIN siri sr ON s.siri_id = sr.siri_id
                    JOIN levels l ON s.session_id = l.session_id
                    JOIN `groups` g ON l.level_id = g.level_id
                    LEFT JOIN judges j ON g.judge_id = j.id
                    JOIN tests t ON l.level_id = t.level_id
                    JOIN criteria c ON t.test_id = c.test_id
                    WHERE g.judge_id = ?
                    GROUP BY sr.siri_year, sr.siri_name, s.session_id, s.session_name, l.level_id, g.group_id
                    ORDER BY sr.siri_year DESC, sr.siri_name ASC, s.session_name ASC, l.level_name, g.group_name
                ");
                $sqSummary->bind_param("i", $judge_id);
                $sqSummary->execute();
                $summary = $sqSummary->get_result();
                $sqSummary->close();

                $groupedData = [];
                while ($row = $summary->fetch_assoc()) {
                    // Create a clean layout for the accordion header
                    $yearText = $row["siri_year"] ? $row["siri_year"] : "Tiada Tahun";
                    $siriText = $row["siri_name"] ? $row["siri_name"] : "Tiada Siri";
                    
                    $headerTitle = "{$yearText} | {$siriText} | {$row['session_name']}";
                    $groupedData[$headerTitle][] = $row;
                }

                if (empty($groupedData)) {
                    echo "<div style='color:#aaa; text-align:center; padding:30px; background:var(--c-surface-2); border-radius:6px; border: 1px dashed var(--c-border);'>Tiada rekod ujian ditemui.</div>";
                } else {
                    foreach ($groupedData as $sessionName => $rows) {
                        $sidHash = md5($sessionName); // Unique ID for toggle
                        $groupCount = count($rows);

                        // Split the string "2026 | Siri 1 | Sidang 1" into an array
                        $parts = explode(" | ", $sessionName);
                        $hasParts = count($parts) === 3;
                        
                        $yearBadge = $hasParts ? $parts[0] : "";
                        $siriBadge = $hasParts ? $parts[1] : "";
                        $sidangName = $hasParts ? $parts[2] : $sessionName;

                        // Ensure search functionality still works with the full combined string
                        echo "<div class='pm-accordion-block' data-session='" . strtolower(htmlspecialchars($sessionName)) . "'>";

                        // Enhanced Accordion Header
                        echo "<div class='pm-accordion-header' onclick=\"toggleSummaryAccordion('{$sidHash}')\" id='header_{$sidHash}'>";
                        echo "<div class='pm-accordion-header-left'>";
                        echo "<span class='pm-accordion-arrow' id='arrow_{$sidHash}'>▶</span>";
                        
                        if ($hasParts) {
                            echo "<span class='pm-badge pm-badge-year'>" . htmlspecialchars($yearBadge) . "</span>";
                            echo "<span class='pm-badge pm-badge-siri'>" . htmlspecialchars($siriBadge) . "</span>";
                            echo "<span class='pm-accordion-title'>" . htmlspecialchars($sidangName) . "</span>";
                        } else {
                            // Fallback just in case the string format doesn't match
                            echo "<span class='pm-accordion-title'>" . htmlspecialchars($sessionName) . "</span>";
                        }
                        
                        echo "</div>";
                        
                        // Right side counter
                        echo "<div class='pm-count-badge'>{$groupCount} Kumpulan</div>";
                        echo "</div>";

                        // Accordion Content (Table) - No changes to the table itself
                        echo "<div class='pm-accordion-content' id='content_{$sidHash}'>";
                        echo "<div class='pm-table-wrap'><table class='pm-table summaryTable'>";
                        echo "<thead><tr><th>Peringkat</th><th>Status Ujian</th><th>Kumpulan</th><th>Cawangan</th><th>Juri Bertugas</th></tr></thead>";
                        echo "<tbody>";

                        foreach ($rows as $r) {
                            $juriText = $r["judge_name"]
                                ? htmlspecialchars($r["judge_name"])
                                : "<i style='color:var(--c-text-faint);'>Tiada Juri</i>";
                            $cawanganText = $r["school_names"]
                                ? htmlspecialchars($r["school_names"])
                                : "<i style='color:var(--c-text-faint);'>Tiada Pelajar</i>";

                            echo "<tr class='summary-row'>";
                            echo "<td style='font-weight: 500;'>" . htmlspecialchars($r["level_name"]) . "</td>";
                            echo "<td style='line-height: 1.6;'>{$r["status_list"]}</td>";
                            echo "<td>" . htmlspecialchars($r["group_name"]) . "</td>";
                            echo "<td style='color:var(--c-text-muted); font-size:var(--text-sm); max-width:180px; white-space:normal; line-height:1.2;'>{$cawanganText}</td>";
                            echo "<td style='font-weight: 600; color: var(--c-red);'>{$juriText}</td>";
                            echo "</tr>";
                        }

                        echo "</tbody></table></div></div></div>";
                    }
                }
                ?>
            </div>
        </div>
    </div>
</div>

<div class="judge-card">
    <h3 class="pm-card-title">Pilih Parameter Pemarkahan</h3>
    <form method="POST" action="judge.php" id="judgeSelection">
        <input type="hidden" name="start_marking" value="1">
        <?php if ($current_siri_id): ?>
            <input type="hidden" name="siri_id" value="<?= $current_siri_id ?>">
        <?php endif; ?>

        <div class="param-grid">

            <?php if ($show_year_dropdown): ?>
            <div class="param-field">
                <label class="param-label">Tahun:</label>
                <select id="yearSelect" class="pm-input" style="width:100%;">
                    <option value="">-- Pilih Tahun --</option>
                    <?php foreach ($all_years as $yr): ?>
                        <option value="<?= $yr ?>" <?= $current_year == $yr ? 'selected' : '' ?>>
                            <?= htmlspecialchars($yr) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <?php if ($show_siri_dropdown): ?>
            <div class="param-field">
                <label class="param-label">Siri:</label>
                <select name="siri_id" id="siriSelect" class="pm-input" style="width:100%;">
                    <option value="">-- <?= $show_year_dropdown ? 'Pilih Tahun Dahulu' : 'Pilih Siri' ?> --</option>
                    <?php foreach ($all_siri as $sr):
                        $hidden = $show_year_dropdown && $current_year && $sr['siri_year'] != $current_year;
                    ?>
                        <option value="<?= $sr['siri_id'] ?>"
                            data-year="<?= $sr['siri_year'] ?>"
                            <?= $current_siri_id == $sr['siri_id'] ? 'selected' : '' ?>
                            <?= $hidden ? 'style="display:none"' : '' ?>>
                            <?= htmlspecialchars($sr['siri_name']) ?> (<?= $sr['siri_year'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>

            <div class="param-field">
                <label class="param-label">Sidang:</label>
                <select name="session_id" id="sessionSelect" required class="pm-input" style="width:100%;">
                    <option value="">-- <?= ($show_siri_dropdown && !$current_siri_id) ? 'Pilih Siri Dahulu' : 'Pilih Sidang' ?> --</option>
                    <?php
                    // If siri is already determined, pre-populate sessions
                    if ($current_siri_id) {
                        $stmt = $conn->prepare("SELECT * FROM sessions WHERE siri_id = ? ORDER BY session_name ASC");
                        $stmt->bind_param("i", $current_siri_id);
                        $stmt->execute();
                        $sess_res = $stmt->get_result();
                        while ($s = $sess_res->fetch_assoc()) {
                            $sel = $current_session == $s["session_id"] ? "selected" : "";
                            echo "<option value='{$s["session_id"]}' $sel>{$s["session_name"]}</option>";
                        }
                        $stmt->close();
                    } elseif (!$show_siri_dropdown) {
                        // No siri dropdown shown — show all sessions
                        $sess_res = $conn->query("SELECT * FROM sessions ORDER BY session_name ASC");
                        while ($s = $sess_res->fetch_assoc()) {
                            $sel = $current_session == $s["session_id"] ? "selected" : "";
                            echo "<option value='{$s["session_id"]}' $sel>{$s["session_name"]}</option>";
                        }
                    }
                    ?>
                </select>
            </div>

            <div class="param-field">
                <label class="param-label">Peringkat:</label>
                <select name="level_id" id="levelSelect" required class="pm-input" style="width:100%;">
                    <option value="">-- Sila Pilih Sidang Dahulu --</option>
                    <?php if ($current_session) {
                        $levels = $conn->query(
                            "SELECT * FROM levels WHERE session_id = " . (int)$current_session . " ORDER BY level_name ASC"
                        );
                        while ($l = $levels->fetch_assoc()) {
                            $sel = $current_level == $l["level_id"] ? "selected" : "";
                            echo "<option value='{$l["level_id"]}' $sel>{$l["level_name"]}</option>";
                        }
                    } ?>
                </select>
            </div>

            <div class="param-field param-field--wide">
                <label class="param-label">Kumpulan:</label>
                <select name="group_id" id="groupSelect" required class="pm-input" style="width:100%;">
                    <option value="">-- Sila Pilih Peringkat Dahulu --</option>
                    <?php if ($current_level) {
                        $groups = $conn->query(
                            "SELECT * FROM `groups` WHERE level_id = " . (int)$current_level . " ORDER BY group_name ASC"
                        );
                        while ($g = $groups->fetch_assoc()) {
                            $sel = $current_group == $g["group_id"] ? "selected" : "";
                            echo "<option value='{$g["group_id"]}' $sel>{$g["group_name"]}</option>";
                        }
                    } ?>
                </select>
            </div>

            <div class="param-field param-field--btn">
                <label class="param-label" style="visibility:hidden;">-</label>
                <button type="submit" class="pm-btn pm-btn-primary form-btn-submit" style="width:100%;">▶ Mula Menanda</button>
            </div>

        </div>
    </form>
</div>

<script>
    // Global criteria data (populated after marking form renders — see bottom script block)
    let criteriaByTest = {};

    // ACCORDION UI LOGIC
    function toggleSummaryAccordion(id) {
        const content = document.getElementById('content_' + id);
        const arrow = document.getElementById('arrow_' + id);
        const header = document.getElementById('header_' + id);

        if (content.style.display === 'block') {
            content.style.display = 'none';
            arrow.style.transform = 'rotate(0deg)';
            header.classList.remove('active');
        } else {
            content.style.display = 'block';
            arrow.style.transform = 'rotate(90deg)';
            header.classList.add('active');
        }
    }

    // LIVE SEARCH LOGIC FOR ACCORDION
    document.getElementById('summarySearchInput').addEventListener('keyup', function () {
        const keyword = this.value.toLowerCase();
        const blocks = document.querySelectorAll('.pm-accordion-block');

        blocks.forEach(block => {
            let hasMatch = false;
            const sessionName = block.getAttribute('data-session');
            const rows = block.querySelectorAll('.summary-row');

            // Match at the Session name level
            const sessionMatch = sessionName.includes(keyword);

            rows.forEach(row => {
                const rowText = row.textContent.toLowerCase();
                if (rowText.includes(keyword) || sessionMatch) {
                    row.style.display = '';
                    hasMatch = true;
                } else {
                    row.style.display = 'none';
                }
            });

            const content = block.querySelector('.pm-accordion-content');
            const arrow = block.querySelector('.pm-accordion-arrow');
            const header = block.querySelector('.pm-accordion-header');

            if (hasMatch) {
                block.style.display = '';
                // Auto expand if actively searching
                if (keyword.length > 0) {
                    content.style.display = 'block';
                    arrow.style.transform = 'rotate(90deg)';
                    header.classList.add('active');
                } else {
                    // Collapse back when search is empty
                    content.style.display = 'none';
                    arrow.style.transform = 'rotate(0deg)';
                    header.classList.remove('active');
                }
            } else {
                block.style.display = 'none';
            }
        });
    });

    $(document).ready(function () {
        // Live Clock & Date
        function updateDateTime() {
            const now = new Date();
            const timeEl = document.getElementById('liveTime');
            const dateEl = document.getElementById('liveDate');

            if (timeEl) {
                timeEl.textContent = now.toLocaleTimeString('ms-MY', { hour: '2-digit', minute: '2-digit' });
            }
            if (dateEl) {
                dateEl.textContent = now.toLocaleDateString('ms-MY', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
            }
        }

        updateDateTime(); // Run immediately on load
        setInterval(updateDateTime, 1000);

        // Initialize Select2
        const select2Fields = ['#sessionSelect', '#levelSelect', '#groupSelect'];
        <?php if ($show_year_dropdown): ?> select2Fields.push('#yearSelect'); <?php endif; ?>
        <?php if ($show_siri_dropdown): ?> select2Fields.push('#siriSelect'); <?php endif; ?>
        $(select2Fields.join(',')).select2({ width: '100%' });

        $('#groupSelect').select2({
            width: '100%',
            templateResult: function(opt) {
                if (!opt.id) return opt.text;
                const el = opt.element;
                const span = document.createElement('span');
                span.textContent = opt.text;
                if (el && el.dataset.unassigned === '1') {
                    span.style.color = 'var(--c-text-muted)';
                    span.style.fontStyle = 'italic';
                }
                return span;
            }
        });

        // Year → filter Siri options
        $('#yearSelect').on('change', function () {
            const year = $(this).val();
            const siriSelect = $('#siriSelect');
            siriSelect.find('option[data-year]').each(function () {
                $(this).toggle(!year || $(this).data('year') == year);
            });
            siriSelect.val('').trigger('change.select2');
            $('#sessionSelect').empty().append('<option value="">-- Pilih Siri Dahulu --</option>').trigger('change.select2');
            $('#levelSelect').empty().append('<option value="">-- Sila Pilih Sidang Dahulu --</option>').trigger('change.select2');
            $('#groupSelect').empty().append('<option value="">-- Sila Pilih Peringkat Dahulu --</option>').trigger('change.select2');
        });

        // Siri → Sessions
        $('#siriSelect').on('change', function () {
            const siriId = $(this).val();
            const sessionSelect = $('#sessionSelect');
            sessionSelect.empty().append('<option value="">Memuatkan...</option>').trigger('change.select2');
            $('#levelSelect').empty().append('<option value="">-- Sila Pilih Sidang Dahulu --</option>').trigger('change.select2');
            $('#groupSelect').empty().append('<option value="">-- Sila Pilih Peringkat Dahulu --</option>').trigger('change.select2');
            if (!siriId) {
                sessionSelect.empty().append('<option value="">-- Pilih Siri Dahulu --</option>').trigger('change.select2');
                return;
            }
            // Update the hidden siri_id input if no visible siri dropdown
            $('input[name="siri_id"]').val(siriId);
            $.get('judge.php?ajax_sessions=1&siri_id=' + encodeURIComponent(siriId), function (html) {
                sessionSelect.empty().append('<option value="">-- Pilih Sidang --</option>' + html).trigger('change.select2');
            });
        });

        // Session → Levels
        $('#sessionSelect').on('change', function () {
            const sessionId = $(this).val();
            const levelSelect = $('#levelSelect');
            levelSelect.empty().append('<option value="">Memuatkan...</option>').trigger('change.select2');
            $('#groupSelect').empty().append('<option value="">-- Sila Pilih Peringkat Dahulu --</option>').trigger('change.select2');
            if (!sessionId) {
                levelSelect.empty().append('<option value="">-- Pilih Sidang Dahulu --</option>').trigger('change.select2');
                return;
            }
            $.get('judge.php?ajax_levels=1&session_id=' + encodeURIComponent(sessionId), function (html) {
                levelSelect.empty().append('<option value="">-- Pilih Peringkat --</option>' + html).trigger('change.select2');
            });
        });

        // Level → Groups
        $('#levelSelect').on('change', function () {
            const levelId = $(this).val();
            const groupSelect = $('#groupSelect');
            groupSelect.empty().append('<option value="">Memuatkan...</option>').trigger('change.select2');
            if (!levelId) {
                groupSelect.empty().append('<option value="">-- Pilih Peringkat Dahulu --</option>').trigger('change.select2');
                return;
            }
            $.get('judge.php?ajax_groups=1&level_id=' + encodeURIComponent(levelId), function (html) {
                groupSelect.empty().append('<option value="">-- Pilih Kumpulan --</option>' + html).trigger('change.select2');
            });
        });

    }); // <-- ONLY ONE CLOSING BRACKET FOR DOCUMENT.READY

    // Marking UI Logic
    document.addEventListener('change', function (e) {
        // 1. Handle Dropdown Value Change
        if (e.target.classList.contains('mark-select')) {
            const select = e.target;
            const { student, criteria } = select.dataset;

            // Update or create the hidden input that actually submits the data
            let inp = document.getElementById(`mark_${student}_${criteria}`);
            if (!inp) {
                inp = document.createElement('input'); inp.type = 'hidden';
                inp.id = `mark_${student}_${criteria}`; inp.name = `marks[${student}][${criteria}]`;
                document.getElementById('markForm').appendChild(inp);
            }
            inp.value = select.value;
            updateTotals(student);
        }

        // 2. Handle the "Nilai" Checkbox Toggle
        if (e.target.classList.contains('enable-marking')) {
            const cb = e.target;
            const wrapper = document.getElementById(`keypad_${cb.dataset.student}_${cb.dataset.criteria}`);
            const select = document.getElementById(`select_${cb.dataset.student}_${cb.dataset.criteria}`);
            const inp = document.getElementById(`mark_${cb.dataset.student}_${cb.dataset.criteria}`);

            wrapper.style.display = cb.checked ? 'block' : 'none';
            if (!cb.checked) {
                if (select) select.value = '';
                if (inp) inp.value = '';
            }
            updateTotals(cb.dataset.student);
        }
    });

    function updateTotals(studentId) {
        let overallSum = 0, overallMax = 0;
        for (const testName in criteriaByTest) {
            let testSum = 0, testMax = 0;
            Object.keys(criteriaByTest[testName]).forEach(cid => {
                const cb = document.querySelector(`.enable-marking[data-student='${studentId}'][data-criteria='${cid}']`);
                if (!cb || cb.checked) {
                    testMax += 10;
                    // Look for the dropdown value instead of the selected button
                    const sel = document.querySelector(`.mark-select[data-student='${studentId}'][data-criteria='${cid}']`);
                    if (sel && sel.value !== '') testSum += parseInt(sel.value);
                }
            });
            const cell = document.querySelector(`.test-total[data-student='${studentId}'][data-test='${testName}']`);
            if (cell) cell.innerHTML = `${testSum} / ${testMax}`;
            overallSum += testSum; overallMax += testMax;
        }
        const oCell = document.querySelector(`.overall-total[data-student='${studentId}']`);
        if (oCell) oCell.innerHTML = `${overallSum} / ${overallMax}`;
    }
</script>

<?php // ── MARKING LOGIC ──────────────────────────────────────────────────────

if ($marking_active && $current_session && $current_group) {
    $session_id = (int) $current_session;
    $group_id = (int) $current_group;

    // SECURED: Fetch level and associated judge
    $level_id = 0;
    $group_judge_id = 0;
    $group_edit_used = 0;
    $stmt = $conn->prepare(
        "SELECT level_id, judge_id, edit_used FROM `groups` WHERE group_id = ?",
    );

    if ($stmt) {
        $stmt->bind_param("i", $group_id);
        $stmt->execute();
        $r = $stmt->get_result();
        if ($r && $r->num_rows === 1) {
            $grpData = $r->fetch_assoc();
            $level_id = (int) $grpData["level_id"];
            $group_judge_id = (int) $grpData["judge_id"];
            $group_edit_used = (int) ($grpData["edit_used"] ?? 0); // Check if edit was used
        }
        $stmt->close();
    }

    // SECURED: Check scores table directly to see if someone already marked it
    // Failsafe: only query judge_id from scores if the column actually exists
    $marker_judge_id = $group_judge_id;
    $col_check = $conn->query("SHOW COLUMNS FROM scores LIKE 'judge_id'");
    if ($col_check && $col_check->num_rows > 0) {
        $stmt = $conn->prepare(
            "SELECT judge_id FROM scores WHERE group_id = ? LIMIT 1",
        );
        if ($stmt) {
            $stmt->bind_param("i", $group_id);
            $stmt->execute();
            $rj = $stmt->get_result();
            if ($rj && $rj->num_rows > 0) {
                $rowj = $rj->fetch_assoc();
                if (!empty($rowj["judge_id"])) {
                    $marker_judge_id = (int) $rowj["judge_id"];
                }
            }
            $stmt->close();
        }
    }

    // SECURED: Check existing scores
    $existing_scores = [];
    $is_locked = false;
    // edit_mode=1 only works if the edit token hasn't been consumed yet.
    // This is the core fix: a judge who already edited once cannot re-open
    // edit mode by re-posting edit_mode=1, because group_edit_used will be 1.
    $raw_edit_requested = isset($_POST["edit_mode"]) && $_POST["edit_mode"] == "1";
    $is_edit_mode_form  = $raw_edit_requested && ($group_edit_used === 0);

    $stmt = $conn->prepare("
        SELECT student_id, criteria_id, mark, submitted
        FROM scores
        WHERE group_id = ?
    ");
    if ($stmt) {
        $stmt->bind_param("i", $group_id);
        $stmt->execute();
        $sres = $stmt->get_result();
        if ($sres && $sres->num_rows > 0) {
            $has_submitted = false;
            while ($sr = $sres->fetch_assoc()) {
                // Draft marks (submitted=0) still prefill the form so the judge
                // sees their in-progress work, but they must NOT lock the group —
                // only a finalized (submitted=1) mark counts as "saved".
                $existing_scores[$sr["student_id"]][$sr["criteria_id"]] =
                    $sr["mark"];
                if ((int) $sr["submitted"] === 1) {
                    $has_submitted = true;
                }
            }
            // Lock if a submitted mark exists, UNLESS edit token is valid AND not yet consumed
            $is_locked = $has_submitted && !($is_edit_mode_form && $group_edit_used === 0);
        }
        $stmt->close();
    }

    // TAMPER PROTECTION: reject if a different judge posts edit_mode=1
    if (
        $is_edit_mode_form &&
        $marker_judge_id !== 0 &&
        $marker_judge_id !== $judge_id
    ) {
        $is_locked = true;
        $is_edit_mode_form = false;
    }

    // SECURED: Students in group (Correlated Subquery Fix to prevent duplicate rows from attendance)
    $student_rows = [];
    $stmt = $conn->prepare("
        SELECT st.student_id, st.student_name, sc.school_name,
               COALESCE((SELECT status FROM attendance WHERE student_id = st.student_id ORDER BY attendance_id DESC LIMIT 1), 'Absent') AS status
        FROM group_students gs
        JOIN students st ON gs.student_id = st.student_id
        LEFT JOIN schools sc ON st.school_id = sc.school_id
        WHERE gs.group_id = ?
        ORDER BY st.student_name
    ");
    if ($stmt) {
        $stmt->bind_param("i", $group_id);
        $stmt->execute();
        $res = $stmt->get_result();
        if ($res) {
            while ($r2 = $res->fetch_assoc()) {
                $student_rows[] = $r2;
            }
        }
        $stmt->close();
    }

    // SECURED: Criteria by test
    $criteria_by_test = [];
    $test_ids_map = []; // Added for dynamic JS creation
    $stmt = $conn->prepare("
    SELECT c.criteria_id, c.criteria_name, t.test_id, t.test_name
    FROM criteria c
    JOIN tests t ON c.test_id = t.test_id
    WHERE t.level_id = ?
    ORDER BY t.test_id, c.criteria_id
");
    if ($stmt) {
        $stmt->bind_param("i", $level_id);
        $stmt->execute();
        $cres = $stmt->get_result();
        if ($cres) {
            while ($cr = $cres->fetch_assoc()) {
                $criteria_by_test[$cr["test_name"]][$cr["criteria_id"]] =
                    $cr["criteria_name"];
                $test_ids_map[$cr["test_name"]] = $cr["test_id"]; // Map the ID
            }
        }
        $stmt->close();
    }

    // ── FETCH EXISTING DATA (no longer needed for modal — cascade AJAX used instead) ──

    // // SECURED: Criteria by test
    // $criteria_by_test = [];
    // $stmt = $conn->prepare("
    //     SELECT c.criteria_id, c.criteria_name, t.test_name
    //     FROM criteria c
    //     JOIN tests t ON c.test_id = t.test_id
    //     WHERE t.level_id = ?
    //     ORDER BY t.test_id, c.criteria_id
    // ");
    // if ($stmt) {
    //     $stmt->bind_param("i", $level_id);
    //     $stmt->execute();
    //     $cres = $stmt->get_result();
    //     if ($cres)
    //         while ($cr = $cres->fetch_assoc()) {
    //             $criteria_by_test[$cr['test_name']][$cr['criteria_id']] = $cr['criteria_name'];
    //         }
    //     $stmt->close();
    // }

    // Student list table
    $student_list_html =
        "<div class='pm-table-wrap student-list-wrap'><table class='pm-table'>";

    // Removed the "spring" width hacks so the table balances naturally and uniformly.
    $student_list_html .= "<thead><tr>
        <th style='text-align: center; width: 60px;'>ID</th>
        <th>Nama</th>
        <th>Cawangan</th>
        <th style='text-align: center; width: 140px;'>Status</th>
    </tr></thead><tbody>";

    foreach ($student_rows as $r) {
        if ($r["status"] === "Present") {
            $row_style = "";
            // Emerald Green pill badge - visible in both Dark & Light modes
            $status_cell = "<td style='text-align: center;'>
                <span style='display: inline-block; color: #10B981; font-weight: 700; background: rgba(16, 185, 129, 0.15); padding: 4px 12px; border-radius: 99px; font-size: 0.85rem;'>✔ Hadir</span>
            </td>";
        } else {
            $row_style = "style='opacity: 0.6;'";
            // Red pill badge - visible in both Dark & Light modes
            $status_cell = "<td style='text-align: center;'>
                <span style='display: inline-block; color: #EF4444; font-weight: 700; background: rgba(239, 68, 68, 0.15); padding: 4px 12px; border-radius: 99px; font-size: 0.85rem;'>❌ Tidak Hadir</span>
            </td>";
        }
        $student_list_html .= "<tr $row_style>
            <td style='text-align: center; color: var(--c-text-faint);'>{$r["student_id"]}</td>
            <td style='font-weight: 600; color: var(--c-text);'>" . htmlspecialchars($r["student_name"]) . "</td>
            <td style='color: var(--c-text-muted);'>" . htmlspecialchars($r["school_name"] ?? '') . "</td>
            $status_cell
        </tr>";
    }
    $student_list_html .= "</tbody></table></div>";

    // Added pm-card-title class to ensure the heading styling matches the rest of the page
    echo "<div class='judge-card'><h3 class='pm-card-title'>Senarai Pesilat</h3>$student_list_html</div>";

    if (count($student_rows) === 0) {
        echo "<div class='pm-alert pm-alert-danger'>❌ Tiada pelajar dalam kumpulan ini.</div>";
    } else {
        if ($is_edit_mode_form) {
            echo "<div class='pm-alert pm-alert-warn'>✏️ <strong>Mod Edit Aktif</strong> — Sila berhati-hati. Kemaskini markah hanya boleh dilakukan <b>SEKALI SAHAJA</b> sebelum dikunci sepenuhnya. Simpan semula untuk mengunci.</div>";
        }

        if (!$is_locked) {
            echo "<div style='display: flex; gap: 8px; margin-bottom: 16px; justify-content: flex-end;'>
                    <button type='button' class='pm-btn pm-btn-primary' style='font-size:0.78rem; padding: 5px 12px; border-radius: 5px; line-height:1.4;' onclick='openParameterModal()'>+ Tambah Peringkat &amp; Ujian</button>
                    </div>";
        }

        // --- OWNERSHIP LOCK LOGIC ---
        if ($is_locked) {
            if ($marker_judge_id === 0 || $marker_judge_id === $judge_id) {
                if ($group_edit_used === 1) {
                    // The judge has used their edit. Hide button, show locked message.
                    echo "<div class='pm-alert pm-lock-alert'>
                            🔒 <strong>Dikunci Sepenuhnya:</strong> Markah telah disimpan dan disahkan. Pengemaskinian tidak lagi dibenarkan.
                          </div>";
                } else {
                    // This judge owns the marks AND hasn't used their edit yet
                    echo "<div class='pm-alert pm-alert-success'>🔒 Markah telah disimpan.
                                  <form method='POST' style='display:inline;margin-left:10px;'>
                                    <input type='hidden' name='session_id' value='$session_id'>
                                    <input type='hidden' name='level_id'   value='$level_id'>
                                    <input type='hidden' name='group_id'   value='$group_id'>
                                    <input type='hidden' name='start_marking' value='1'>
                                    <input type='hidden' name='edit_mode'  value='1'>
                                    <button class='pm-btn pm-btn-ghost' style='font-size:0.8rem;padding:4px 10px;'>✏️ Edit</button>
                                  </form></div>";
                }
            } else {
                // Another judge owns the marks. Hide edit button, show warning.
                $marker_name = "Juri Lain";
                if ($marker_judge_id) {
                    $q = $conn->query(
                        "SELECT name FROM judges WHERE id = $marker_judge_id",
                    );
                    if ($q && $q->num_rows) {
                        $marker_name = htmlspecialchars(
                            $q->fetch_assoc()["name"],
                        );
                    }
                }
                echo "<div class='pm-alert pm-alert-danger'>
                        🔒 <strong>Akses Ditolak:</strong> Markah kumpulan ini telah direkodkan oleh <b>$marker_name</b>. Anda tidak dibenarkan mengeditnya.
                      </div>";
            }
        }

        echo "<form method='POST' action='save_scores.php' id='markForm'>
        <input type='hidden' name='session_id' value='$session_id'>
        <input type='hidden' name='level_id'   value='$level_id'>
        <input type='hidden' name='group_id'   value='$group_id'>
        <input type='hidden' name='judge_id'   value='$judge_id'>
        <input type='hidden' name='csrf_token' value='" . htmlspecialchars($csrf) . "'>
        <input type='hidden' name='edit_mode'  value='" .
            ($is_edit_mode_form ? "1" : "0") .
            "'>
        <div id='pendingParamsContainer'><!-- pending test/criteria pairs injected here by JS --></div>
     ";

        if (!empty($existing_scores)) {
            foreach ($existing_scores as $s_id => $crits) {
                foreach ($crits as $c_id => $val) {
                    echo "<input type='hidden' id='mark_{$s_id}_{$c_id}' name='marks[{$s_id}][{$c_id}]' value='$val'>";
                }
            }
        }

        // ── DESKTOP TABLE vs. MOBILE/TABLET RIBBON ────────────────────────
        // Desktop keeps the original wide table exactly as it was. Below
        // 1024px, judges instead get a tab-per-Ujian ribbon (accordion —
        // opening one closes the rest) with students stacked vertically, so
        // the only scroll direction is down — no more scrolling right into
        // a dense grid, which was a real fat-finger mis-tap risk.
        //
        // The checkbox + keypad + hidden input for each student×criteria is
        // rendered exactly ONCE (as a "markctrl" unit) and JS physically
        // relocates that single live node between the table cell and the
        // mobile card slot depending on viewport — never duplicated, so
        // there's nothing that can fall out of sync between the two layouts.
        $present_students = array_filter($student_rows, fn($s) => $s["status"] === "Present");
        $absent_students  = array_filter($student_rows, fn($s) => $s["status"] !== "Present");

        $render_markctrl = function ($sid, $cid) use ($existing_scores, $is_locked) {
            $existingVal = $existing_scores[$sid][$cid] ?? "";
            $hasValue = $existingVal !== "";
            $isChecked = $hasValue || !$is_locked ? "checked" : "";
            $gridDisplay = $hasValue || !$is_locked ? "block" : "none";
            $disabledAttr = $is_locked ? "disabled" : "";
            $toggleText = $isChecked ? "Dinilai" : "Abai";

            $html = "<div class='markctrl' id='markctrl_{$sid}_{$cid}' data-student='$sid' data-criteria='$cid'>";
            $html .= "<label class='pm-nilai-wrap'>";
            $html .= "<input type='checkbox' class='pm-nilai-checkbox' data-student='$sid' data-criteria='$cid' $isChecked $disabledAttr>";
            $html .= "<div class='pm-toggle-switch'></div>";
            $html .= "<span class='pm-toggle-label'>$toggleText</span>";
            $html .= "</label>";
            $html .= "<div class='keypad-wrapper' id='keypad_{$sid}_{$cid}' style='display:$gridDisplay;'>";
            $html .= "<input type='hidden' id='mark_{$sid}_{$cid}' name='marks[{$sid}][{$cid}]' value='$existingVal'>";
            $lockedClass = $is_locked ? "locked" : "";
            $html .= "<div class='pm-keypad $lockedClass'>";
            $keys = [1, 2, 3, 4, 5, 6, 7, 8, 9, "X", 0, 10];
            foreach ($keys as $k) {
                $val = $k === "X" ? "" : $k;
                $activeCls = $hasValue && (string) $existingVal === (string) $val && $k !== "X" ? "active" : "";
                $displayK = $k === "X" ? "✖" : $k;
                $btnClass = $k === "X" ? "pm-key-btn clear-btn" : "pm-key-btn";
                $html .= "<button type='button' class='$btnClass $activeCls' data-target='mark_{$sid}_{$cid}' data-val='$val' data-student='$sid' data-criteria='$cid' $disabledAttr>$displayK</button>";
            }
            $html .= "</div></div></div>"; // .pm-keypad, .keypad-wrapper, .markctrl
            return $html;
        };

        // NOTE: overflow is intentionally NOT hidden on .judge-card itself —
        // position:sticky only sticks within its nearest ancestor that clips
        // overflow, so an overflow:hidden wrapper here would trap the mobile
        // summary strip inside the card instead of letting it stick to the
        // viewport while the judge scrolls through student cards. The
        // desktop table keeps its own clipped/rounded corners via
        // #desktopMarkingTable below instead.
        echo "<div class='judge-card' style='padding: 0;'>";

        // ── Desktop table (unchanged layout/behavior from before) ──
        echo "<div id='desktopMarkingTable' style='overflow: hidden; border-radius: 6px;'>";
        echo "<div class='pm-table-wrap' style='border: none; margin: 0; border-radius: 0;'>";
        echo "<table class='pm-table marking-table'>";

        echo "<thead><tr><th class='sticky-col' rowspan='2' style='background: var(--c-surface-2); z-index: 15;'>Pelajar</th>";
        foreach ($criteria_by_test as $testName => $criteriaList) {
            $cnt = count($criteriaList);
            $testNameSafe = htmlspecialchars($testName);
            echo "<th colspan='$cnt' style='background: var(--c-red); color: #ffffff; text-align: center; border-bottom: 1px solid rgba(0,0,0,0.1);'>$testNameSafe</th>
          <th rowspan='2' data-test='$testNameSafe' style='background: var(--c-surface-3); color: var(--c-text); text-align: center;'>Jumlah $testNameSafe</th>";
        }
        echo "<th rowspan='2' style='background: var(--c-surface-3); color: var(--c-text); text-align: center;'>Jumlah Keseluruhan</th></tr>";

        echo "<tr>";
        foreach ($criteria_by_test as $criteriaList) {
            foreach ($criteriaList as $cid => $cname) {
                echo "<th>" . htmlspecialchars($cname) . "</th>";
            }
        }
        echo "</tr></thead><tbody>";

        foreach ($student_rows as $s) {
            $sid = $s["student_id"];
            $is_present = $s["status"] === "Present";

            if ($is_present) {
                echo "<tr data-student='$sid'>";
                echo "<td class='sticky-col'>" . htmlspecialchars($s["student_name"]) . "</td>";
                foreach ($criteria_by_test as $testName => $criteriaList) {
                    $testNameAttr = htmlspecialchars($testName);
                    foreach ($criteriaList as $cid => $cname) {
                        echo "<td class='mark-cell' id='desktopSlot_{$sid}_{$cid}' style='text-align: center;'>" . $render_markctrl($sid, $cid) . "</td>";
                    }
                    $maxTest = count($criteriaList) * 10;
                    echo "<td class='test-total' data-student='$sid' data-test='$testNameAttr'
                  style='background:var(--c-surface-2);color:var(--c-text);font-weight:700;text-align:center;'>0 / $maxTest</td>";
                }
                echo "<td class='overall-total' data-student='$sid'
      style='background:var(--c-surface-1);color:var(--c-text);font-weight:700;text-align:center;'>0 / 0</td>";
                echo "</tr>";
            } else {
                echo "<tr style='opacity:0.4;background:rgba(214,40,40,0.06);' title='Tidak Hadir'>";
                echo "<td class='sticky-col'>" . htmlspecialchars($s["student_name"]) . " <br><em style='color:var(--c-red);font-size:0.85em;'>(Tidak Hadir)</em></td>";
                foreach ($criteria_by_test as $testName => $criteriaList) {
                    foreach ($criteriaList as $c) {
                        echo "<td style='color:#666;text-align:center;'>—</td>";
                    }
                    echo "<td style='background:var(--c-surface-2);color:#666;text-align:center;'>—</td>";
                }
                echo "<td style='background:var(--c-surface-1);color:#666;text-align:center;'>—</td></tr>";
            }
        }
        echo "</tbody></table></div></div>"; // .marking-table, .pm-table-wrap, #desktopMarkingTable

        // ── Mobile/tablet ribbon (skeleton only — markctrl units get moved
        //    in here by JS when the viewport is narrow) ──
        echo "<div id='mobileMarkingUI'>";

        // Summary pills + Ujian tabs stick together as one unit right below
        // the site header while scrolling through student cards — wrapped
        // in a single sticky container rather than two independently-sticky
        // elements, so they stack cleanly without needing to measure either
        // one's height in JS.
        echo "<div class='sticky-marking-header'>";

        if (!empty($present_students)) {
            echo "<div class='marking-summary'>";
            foreach ($present_students as $s) {
                $sid = $s["student_id"];
                echo "<button type='button' class='summary-pill' data-student='$sid'>
                    <span class='summary-pill-name'>" . htmlspecialchars($s["student_name"]) . "</span>
                    <span class='overall-total' data-student='$sid'>0 / 0</span>
                </button>";
            }
            echo "</div>";
        }

        if (empty($criteria_by_test)) {
            echo "<div class='pm-alert pm-alert-warn' style='margin:16px;'>⚠️ Tiada ujian/kriteria ditetapkan untuk peringkat ini.</div>";
        } else {
            echo "<div class='ujian-tabs' role='tablist'>";
            $tabIndex = 0;
            foreach ($criteria_by_test as $testName => $criteriaList) {
                $activeCls = $tabIndex === 0 ? "active" : "";
                echo "<button type='button' class='ujian-tab-btn $activeCls' data-tab-index='$tabIndex'>" . htmlspecialchars($testName) . "</button>";
                $tabIndex++;
            }
            echo "</div>";
        }
        echo "</div>"; // .sticky-marking-header

        if (!empty($criteria_by_test)) {
            $tabIndex = 0;
            foreach ($criteria_by_test as $testName => $criteriaList) {
                $testNameAttr = htmlspecialchars($testName);
                $panelDisplay = $tabIndex === 0 ? "block" : "none";
                $maxTest = count($criteriaList) * 10;

                echo "<div class='ujian-tab-panel' data-tab-index='$tabIndex' style='display:$panelDisplay;'>";

                foreach ($present_students as $s) {
                    $sid = $s["student_id"];
                    echo "<div class='student-mark-card' data-student='$sid'>";

                    // Collapsed by default — tap to expand. Keeps a long
                    // roster scannable instead of every criteria row for
                    // every student being open and taking up screen at once.
                    echo "<button type='button' class='student-mark-card-header'>
                        <span class='student-mark-card-arrow'>▶</span>
                        <span class='student-mark-card-name'>" . htmlspecialchars($s["student_name"]) . "</span>
                        <span class='test-total' data-student='$sid' data-test='$testNameAttr'>0 / $maxTest</span>
                    </button>";

                    echo "<div class='student-mark-card-content' style='display:none;'>";
                    foreach ($criteriaList as $cid => $cname) {
                        echo "<div class='criteria-row'>";
                        echo "<div class='criteria-row-label'>" . htmlspecialchars($cname) . "</div>";
                        echo "<div class='markctrl-mount' id='mobileSlot_{$sid}_{$cid}'></div>";
                        echo "</div>"; // .criteria-row
                    }
                    echo "</div>"; // .student-mark-card-content

                    echo "</div>"; // .student-mark-card
                }

                echo "</div>"; // .ujian-tab-panel
                $tabIndex++;
            }
        }

        if (!empty($absent_students)) {
            echo "<div class='absent-students-list'>";
            echo "<div class='absent-students-title'>Tidak Hadir</div>";
            foreach ($absent_students as $s) {
                echo "<div class='absent-student-row'>" . htmlspecialchars($s["student_name"]) . "</div>";
            }
            echo "</div>";
        }

        echo "</div>"; // #mobileMarkingUI
        echo "</div>"; // .judge-card
            echo "<div style='margin-top: 20px; padding: 0 20px 20px 20px; display: flex; gap: 10px; align-items: center; flex-wrap: wrap;' class='mark-actions-row'>";

        if (!$is_locked) {
            // Buttons to show when actively marking or editing
            echo "<button type='submit' class='pm-btn pm-btn-primary mark-action-btn' style='padding: 8px 18px; font-size: 0.85rem;'>💾 Selesai Pemarkahan</button>";
            echo "<button type='button' class='pm-btn pm-btn-ghost mark-action-btn' style='padding: 8px 18px; font-size: 0.85rem;' onclick='pendingParams=[]; document.getElementById(\"pendingParamsContainer\").innerHTML=\"\"; const b=document.getElementById(\"pendingParamsBadge\"); if(b)b.remove(); window.location.href=\"judge.php\";'>Batal</button>";
        } else {
            // Button to show when the table is locked (View Only)
            echo "<button type='button' class='pm-btn pm-btn-ghost mark-action-btn' style='padding: 8px 18px; font-size: 0.85rem; background: var(--c-surface-2); color: var(--c-text); border: 1px solid var(--c-border-strong);' onclick='window.location.href=\"judge.php\";'>⬅ Kembali ke Dashboard</button>";
        }

        echo "</div>";
        echo "</form></div>";

        // ── CUSTOM MODALS HTML & CSS ──
        // Fetch levels for current session (scoped, not global)
        $modal_levels = [];
        if ($session_id) {
            $mlvl = $conn->prepare("SELECT level_id, level_name FROM levels WHERE session_id = ? ORDER BY level_name ASC");
            if ($mlvl) {
                $mlvl->bind_param("i", $session_id);
                $mlvl->execute();
                $mlvl_res = $mlvl->get_result();
                while ($ml = $mlvl_res->fetch_assoc()) {
                    $modal_levels[] = $ml;
                }
                $mlvl->close();
            }
        }

        echo "
        <style>
            .pm-modal-overlay {
                position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
                background: rgba(0,0,0,0.65); backdrop-filter: blur(3px);
                z-index: 9999; display: none; align-items: center; justify-content: center;
                opacity: 0; transition: opacity 0.18s ease;
            }
            .pm-modal-overlay.show { opacity: 1; }
            .pm-modal-box {
                background: var(--c-surface-1); border: 1px solid var(--c-border-strong);
                border-radius: 10px; width: 100%; max-width: 480px;
                box-shadow: 0 10px 36px rgba(0,0,0,0.55);
                transform: translateY(14px); transition: transform 0.18s ease;
                overflow: hidden;
            }
            .pm-modal-overlay.show .pm-modal-box { transform: translateY(0); }
            .pm-modal-header {
                display: flex; align-items: center; justify-content: space-between;
                padding: 12px 16px 11px;
                border-bottom: 1px solid var(--c-border-strong);
                background: var(--c-surface-2);
            }
            .pm-modal-title {
                font-family: 'Bebas Neue', sans-serif; font-size: 1.15rem;
                color: var(--c-white); letter-spacing: 0.06em;
                border-left: 3px solid var(--c-red); padding-left: 8px;
                line-height: 1.2;
            }
            .pm-modal-close-btn {
                background: none; border: none; color: var(--c-text-muted);
                font-size: 1.1rem; cursor: pointer; padding: 0 2px; line-height: 1;
                transition: color 0.15s;
            }
            .pm-modal-close-btn:hover { color: var(--c-red); }
            .pm-modal-body { padding: 14px 16px; }
            .pm-modal-grid {
                display: grid; grid-template-columns: 1fr 1fr; gap: 10px;
            }
            .pm-modal-field label {
                display: block; font-size: 0.68rem; font-weight: 700;
                text-transform: uppercase; letter-spacing: 0.08em;
                color: var(--c-text-muted); margin-bottom: 5px;
            }
            .pm-modal-field select {
                width: 100%; background: var(--c-surface-2);
                border: 1px solid var(--c-border-strong);
                border-radius: 6px; padding: 7px 10px;
                color: var(--c-text); font-size: 0.82rem;
                outline: none; transition: border-color 0.15s, box-shadow 0.15s;
                appearance: auto;
            }
            .pm-modal-field select:focus {
                border-color: var(--c-red);
                box-shadow: 0 0 0 2px var(--c-red-dim);
            }
            .pm-modal-field select:disabled {
                opacity: 0.45; cursor: not-allowed;
            }
            .pm-modal-hint {
                margin-top: 10px; font-size: 0.75rem; color: var(--c-text-muted);
                background: var(--c-surface-2); border-left: 2px solid #eab308;
                padding: 7px 10px; border-radius: 0 5px 5px 0;
            }
            .pm-modal-actions {
                display: flex; gap: 8px; justify-content: flex-end;
                padding: 10px 16px 12px; border-top: 1px solid var(--c-border-strong);
                background: var(--c-surface-2);
            }
            .pm-modal-actions .pm-btn {
                font-size: 0.78rem; padding: 6px 14px; border-radius: 5px;
            }
        </style>

        <div class='pm-modal-overlay' id='modal-parameter'>
            <div class='pm-modal-box'>
                <div class='pm-modal-header'>
                    <div class='pm-modal-title'>Tambah Peringkat &amp; Ujian</div>
                    <button type='button' class='pm-modal-close-btn' onclick='closeModal(\"modal-parameter\")' title='Tutup'>&times;</button>
                </div>
                <div class='pm-modal-body'>
                    <div class='pm-modal-grid'>
                        <div class='pm-modal-field'>
                            <label>1. Peringkat</label>
                            <select id='paramLevelSelect'>";
        foreach ($modal_levels as $ml) {
            echo "<option value='" . (int)$ml['level_id'] . "'>" . htmlspecialchars($ml['level_name']) . "</option>";
        }
        echo "              <option value='' disabled selected style='display:none'>-- Pilih Peringkat --</option>
                            </select>
                        </div>
                        <div class='pm-modal-field'>
                            <label>2. Ujian</label>
                            <select id='paramTestSelect' disabled>
                                <option value=''>-- Pilih Peringkat Dahulu --</option>
                            </select>
                        </div>
                        <div class='pm-modal-field' style='grid-column: 1 / -1;'>
                            <label>3. Kriteria Pemarkahan</label>
                            <select id='paramCriteriaSelect' disabled>
                                <option value=''>-- Pilih Ujian Dahulu --</option>
                            </select>
                        </div>
                    </div>
                    <div class='pm-modal-hint'>
                        ℹ️ Pilihan ini <b>tidak akan disimpan</b> ke pangkalan data sehingga anda klik <b>Selesai Pemarkahan</b>. Klik Batal pada bila-bila masa untuk membuang.
                    </div>
                </div>
                <div class='pm-modal-actions'>
                    <button type='button' class='pm-btn pm-btn-ghost' onclick='closeModal(\"modal-parameter\")'>Batal</button>
                    <button type='button' class='pm-btn pm-btn-primary' id='paramSaveBtn' onclick='submitNewParameter()'>Tambah ke Senarai</button>
                </div>
            </div>
        </div>";
    }
} ?>

<script>
    // Populate variables from PHP
    criteriaByTest = <?= json_encode($criteria_by_test ?? []) ?>;
    const testIdsMap = <?= json_encode($test_ids_map ?? []) ?>;
    const currentLevelId = <?= $level_id ?? 0 ?>;

    // --- RESPONSIVE MARKING LAYOUT ---
    // Each student×criteria checkbox+keypad+hidden-input ("markctrl") is
    // rendered exactly once, server-side, sitting inside the desktop
    // table's <td>. This relocates the SAME live node into the mobile
    // ribbon's slot when the viewport is narrow, and back into the table
    // when it's wide — never clones it, so there is only ever one input
    // per student×criteria and nothing can fall out of sync between the
    // two layouts. The breakpoint (1024px) matches the CSS media query
    // that shows/hides #desktopMarkingTable vs #mobileMarkingUI.
    function applyResponsiveMarkingLayout() {
        const isMobile = window.matchMedia('(max-width: 1024px)').matches;
        document.querySelectorAll('.markctrl').forEach(ctrl => {
            const { student, criteria } = ctrl.dataset;
            const targetId = isMobile
                ? `mobileSlot_${student}_${criteria}`
                : `desktopSlot_${student}_${criteria}`;
            const target = document.getElementById(targetId);
            if (target && ctrl.parentElement !== target) {
                target.appendChild(ctrl);
            }
        });
    }
    // --- STICKY HEADER HEIGHT (for the expanded student card header) ---
    // The summary-pills + Ujian-tabs sticky block's height isn't constant
    // (more students = taller), so it's measured here rather than guessed
    // in CSS, and exposed as --sticky-header-h for the expanded card
    // header's own `top` offset to stack cleanly underneath it.
    function updateStickyHeaderHeight() {
        const header = document.querySelector('.sticky-marking-header');
        if (!header) return;
        document.documentElement.style.setProperty('--sticky-header-h', header.offsetHeight + 'px');
    }

    function applyResponsiveLayoutAndMeasurements() {
        applyResponsiveMarkingLayout();
        updateStickyHeaderHeight();
    }
    applyResponsiveLayoutAndMeasurements();
    document.addEventListener('DOMContentLoaded', applyResponsiveLayoutAndMeasurements);
    let _respLayoutTimer;
    window.addEventListener('resize', function () {
        clearTimeout(_respLayoutTimer);
        _respLayoutTimer = setTimeout(applyResponsiveLayoutAndMeasurements, 150);
    });

    // --- UJIAN TAB/RIBBON SWITCHING ---
    // One panel visible at a time (accordion) — switching tabs never
    // scrolls sideways, it just swaps which vertical panel is shown.
    document.addEventListener('click', function (e) {
        if (!e.target.classList.contains('ujian-tab-btn')) return;
        const idx = e.target.dataset.tabIndex;

        document.querySelectorAll('.ujian-tab-btn').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.tabIndex === idx);
        });
        document.querySelectorAll('.ujian-tab-panel').forEach(panel => {
            panel.style.display = panel.dataset.tabIndex === idx ? 'block' : 'none';
        });

        // Scroll the newly-opened panel into view rather than leaving the
        // judge looking at wherever the page happened to be scrolled to.
        const openPanel = document.querySelector(`.ujian-tab-panel[data-tab-index="${idx}"]`);
        if (openPanel) openPanel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });

    // --- STUDENT CARD EXPAND/COLLAPSE (mobile/tablet ribbon) ---
    // Every student card starts collapsed — tap the header to expand just
    // that one student's criteria, keeping a long roster scannable instead
    // of showing every criteria row for every student all at once.
    function expandStudentCard(card) {
        const content = card.querySelector('.student-mark-card-content');
        const arrow = card.querySelector('.student-mark-card-arrow');
        if (!content) return;
        content.style.display = 'block';
        card.classList.add('expanded');
        if (arrow) arrow.textContent = '▼';
    }
    function collapseStudentCard(card) {
        const content = card.querySelector('.student-mark-card-content');
        const arrow = card.querySelector('.student-mark-card-arrow');
        if (!content) return;
        content.style.display = 'none';
        card.classList.remove('expanded');
        if (arrow) arrow.textContent = '▶';
    }

    document.addEventListener('click', function (e) {
        const header = e.target.closest('.student-mark-card-header');
        if (!header) return;
        const card = header.closest('.student-mark-card');
        if (!card) return;
        if (card.classList.contains('expanded')) {
            collapseStudentCard(card);
        } else {
            expandStudentCard(card);
        }
    });

    // --- SUMMARY PILLS AS PER-STUDENT QUICK-JUMP TABS ---
    // Clicking a student's name/total pill expands their card and scrolls
    // straight to it within whichever Ujian tab is currently open — a
    // second, finer-grained navigation layer on top of the Ujian tabs, so a
    // judge with a long student list doesn't have to hunt-and-scroll through
    // the whole panel.
    document.addEventListener('click', function (e) {
        const pill = e.target.closest('.summary-pill');
        if (!pill) return;
        const sid = pill.dataset.student;

        const activePanel = Array.from(document.querySelectorAll('.ujian-tab-panel'))
            .find(p => p.style.display !== 'none');
        if (!activePanel) return;

        const card = activePanel.querySelector(`.student-mark-card[data-student='${sid}']`);
        if (!card) return;

        expandStudentCard(card);
        card.scrollIntoView({ behavior: 'smooth', block: 'start' });
        card.classList.add('flash-highlight');
        setTimeout(() => card.classList.remove('flash-highlight'), 1100);
    });

    // --- SERVER-SIDE DRAFT AUTOSAVE ---
    // Persists each mark to the DB as submitted=0 so an accidental back-nav,
    // tab close, or crash doesn't lose in-progress marking. Debounced per
    // cell, with an immediate flush of any pending saves when the tab is
    // hidden/closed so nothing is lost to the debounce delay.
    const draftDebounce = {};
    const draftDirty = {};

    function queueDraftSave(studentId, criteriaId, value) {
        const key = studentId + '_' + criteriaId;
        draftDirty[key] = { studentId, criteriaId, value };
        clearTimeout(draftDebounce[key]);
        draftDebounce[key] = setTimeout(() => flushDraftSave(key), 500);
    }

    function flushDraftSave(key, useBeacon) {
        const entry = draftDirty[key];
        if (!entry) return;
        delete draftDirty[key];
        clearTimeout(draftDebounce[key]);

        const form = document.getElementById('markForm');
        if (!form) return;
        const body = new URLSearchParams({
            group_id: form.group_id.value,
            student_id: entry.studentId,
            criteria_id: entry.criteriaId,
            mark: entry.value,
            csrf_token: form.csrf_token.value
        });

        if (useBeacon && navigator.sendBeacon) {
            navigator.sendBeacon('save_draft_score.php', body);
        } else {
            fetch('save_draft_score.php', { method: 'POST', body, keepalive: true }).catch(() => {});
        }
    }

    function flushAllDrafts(useBeacon) {
        Object.keys(draftDirty).forEach(key => flushDraftSave(key, useBeacon));
    }

    document.addEventListener('visibilitychange', function () {
        if (document.visibilityState === 'hidden') flushAllDrafts(true);
    });
    window.addEventListener('pagehide', function () { flushAllDrafts(true); });

    // --- KEYPAD & TOGGLE LOGIC ---
    document.addEventListener('change', function (e) {
        // 1. Toggle "Dinilai / Abai" Switch
        if (e.target.classList.contains('pm-nilai-checkbox')) {
            const cb = e.target;
            const sid = cb.dataset.student;
            const cid = cb.dataset.criteria;
            const keypad = document.getElementById(`keypad_${sid}_${cid}`);
            const input = document.getElementById(`mark_${sid}_${cid}`);
            const label = cb.closest('.pm-nilai-wrap').querySelector('.pm-toggle-label');

            if (cb.checked) {
                label.innerHTML = 'Dinilai';
                keypad.style.display = 'block';
            } else {
                label.innerHTML = 'Abai';
                keypad.style.display = 'none';
                input.value = ''; // Clear mark
                document.querySelectorAll(`.pm-key-btn[data-target="mark_${sid}_${cid}"]`).forEach(k => k.classList.remove('active'));
                queueDraftSave(sid, cid, '');
            }
            updateTotals(sid);
        }
    });

    document.addEventListener('click', function (e) {
        // 2. Keypad Number Click (With Deselect Logic)
        if (e.target.classList.contains('pm-key-btn')) {
            if (e.target.disabled) return;
            const keyBtn = e.target;
            const targetId = keyBtn.dataset.target;
            const val = keyBtn.dataset.val;
            const input = document.getElementById(targetId);

            // Check if the button was already active BEFORE we strip classes
            const wasActive = keyBtn.classList.contains('active');

            // Remove active state from all siblings
            document.querySelectorAll(`.pm-key-btn[data-target="${targetId}"]`).forEach(k => k.classList.remove('active'));

            if (val === '') {
                // Clicked 'X' to clear
                input.value = '';
            } else if (wasActive) {
                // Clicked the already active number -> Deselect it
                input.value = '';
            } else {
                // Clicked a new number
                keyBtn.classList.add('active');
                input.value = val;
            }

            queueDraftSave(keyBtn.dataset.student, keyBtn.dataset.criteria, input.value);
            updateTotals(keyBtn.dataset.student);
        }
    });

    function updateTotals(studentId) {
        let overallSum = 0, overallMax = 0;
        for (const testName in criteriaByTest) {
            let testSum = 0, testMax = 0;
            Object.keys(criteriaByTest[testName]).forEach(cid => {
                const cb = document.querySelector(`.pm-nilai-checkbox[data-student='${studentId}'][data-criteria='${cid}']`);
                if (!cb || cb.checked) {
                    testMax += 10;
                    const inp = document.getElementById(`mark_${studentId}_${cid}`);
                    if (inp && inp.value !== '') {
                        testSum += parseInt(inp.value);
                    }
                }
            });
            // Both the desktop table AND the mobile summary/card render their
            // own .test-total / .overall-total element for the same student —
            // update every instance (querySelectorAll), not just the first
            // one found in the DOM, otherwise whichever layout is currently
            // hidden gets updated while the visible one stays stuck at 0/0.
            document.querySelectorAll(`.test-total[data-student='${studentId}'][data-test='${testName}']`).forEach(cell => {
                cell.innerHTML = `${testSum} / ${testMax}`;
            });
            overallSum += testSum; overallMax += testMax;
        }
        document.querySelectorAll(`.overall-total[data-student='${studentId}']`).forEach(oCell => {
            oCell.innerHTML = `${overallSum} / ${overallMax}`;
        });
    }

    // --- DRAFT PROTECTION SYSTEM ---
    function saveDraftMarks() {
        const drafts = {};
        document.querySelectorAll('input[type="hidden"][name^="marks["]').forEach(inp => {
            if (inp.value !== '') drafts[inp.id] = inp.value;
        });

        const toggles = {};
        document.querySelectorAll('.pm-nilai-checkbox').forEach(cb => {
            toggles[cb.dataset.student + '_' + cb.dataset.criteria] = cb.checked;
        });

        sessionStorage.setItem('pm_draft_marks', JSON.stringify(drafts));
        sessionStorage.setItem('pm_draft_toggles', JSON.stringify(toggles));
    }

    function restoreDraftMarks() {
        const draftsStr = sessionStorage.getItem('pm_draft_marks');
        const togglesStr = sessionStorage.getItem('pm_draft_toggles');

        if (togglesStr) {
            const toggles = JSON.parse(togglesStr);
            for (const key in toggles) {
                const cb = document.querySelector(`.pm-nilai-checkbox[data-student="${key.split('_')[0]}"][data-criteria="${key.split('_')[1]}"]`);
                const keypad = document.getElementById('keypad_' + key);
                if (cb && keypad) {
                    const label = cb.closest('.pm-nilai-wrap').querySelector('.pm-toggle-label');
                    cb.checked = toggles[key];
                    if (cb.checked) {
                        label.innerHTML = 'Dinilai'; keypad.style.display = 'block';
                    } else {
                        label.innerHTML = 'Abai'; keypad.style.display = 'none';
                    }
                }
            }
            sessionStorage.removeItem('pm_draft_toggles');
        }

        if (draftsStr) {
            const drafts = JSON.parse(draftsStr);
            for (const id in drafts) {
                const inp = document.getElementById(id);
                if (inp) {
                    inp.value = drafts[id];
                    const btn = document.querySelector(`.pm-key-btn[data-target="${id}"][data-val="${drafts[id]}"]`);
                    if (btn) btn.classList.add('active');
                }
            }
            sessionStorage.removeItem('pm_draft_marks');
        }
    }

        // --- PARAMETER MODAL: DEFERRED ADD LOGIC ---
        // Nothing is written to the DB until the judge clicks "Selesai Pemarkahan".
        // The modal only queues the (test, criteria) pair in memory and
        // injects hidden inputs into markForm so save_scores.php can persist
        // them atomically alongside the actual marks.

        let pendingParams = []; // [{levelId, testId, testName, criteriaId, criteriaName}]

        function openParameterModal() {
            const modal = document.getElementById('modal-parameter');
            modal.style.display = 'flex';
            setTimeout(() => modal.classList.add('show'), 10);

            const lvlSel  = document.getElementById('paramLevelSelect');
            const testSel = document.getElementById('paramTestSelect');
            const critSel = document.getElementById('paramCriteriaSelect');

            lvlSel.value = '';
            testSel.innerHTML = '<option value="">-- Pilih Peringkat Dahulu --</option>';
            testSel.disabled = true;
            critSel.innerHTML = '<option value="">-- Pilih Ujian Dahulu --</option>';
            critSel.disabled = true;

            const saveBtn = document.getElementById('paramSaveBtn');
            saveBtn.innerHTML = 'Tambah ke Senarai';
            saveBtn.disabled = false;
        }

        // Cascade: Peringkat → Ujian
        document.getElementById('paramLevelSelect')?.addEventListener('change', function() {
            const levelId = this.value;
            const testSel = document.getElementById('paramTestSelect');
            const critSel = document.getElementById('paramCriteriaSelect');

            testSel.innerHTML = '<option value="">Memuatkan...</option>';
            testSel.disabled = true;
            critSel.innerHTML = '<option value="">-- Pilih Ujian Dahulu --</option>';
            critSel.disabled = true;

            if (!levelId) {
                testSel.innerHTML = '<option value="">-- Pilih Peringkat Dahulu --</option>';
                return;
            }
            fetch('judge.php?ajax_modal_tests=1&level_id=' + encodeURIComponent(levelId))
                .then(r => r.json())
                .then(data => {
                    testSel.innerHTML = '<option value="" disabled selected>-- Pilih Ujian --</option>';
                    data.forEach(t => {
                        const opt = document.createElement('option');
                        opt.value = t.id;
                        opt.textContent = t.name;
                        testSel.appendChild(opt);
                    });
                    testSel.disabled = data.length === 0;
                    if (data.length === 0) testSel.innerHTML = '<option value="">Tiada ujian untuk peringkat ini</option>';
                });
        });

        // Cascade: Ujian → Kriteria
        document.getElementById('paramTestSelect')?.addEventListener('change', function() {
            const testId = this.value;
            const critSel = document.getElementById('paramCriteriaSelect');

            critSel.innerHTML = '<option value="">Memuatkan...</option>';
            critSel.disabled = true;

            if (!testId) {
                critSel.innerHTML = '<option value="">-- Pilih Ujian Dahulu --</option>';
                return;
            }
            fetch('judge.php?ajax_modal_criteria=1&test_id=' + encodeURIComponent(testId))
                .then(r => r.json())
                .then(data => {
                    critSel.innerHTML = '<option value="" disabled selected>-- Pilih Kriteria --</option>';
                    data.forEach(c => {
                        const opt = document.createElement('option');
                        opt.value = c.id;
                        opt.textContent = c.name;
                        critSel.appendChild(opt);
                    });
                    critSel.disabled = data.length === 0;
                    if (data.length === 0) critSel.innerHTML = '<option value="">Tiada kriteria untuk ujian ini</option>';
                });
        });

        function closeModal(id) {
            const modal = document.getElementById(id);
            modal.classList.remove('show');
            setTimeout(() => modal.style.display = 'none', 200);
        }

        function submitNewParameter() {
            const lvlSel  = document.getElementById('paramLevelSelect');
            const testSel = document.getElementById('paramTestSelect');
            const critSel = document.getElementById('paramCriteriaSelect');

            const levelId   = lvlSel.value;
            const testId    = testSel.value;
            const criteriaId = critSel.value;

            if (!levelId || !testId || !criteriaId) {
                alert("Sila pilih Peringkat, Ujian, dan Kriteria terlebih dahulu.");
                return;
            }

            const testName     = testSel.options[testSel.selectedIndex].text;
            const criteriaName = critSel.options[critSel.selectedIndex].text;

            // Guard: don't add the same combo twice
            const alreadyQueued = pendingParams.some(
                p => p.testId == testId && p.criteriaId == criteriaId
            );
            if (alreadyQueued) {
                alert("Kombinasi ujian dan kriteria ini sudah ditambah.");
                return;
            }

            // Queue it — nothing touches the DB yet
            const param = { levelId, testId, testName, criteriaId, criteriaName };
            pendingParams.push(param);

            // Inject a hidden input into markForm so save_scores.php gets it on submit
            const container = document.getElementById('pendingParamsContainer');
            const inp = document.createElement('input');
            inp.type  = 'hidden';
            inp.name  = 'pending_params[]';
            inp.value = JSON.stringify({ levelId, testId, testName, criteriaId, criteriaName });
            container.appendChild(inp);

            // Show a pending badge so the judge knows what's queued
            refreshPendingBadge();

            closeModal('modal-parameter');
        }

        function refreshPendingBadge() {
            let badge = document.getElementById('pendingParamsBadge');
            if (pendingParams.length === 0) {
                if (badge) badge.remove();
                return;
            }
            if (!badge) {
                badge = document.createElement('div');
                badge.id = 'pendingParamsBadge';
                badge.style.cssText = 'margin-top:10px; padding:8px 12px; background:rgba(234,179,8,0.12); border-left:3px solid #eab308; border-radius:0 6px 6px 0; font-size:0.78rem; color:#b45309;';
                // Insert above the marking table (inside judge-card, before pm-table-wrap)
                const markCard = document.querySelector('#markForm .judge-card');
                if (markCard) markCard.insertBefore(badge, markCard.firstChild);
            }
            const lines = pendingParams.map(p =>
                `• <b>${p.testName}</b> → ${p.criteriaName}`
            ).join('<br>');
            badge.innerHTML = `⏳ <b>${pendingParams.length} parameter tertangguh</b> — akan disimpan apabila anda klik "Selesai Pemarkahan":<br>${lines}<br><span style="font-size:0.72rem;color:#92400e;">Klik Batal untuk membuang semuanya.</span>`;
        }

    // Initialize Page
    document.addEventListener('DOMContentLoaded', function () {
        const pos = localStorage.getItem('judge_scroll_pos');
        if (pos) { window.scrollTo(0, parseInt(pos)); localStorage.removeItem('judge_scroll_pos'); }
        document.querySelectorAll('form').forEach(f => {
            f.addEventListener('submit', () => localStorage.setItem('judge_scroll_pos', window.scrollY));
        });

        restoreDraftMarks(); // Restore marks if a criteria was just added!

        const students = [...new Set(Array.from(document.querySelectorAll('.pm-key-btn')).map(b => b.dataset.student))];
        students.forEach(id => updateTotals(id));
        
        // Guarantee all accordions start collapsed
        document.querySelectorAll('.pm-accordion-content').forEach(c => c.style.display = 'none');
        document.querySelectorAll('.pm-accordion-arrow').forEach(a => a.style.transform = 'rotate(0deg)');
        document.querySelectorAll('.pm-accordion-header').forEach(h => h.classList.remove('active'));
    });
</script>

</main>
</body>

</html>