<?php
/**
 * auth_check.php — shared idle-timeout enforcement.
 * Include immediately after session_start() on every authenticated page.
 * (Previously this logic only lived in login.php and never ran again
 * after a user was authenticated, so sessions never actually expired.)
 */

$idle_timeout = 900; // 15 minutes
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $idle_timeout)) {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit();
}
$_SESSION['last_activity'] = time();
