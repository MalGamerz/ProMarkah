<?php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);

session_start();
require __DIR__ . '/auth_check.php';
include 'db.php';
$conn = getDB();

if (!isset($_SESSION['role']) || !in_array($_SESSION['role'], ['judge', 'pic'])) {
    header("Location: login.php");
    exit();
}

$pm_page = 'leaderboard';
include 'layout.php';
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.28/jspdf.plugin.autotable.min.js"></script>

<style>
    /* ── SELECT2 — compact, matches Export Excel button height ── */
    .select2-container .select2-selection--single {
        background: var(--c-surface-2) !important;
        border: 1px solid var(--c-border-strong) !important;
        border-radius: 6px !important;
        height: 36px !important;
        transition: border-color 0.2s;
    }
    .select2-container--default .select2-selection--single:focus,
    .select2-container--default .select2-selection--single:active {
        border-color: var(--c-red) !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__rendered {
        color: var(--c-text) !important;
        line-height: 34px !important;
        padding-left: 10px !important;
        font-size: 0.82rem !important;
    }
    .select2-container--default .select2-selection--single .select2-selection__arrow {
        height: 34px !important;
    }
    .select2-dropdown {
        background: var(--c-surface-1) !important;
        border: 1px solid var(--c-border-strong) !important;
        box-shadow: 0 8px 24px rgba(0,0,0,.15);
    }
    .select2-results__option {
        color: var(--c-text) !important;
        font-size: 0.82rem;
    }
    .select2-results__option--highlighted {
        background: var(--c-red) !important;
        color: #fff !important;
    }
    .select2-search__field {
        background: var(--c-surface-0) !important;
        color: var(--c-text) !important;
        border: 1px solid var(--c-border-strong) !important;
        border-radius: 4px;
        font-size: 0.82rem !important;
    }
    .select2-search__field::placeholder { color: var(--c-text-faint) !important; }
    .filter-bar .select2-container { width: 100% !important; }

    /* ── FILTER BAR ── */
    .filter-bar {
        display: flex;
        flex-wrap: nowrap; /* Forces a single line */
        gap: 8px; /* Tighter gap to save horizontal space */
        align-items: flex-end;
        overflow-x: auto; /* Allows smooth swipe on smaller laptops without breaking */
        padding-bottom: 4px; /* Room for focus rings */
    }
    .filter-bar::-webkit-scrollbar { height: 4px; }
    .filter-bar::-webkit-scrollbar-thumb { background: var(--c-border-strong); border-radius: 4px; }

    .filter-col {
        flex: 1 1 10%; /* Allows aggressive shrinking */
        display: flex;
        flex-direction: column;
        gap: 4px;
        min-width: 110px; /* Prevents Select2 from getting completely crushed */
    }
    
    /* EXPORT BUTTONS COLUMN */
    .filter-col.export-col {
        flex: 0 0 auto;
        display: flex;
        flex-direction: row; 
        align-items: flex-end;
        gap: 4px; /* Tighter button gap */
        margin-bottom: 0;
    }

    .filter-label {
        font-size: 0.65rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--c-text-faint);
        white-space: nowrap;
    }
    
    /* Export button */
    .btn-export {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        height: 36px; 
        padding: 0 8px; /* Reduced padding */
        color: #ffffff !important;
        border-radius: 4px;
        font-size: 0.75rem; /* Smaller font to fit everything */
        font-weight: 700;
        letter-spacing: 0.02em;
        font-family: 'DM Sans', sans-serif;
        cursor: pointer;
        text-decoration: none;
        white-space: nowrap;
        transition: all 0.2s ease-in-out;
    }
    
    .btn-export:hover { 
        filter: brightness(0.9);
        transform: translateY(-1px);
    }

    .medal-cell {
        font-size: 1.15rem;
        font-weight: bold;
        text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5);
    }
    .gold-row   { background: rgba(255,215,0,  0.10) !important; border-left: 4px solid #ffd700; }
    .silver-row { background: rgba(192,192,192,0.08) !important; border-left: 4px solid #c0c0c0; }
    .bronze-row { background: rgba(205,127,50, 0.10) !important; border-left: 4px solid #cd7f32; }
    .gold-row:hover   { background: rgba(255,215,0,  0.18) !important; }
    .silver-row:hover { background: rgba(192,192,192,0.15) !important; }
    .bronze-row:hover { background: rgba(205,127,50, 0.18) !important; }

    .quota-badge {
        display: inline-block;
        font-size: 0.68rem;
        font-family: 'DM Mono', monospace;
        font-weight: 600;
        letter-spacing: 0.04em;
        padding: 2px 7px;
        border-radius: 10px;
        vertical-align: middle;
        margin-left: 6px;
    }
    .quota-badge.school  { background: rgba(99,179,237,0.18);  color: #63b3ed;         border: 1px solid rgba(99,179,237,0.35); }
    .quota-badge.level   { background: rgba(214,40,40,0.15);   color: var(--c-red);    border: 1px solid rgba(214,40,40,0.3); }
    .quota-badge.session { background: rgba(154,230,180,0.15); color: #68d391;         border: 1px solid rgba(104,211,145,0.3); }
    .quota-badge.overall { background: rgba(183,148,244,0.15); color: #b794f4;         border: 1px solid rgba(183,148,244,0.3); }
    .quota-badge.auto    { background: rgba(160,160,160,0.12); color: var(--c-text-faint); border: 1px solid var(--c-border); }

    .pm-table-wrap {
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        width: 100%;
    }
    .pm-table { min-width: 900px; }
    .pm-table th,
    .pm-table td {
        white-space: nowrap;
        padding: 12px 18px !important;
        text-transform: uppercase; 
    }

    /* ── IMPROVED RESPONSIVENESS ── */
    @media (max-width: 1200px) {
        .filter-bar { flex-wrap: wrap; overflow-x: visible; }
        .filter-col { flex: 1 1 calc(25% - 8px); }
        .filter-col.export-col { width: 100%; justify-content: flex-end; margin-top: 8px; }
    }
    @media (max-width: 768px) {
        .filter-col { flex: 1 1 calc(33.333% - 8px); }
    }
    @media (max-width: 480px) {
        .filter-col { flex: 1 1 100%; }
        .filter-col.export-col { flex-direction: column; width: 100%; align-items: stretch; }
        .btn-export { width: 100%; }
    }
</style>

<h2 class="pm-page-heading">🏆 Papan Kedudukan Keseluruhan</h2>

<div class="pm-card" style="margin-bottom: 20px;">
    <div class="filter-bar">
        <div class="filter-col">
            <label class="filter-label">Tahun</label>
            <select id="filter-year" class="lb-filter"><option value="">Semua Tahun</option></select>
        </div>
        <div class="filter-col">
            <label class="filter-label">Siri</label>
            <select id="filter-siri" class="lb-filter"><option value="">Semua Siri</option></select>
        </div>
        <div class="filter-col">
            <label class="filter-label">Sidang</label>
            <select id="filter-session" class="lb-filter"><option value="">Semua Sidang</option></select>
        </div>
        <div class="filter-col">
            <label class="filter-label">Tahap</label>
            <select id="filter-level" class="lb-filter"><option value="">Semua Tahap</option></select>
        </div>
        <div class="filter-col">
            <label class="filter-label">Cawangan</label>
            <select id="filter-school" class="lb-filter"><option value="">Semua Cawangan</option></select>
        </div>
        <div class="filter-col">
            <label class="filter-label">Juri</label>
            <select id="filter-judge" class="lb-filter"><option value="">Semua Juri</option></select>
        </div>
        <div class="filter-col">
            <label class="filter-label">Pingat</label>
            <select id="filter-medal" class="lb-filter">
                <option value="">Semua Pingat</option>
                <option>🥇 Emas</option>
                <option>🥈 Perak</option>
                <option>🥉 Gangsa</option>
            </select>
        </div>
        
        <div class="filter-col export-col">
            <button onclick="exportToExcel()" class="btn-export" style="background: #10b981; border: 1px solid #059669;">📥 Excel</button>
            <button onclick="exportToPDF('landscape')" class="btn-export" style="background: #b91c1c; border: 1px solid #991b1b;">📄 PDF (L)</button>
            <button onclick="exportToPDF('portrait')" class="btn-export" style="background: #991b1b; border: 1px solid #7f1d1d;">📄 PDF (P)</button>
        </div>
    </div>
</div>

<?php
// ══════════════════════════════════════════════════════════════════
// 1.  Load ALL quota tables in parallel
// ══════════════════════════════════════════════════════════════════

// a) Per-level quotas  (existing table)
$quotas_level = [];
$r = $conn->query("SELECT level_id, gold_quota, silver_quota, bronze_quota FROM medal_quotas WHERE level_id != 0");
if ($r) while ($row = $r->fetch_assoc())
    $quotas_level[$row['level_id']] = [(int)$row['gold_quota'], (int)$row['silver_quota'], (int)$row['bronze_quota']];

// b) Per-session quotas
$quotas_session = [];
$r = $conn->query("SELECT session_id, gold_quota, silver_quota, bronze_quota FROM medal_quotas_session");
if ($r) while ($row = $r->fetch_assoc())
    $quotas_session[$row['session_id']] = [(int)$row['gold_quota'], (int)$row['silver_quota'], (int)$row['bronze_quota']];

// c) Per-school quotas
$quotas_school = [];
$r = $conn->query("SELECT school_id, gold_quota, silver_quota, bronze_quota FROM medal_quotas_school");
if ($r) while ($row = $r->fetch_assoc())
    $quotas_school[$row['school_id']] = [(int)$row['gold_quota'], (int)$row['silver_quota'], (int)$row['bronze_quota']];

// d) Global / overall quota  (stored as level_id = 0 sentinel)
$quota_overall = [0, 0, 0];
$r = $conn->query("SELECT gold_quota, silver_quota, bronze_quota FROM medal_quotas WHERE level_id = 0");
if ($r && $row = $r->fetch_assoc())
    $quota_overall = [(int)$row['gold_quota'], (int)$row['silver_quota'], (int)$row['bronze_quota']];

// ══════════════════════════════════════════════════════════════════
// 2.  Resolve quota for a student with priority cascade
// ══════════════════════════════════════════════════════════════════
function resolve_quota(int $school_id, int $level_id, int $session_id, int $total,
                       array $qs_school, array $qs_level, array $qs_session, array $q_overall): array
{
    $build = function(array $q, string $label) {
        return [$q[0], $q[0] + $q[1], $label];
    };

    if (isset($qs_school[$school_id]) && ($qs_school[$school_id][0] || $qs_school[$school_id][1]))
        return $build($qs_school[$school_id], 'school');

    if (isset($qs_level[$level_id]) && ($qs_level[$level_id][0] || $qs_level[$level_id][1]))
        return $build($qs_level[$level_id], 'level');

    if (isset($qs_session[$session_id]) && ($qs_session[$session_id][0] || $qs_session[$session_id][1]))
        return $build($qs_session[$session_id], 'session');

    if ($q_overall[0] || $q_overall[1])
        return $build($q_overall, 'overall');

    $g = (int)ceil($total * 0.40);
    $s = $g + (int)ceil($total * 0.30);
    return [$g, $s, 'auto'];
}

// ══════════════════════════════════════════════════════════════════
// 3.  Main data query (Includes Siri Table Join)
// ══════════════════════════════════════════════════════════════════
$sql = "
    SELECT st.student_id, st.student_name, st.year, st.level_id,
           sc.school_id, sc.school_name,
           j.name AS judge_name,
           se.session_id, se.session_name,
           sr.siri_name,
           l.level_name,
           SUM(s.mark)           AS total_score,
           SUM(c.max_mark)       AS max_score,
           ROUND((SUM(s.mark)/SUM(c.max_mark))*100, 2) AS percentage
    FROM scores s
    JOIN criteria c        ON s.criteria_id   = c.criteria_id
    JOIN students st       ON s.student_id     = st.student_id
    JOIN schools sc        ON st.school_id     = sc.school_id
    JOIN levels l          ON st.level_id      = l.level_id
    JOIN sessions se       ON l.session_id     = se.session_id
    LEFT JOIN siri sr      ON se.siri_id       = sr.siri_id
    JOIN group_students gs ON st.student_id    = gs.student_id
    JOIN `groups` g      ON gs.group_id      = g.group_id
    LEFT JOIN judges j     ON g.judge_id       = j.id
    WHERE s.submitted = 1
    GROUP BY st.student_id, j.name, se.session_id, se.session_name, sr.siri_name, l.level_name, st.level_id
    HAVING total_score > 0
    ORDER BY st.level_id ASC, percentage DESC
";

$result = $conn->query($sql);
$leaderboard_data = [];

if ($result && $result->num_rows > 0) {

    // First pass — collect all rows and count per level
    $all_rows = [];
    $students_per_level = [];
    while ($row = $result->fetch_assoc()) {
        $all_rows[] = $row;
        $lid = $row['level_id'];
        $students_per_level[$lid] = ($students_per_level[$lid] ?? 0) + 1;
    }

    // Per-student, per-test subtotal marks (ordered alphabetically by test_name)
    // — used to break ties between students with the same overall percentage.
    $student_test_scores = [];
    $tie_sql = "
        SELECT s.student_id, t.test_name, SUM(s.mark) AS test_score
        FROM scores s
        JOIN criteria c ON s.criteria_id = c.criteria_id
        JOIN tests t    ON c.test_id     = t.test_id
        WHERE s.submitted = 1
        GROUP BY s.student_id, t.test_id, t.test_name
        ORDER BY t.test_name ASC
    ";
    $tie_result = $conn->query($tie_sql);
    if ($tie_result) {
        while ($trow = $tie_result->fetch_assoc()) {
            $student_test_scores[$trow['student_id']][] = (float) $trow['test_score'];
        }
    }

    // Rank students within each level: overall percentage DESC, then tie-break
    // by comparing test scores in order (ujian pertama, kedua, ...) until a
    // difference is found — the student with the higher mark ranks above.
    usort($all_rows, function ($a, $b) use ($student_test_scores) {
        if ($a['level_id'] != $b['level_id']) {
            return $a['level_id'] <=> $b['level_id'];
        }
        if ($a['percentage'] != $b['percentage']) {
            return $b['percentage'] <=> $a['percentage'];
        }
        $ta = $student_test_scores[$a['student_id']] ?? [];
        $tb = $student_test_scores[$b['student_id']] ?? [];
        $n  = max(count($ta), count($tb));
        for ($i = 0; $i < $n; $i++) {
            $va = $ta[$i] ?? 0;
            $vb = $tb[$i] ?? 0;
            if ($va != $vb) {
                return $vb <=> $va;
            }
        }
        return 0;
    });

    // Second pass — assign medals using priority cascade
    $current_level  = null;
    $rank           = 1;
    $gold_limit     = 0;
    $silver_limit   = 0;
    $quota_source   = 'auto';

    foreach ($all_rows as $row) {
        $lid = $row['level_id'];
        $sid = $row['session_id'];
        $scid = $row['school_id'];

        if ($current_level !== $lid) {
            $current_level = $lid;
            $rank = 1;
            $total = $students_per_level[$lid];
            [$gold_limit, $silver_limit, $quota_source] = resolve_quota(
                $scid, $lid, $sid, $total,
                $quotas_school, $quotas_level, $quotas_session, $quota_overall
            );
        }

        if ($quota_source !== 'school' && isset($quotas_school[$scid])
            && ($quotas_school[$scid][0] || $quotas_school[$scid][1])) {
            [$gold_limit, $silver_limit, $quota_source] = resolve_quota(
                $scid, $lid, $sid, $students_per_level[$lid],
                $quotas_school, $quotas_level, $quotas_session, $quota_overall
            );
        }

        if ($rank <= $gold_limit)        { $medal = "🥇 Emas"; }
        elseif ($rank <= $silver_limit)  { $medal = "🥈 Perak"; }
        else                             { $medal = "🥉 Gangsa"; }

        $leaderboard_data[] = [
            'year'         => $row['year'],
            'siri'         => $row['siri_name'] ?? 'Tiada Siri', // Pushed into JS array
            'session'      => $row['session_name'],
            'level'        => $row['level_name'],
            'student'      => $row['student_name'],
            'school'       => $row['school_name'],
            'judge'        => $row['judge_name'],
            'total'        => $row['total_score'],
            'max'          => $row['max_score'],
            'percentage'   => $row['percentage'],
            'medal'        => $medal,
            'quota_source' => $quota_source,
        ];

        $rank++;
    }
}

echo "<script>let leaderboardData = " . json_encode($leaderboard_data) . ";</script>";
?>

<div id="leaderboard-tables"></div>

<script>
    function escapeHtml(str) {
        return String(str ?? '').replace(/[&<>"']/g, function(c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    // ── Quota source badge labels ──────────────────────────────────
    const quotaBadge = {
        school:  '<span class="quota-badge school"  title="Kuota ditetapkan mengikut sekolah">🏫 Sekolah</span>',
        level:   '<span class="quota-badge level"   title="Kuota ditetapkan mengikut peringkat">🏆 Peringkat</span>',
        session: '<span class="quota-badge session" title="Kuota ditetapkan mengikut sidang">📅 Sidang</span>',
        overall: '<span class="quota-badge overall" title="Kuota global keseluruhan">🌐 Global</span>',
        auto:    '' 
    };

    // ── Populate filter dropdowns ──────────────────────────────────
    let years    = [...new Set(leaderboardData.map(d => d.year))].filter(Boolean).sort().reverse();
    let siris    = [...new Set(leaderboardData.map(d => d.siri))].filter(Boolean).sort();
    let sessions = [...new Set(leaderboardData.map(d => d.session))].filter(Boolean).sort();
    let levels   = [...new Set(leaderboardData.map(d => d.level))].filter(Boolean).sort();
    let schools  = [...new Set(leaderboardData.map(d => d.school))].filter(Boolean).sort();
    let judges   = [...new Set(leaderboardData.map(d => d.judge))].filter(Boolean).sort();

    years.forEach(y    => document.getElementById('filter-year').innerHTML    += `<option value="${escapeHtml(y)}">${escapeHtml(y)}</option>`);
    siris.forEach(s    => document.getElementById('filter-siri').innerHTML    += `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`);
    sessions.forEach(s => document.getElementById('filter-session').innerHTML += `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`);
    levels.forEach(l   => document.getElementById('filter-level').innerHTML   += `<option value="${escapeHtml(l)}">${escapeHtml(l)}</option>`);
    schools.forEach(s  => document.getElementById('filter-school').innerHTML  += `<option value="${escapeHtml(s)}">${escapeHtml(s)}</option>`);
    judges.forEach(j   => document.getElementById('filter-judge').innerHTML   += `<option value="${escapeHtml(j)}">${escapeHtml(j)}</option>`);

    // ── Init Select2 then wire instant filtering ───────────────────
    $(function() {
        $('.lb-filter').select2({ width: '100%' });
        $('.lb-filter').on('change', applyFilters);
        applyFilters();
    });

    // ── Main render ───────────────────────────────────────────────
    function applyFilters() {
        const fy    = document.getElementById('filter-year').value.toLowerCase();
        const fsiri = document.getElementById('filter-siri').value.toLowerCase();
        const fs    = document.getElementById('filter-session').value.toLowerCase();
        const fl    = document.getElementById('filter-level').value.toLowerCase();
        const fsch  = document.getElementById('filter-school').value.toLowerCase();
        const fj    = document.getElementById('filter-judge').value.toLowerCase();
        const fm    = document.getElementById('filter-medal').value.toLowerCase();

        const filtered = leaderboardData.filter(d =>
            (fy    === '' || String(d.year).toLowerCase() === fy) &&
            (fsiri === '' || d.siri.toLowerCase() === fsiri) &&
            (fs    === '' || d.session.toLowerCase() === fs) &&
            (fl    === '' || d.level.toLowerCase()   === fl) &&
            (fsch  === '' || d.school.toLowerCase()  === fsch) &&
            (fj    === '' || d.judge.toLowerCase()   === fj) &&
            (fm    === '' || d.medal.toLowerCase()   === fm)
        );

        filtered.sort((a, b) => b.percentage - a.percentage);

        // Group by level for showing quota source badge per level header
        const levelSources = {};
        filtered.forEach(d => { if (!levelSources[d.level]) levelSources[d.level] = d.quota_source; });

        let html = `
        <div class="pm-card" style="padding:0; overflow:hidden;">
            <div style="padding:16px 22px; display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid var(--c-border);">
                <h3 style="margin:0; font-family:'Bebas Neue',sans-serif; font-size:1.5rem; letter-spacing:0.05em; color:var(--c-white);">Senarai Keputusan</h3>
                <span style="color:#fff; font-weight:600; background:var(--c-red); padding:4px 12px; border-radius:20px; font-size:0.85rem; box-shadow:0 2px 8px rgba(214,40,40,0.4);">${filtered.length} Rekod</span>
            </div>
            <div class="pm-table-wrap" style="border:none; border-radius:0;">
                <table class="pm-table" id="lbTable">
                    <thead>
                        <tr>
                            <th style="width:60px; text-align:center;">Rank</th>
                            <th style="white-space: nowrap;">Nama Pesilat</th>
                            <th>Tahun</th>
                            <th>Siri</th>
                            <th>Cawangan</th>
                            <th>Sidang</th>
                            <th style="white-space: nowrap;">Tahap</th>
                            <th>Juri</th>
                            <th style="text-align:center; white-space: nowrap;">Markah</th>
                            <th style="text-align:center; white-space: nowrap;">Peratus</th>
                            <th style="text-align:center; white-space: nowrap;">Pingat</th>
                        </tr>
                    </thead>
                    <tbody>`;

        if (filtered.length === 0) {
            html += `<tr><td colspan="11"><div class="pm-empty-state">
                <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                <path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
                <p>Tiada rekod ditemui untuk tapisan ini.</p></div></td></tr>`;
        } else {
            filtered.forEach((s, i) => {
                const src = levelSources[s.level] || 'auto';
                const badge = quotaBadge[src] || '';
                const rowClass = s.medal.includes('Emas') ? 'gold-row' : s.medal.includes('Perak') ? 'silver-row' : 'bronze-row';
                
                html += `
                <tr class="${rowClass}">
                    <td style="text-align:center; font-weight:bold; color:var(--c-text-faint);">${i + 1}</td>
                    <td style="font-weight:600; color:var(--c-text); white-space: nowrap;">${escapeHtml(s.student)}</td>
                    <td style="color:var(--c-text-muted);">${escapeHtml(s.year)}</td>
                    <td style="color:var(--c-text); white-space: nowrap;">${escapeHtml(s.siri)}</td>
                    <td style="color:var(--c-text); white-space: nowrap;">${escapeHtml(s.school)}</td>
                    <td style="color:var(--c-text); white-space: nowrap;">${escapeHtml(s.session)}</td>

                    <td style="color:var(--c-text); white-space: nowrap;">${escapeHtml(s.level)}</td>

                    <td style="color:var(--c-text-muted); white-space: nowrap;">${escapeHtml(s.judge)}</td>
                    <td style="text-align:center; font-family:monospace; font-size:1.05rem; font-weight:bold; color:var(--c-text-muted); white-space: nowrap;">${s.total} / ${s.max}</td>
                    <td style="text-align:center; font-weight:700; color:var(--c-red); white-space: nowrap;">${s.percentage}%</td>

                    <td style="text-align:center; white-space: nowrap;" class="medal-cell">
                        <div style="display: flex; flex-direction: column; align-items: center; gap: 4px;">
                            <span>${escapeHtml(s.medal)}</span>
                            ${badge}
                        </div>
                    </td>
                </tr>`;
            });
        }

        html += `</tbody></table></div></div>`;
        document.getElementById('leaderboard-tables').innerHTML = html;
    }
    
    // ── EXPORT FUNCTIONS ──────────────────────────────────────────────
    function exportToExcel() {
        const table = document.getElementById('lbTable');
        if (!table) return alert("Tiada data untuk dieksport.");
        
        const wb = XLSX.utils.table_to_book(table, { sheet: "Papan Pendahulu" });
        XLSX.writeFile(wb, "Papan_Pendahulu_ProMarkah.xlsx");
    }
    
    function exportToPDF(orientation = 'landscape') {
        const table = document.getElementById('lbTable');
        if (!table) return alert("Tiada data untuk dieksport.");
    
        const { jsPDF } = window.jspdf;
        const isLandscape = orientation === 'landscape';
        const doc = new jsPDF({ orientation: orientation, unit: 'pt', format: 'a4' });

        // Build dynamic filename based on active filters
        const fYear = document.getElementById('filter-year').value;
        const fSiri = document.getElementById('filter-siri').value;
        const fSession = document.getElementById('filter-session').value;
        const fLevel = document.getElementById('filter-level').value;
        const fMedal = document.getElementById('filter-medal').value;

        let nameParts = ["PAPAN_KEDUDUKAN"];
        if (fSiri) nameParts.push(fSiri);
        if (fSession) nameParts.push(fSession);
        if (fLevel) nameParts.push(fLevel);
        if (fMedal) nameParts.push(fMedal);
        if (fYear) nameParts.push(fYear);

        let baseFileName = nameParts.join('_').toUpperCase().replace(/[^A-Z0-9_]/g, '_');
        doc.setProperties({ title: baseFileName });
        
        const pageWidth = doc.internal.pageSize.width;
        
        // --- 1. SLEEK HEADER SECTION ---
        doc.setFont('helvetica', 'bold');
        doc.setFontSize(isLandscape ? 18 : 15);
        doc.setTextColor(30, 30, 30); 
        doc.text("PAPAN KEDUDUKAN KESELURUHAN", 40, 45);

        doc.setFont('helvetica', 'normal');
        doc.setFontSize(10);
        doc.setTextColor(120, 120, 120);
        doc.text("PROMARKAH — SISTEM PENILAIAN SILAT", 40, 60);

        const today = new Date();
        const dateString = "Dijana pada: " + today.toLocaleDateString('ms-MY') + " " + today.toLocaleTimeString('ms-MY');
        doc.setFontSize(8);
        doc.setTextColor(150, 150, 150);
        doc.text(dateString, pageWidth - 40, 60, { align: 'right' });

        doc.setDrawColor(214, 40, 40); 
        doc.setLineWidth(1.5);
        doc.line(40, 68, pageWidth - 40, 68);
    
        // --- 2. TABLE GENERATION ---
        doc.autoTable({
            html: '#lbTable',
            startY: 85,
            didParseCell: function(data) {
                if (data.cell.text && typeof data.cell.text[0] === 'string') {
                    let cleanText = data.cell.text[0].replace(/[^\x00-\x7F]/g, '').trim();
                    data.cell.text[0] = cleanText.toUpperCase();
                }
            },
            styles: { 
                font: 'helvetica',
                fontSize: isLandscape ? 8 : 7.5,
                cellPadding: isLandscape ? 6 : 5,
                textColor: [50, 50, 50],
                lineColor: [235, 235, 235], 
                lineWidth: { bottom: 0.5, top: 0, left: 0, right: 0 },
                valign: 'middle', // Vertically centers text
                halign: 'center', // Horizontally centers ALL text (fixes the messy left-aligned wrapping)
                overflow: 'linebreak' // Allows long names to wrap to the next line naturally
            },
            headStyles: { 
                fillColor: [35, 35, 35], 
                textColor: [255, 255, 255], 
                fontStyle: 'bold',
                halign: 'center',
                lineWidth: 0 
            },
            alternateRowStyles: { 
                fillColor: [252, 252, 252] 
            },
            columnStyles: { 
                0: { fontStyle: 'bold', textColor: [100, 100, 100] }, // halign: 'center' removed as it's now global
                1: { cellWidth: isLandscape ? 'auto' : 110 }, 
                8: { halign: 'center', fontStyle: 'bold' }, 
                9: { halign: 'center', fontStyle: 'bold', textColor: [214, 40, 40] }, 
                10: { halign: 'center', fontStyle: 'bold' } 
            },
            margin: { top: 85, left: 40, right: 40, bottom: 40 }
        });
        
        // --- 3. IN-PAGE PREVIEW (Bypasses Popup Blockers) ---
        const pdfBlob = doc.output('blob', { type: 'application/pdf' });
        const pdfUrl = URL.createObjectURL(pdfBlob);
        
        // Create full-screen overlay
        const overlay = document.createElement('div');
        overlay.style.cssText = 'position: fixed; top: 0; left: 0; width: 100vw; height: 100vh; background: rgba(0,0,0,0.85); z-index: 9999; display: flex; flex-direction: column;';
        
        // Create top bar with close button
        const topBar = document.createElement('div');
        topBar.style.cssText = 'width: 100%; padding: 12px 24px; background: #1f1f1f; display: flex; justify-content: space-between; align-items: center; box-sizing: border-box;';
        
        const titleSpan = document.createElement('span');
        titleSpan.innerText = baseFileName + ".pdf";
        titleSpan.style.cssText = 'color: white; font-family: "DM Sans", sans-serif; font-weight: bold; letter-spacing: 0.05em; font-size: 0.9rem;';
        
        const closeBtn = document.createElement('button');
        closeBtn.innerText = '✖ Tutup Preview';
        closeBtn.style.cssText = 'background: #d62828; color: white; border: none; padding: 8px 16px; border-radius: 4px; font-weight: bold; cursor: pointer; font-family: "DM Sans", sans-serif; font-size: 0.85rem;';
        closeBtn.onclick = () => {
            document.body.removeChild(overlay);
            URL.revokeObjectURL(pdfUrl); // Clean up memory
        };
        
        topBar.appendChild(titleSpan);
        topBar.appendChild(closeBtn);
        
        // Create iframe to render PDF natively
        const iframe = document.createElement('iframe');
        iframe.src = pdfUrl;
        iframe.style.cssText = 'width: 100%; flex-grow: 1; border: none;';
        
        overlay.appendChild(topBar);
        overlay.appendChild(iframe);
        document.body.appendChild(overlay);
    }
</script>
</main>
</body>
</html>