<?php
/**
 * error_page.php — the ONLY thing a visitor sees when something breaks.
 *
 * Rendered by promarkah_render_error_page() in security_bootstrap.php. It is
 * deliberately self-contained (no DB, no external CSS/fonts/images) so it
 * still displays correctly even when the database or network is the very
 * thing that failed. It exposes NOTHING technical — just an apology and the
 * random incident id ($safeId, already html-escaped by the caller).
 */
if (!isset($safeId)) { $safeId = 'UNKNOWN'; }
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <title>Ralat Sistem | ProMarkah</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            background: #111;
            color: #e5e7eb;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            text-align: center;
        }
        .card {
            max-width: 440px;
            width: 100%;
            background: #1a1a1a;
            border: 1px solid #2a2a2a;
            border-radius: 20px;
            padding: 40px 32px;
            box-shadow: 0 20px 50px rgba(0,0,0,0.5);
        }
        .icon { font-size: 3rem; line-height: 1; margin-bottom: 16px; }
        h1 {
            font-size: 1.35rem;
            font-weight: 800;
            letter-spacing: 0.02em;
            color: #fff;
            margin-bottom: 12px;
        }
        p { font-size: 0.95rem; line-height: 1.6; color: #9ca3af; margin-bottom: 10px; }
        .ref {
            display: inline-block;
            margin-top: 18px;
            padding: 8px 14px;
            background: #111;
            border: 1px dashed #3a3a3a;
            border-radius: 10px;
            font-family: ui-monospace, "SF Mono", Menlo, Consolas, monospace;
            font-size: 0.85rem;
            color: #d1d5db;
            letter-spacing: 0.08em;
        }
        .ref b { color: #f87171; }
        .actions { margin-top: 26px; }
        .btn {
            display: inline-block;
            background: #D62828;
            color: #fff;
            text-decoration: none;
            font-weight: 700;
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.1em;
            padding: 12px 26px;
            border-radius: 12px;
            transition: background 0.2s;
        }
        .btn:hover { background: #B01F1F; }
        .muted { margin-top: 22px; font-size: 0.75rem; color: #6b7280; }
    </style>
</head>
<body>
    <div class="card">
        <div class="icon">⚠️</div>
        <h1>Maaf, sistem menghadapi masalah</h1>
        <p>Berlaku ralat teknikal yang tidak dijangka. Pasukan teknikal telah dimaklumkan secara automatik.</p>
        <p>Sila cuba semula sebentar lagi.</p>

        <div class="ref">Rujukan: <b><?= $safeId ?></b></div>

        <div class="actions">
            <a class="btn" href="login.php">Kembali ke Log Masuk</a>
        </div>

        <div class="muted">Jika masalah berterusan, berikan nombor rujukan di atas kepada pentadbir sistem.</div>
    </div>
</body>
</html>
