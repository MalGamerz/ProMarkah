<?php
session_start();
require __DIR__ . '/auth_check.php';
include 'db.php';
$conn = getDB();


// PIC only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['group_id'])) {

    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
        header("Location: pic_manual_marks.php?msg=Ralat+Token+Keselamatan");
        exit();
    }

    $group_id   = intval($_POST['group_id']);
    $student_id = intval($_POST['student_id']);
    $test_id    = intval($_POST['test_id']);

    // MULTIPLE ROWS INPUTS
    $criteria_ids = $_POST['criteria_id'] ?? [];
    $marks        = $_POST['mark'] ?? [];

    if ($group_id <= 0 || $student_id <= 0 || $test_id <= 0 || empty($criteria_ids)) {
        header("Location: pic_manual_marks.php?msg=Ralat+Data+Tidak+Lengkap");
        exit();
    }

    for ($i = 0; $i < count($criteria_ids); $i++) {
        $criteria_id = intval($criteria_ids[$i]);
        $mark        = floatval($marks[$i]);

        if ($criteria_id <= 0) continue;

        // scores no longer stores test_id directly — it's derived via
        // criteria_id -> criteria.test_id, so a criterion can never be
        // saved under the wrong test the way a separately-supplied
        // $test_id used to allow. Just confirm the criterion really
        // belongs to the submitted test before accepting it.
        $ct = $conn->prepare("SELECT test_id FROM criteria WHERE criteria_id=?");
        $ct->bind_param("i", $criteria_id);
        $ct->execute();
        $ctRow = $ct->get_result()->fetch_assoc();
        $ct->close();
        if (!$ctRow || (int)$ctRow['test_id'] !== $test_id) continue;

        // Check if score already exists
        $check = $conn->prepare("SELECT score_id FROM scores WHERE student_id=? AND group_id=? AND criteria_id=?");
        $check->bind_param("iii", $student_id, $group_id, $criteria_id);
        $check->execute();
        $result = $check->get_result();
        $exists = $result->num_rows > 0;
        $check->close();

        if ($exists) {
            $upd = $conn->prepare("UPDATE scores SET mark=?, submitted=1 WHERE student_id=? AND group_id=? AND criteria_id=?");
            $upd->bind_param("diii", $mark, $student_id, $group_id, $criteria_id);
            $upd->execute();
            $upd->close();
        } else {
            // scores.test_id is NOT NULL — $test_id was already validated
            // above (via $ctRow) to match this criterion, so reuse it.
            $ins = $conn->prepare("INSERT INTO scores (student_id, group_id, test_id, criteria_id, mark, submitted) VALUES (?, ?, ?, ?, ?, 1)");
            $ins->bind_param("iiiid", $student_id, $group_id, $test_id, $criteria_id, $mark);
            $ins->execute();
            $ins->close();
        }
    }
    header("Location: pic_manual_marks.php?msg=Markah+Berjaya+Disimpan!");
    exit();
} else {
    header("Location: pic_manual_marks.php");
    exit();
}