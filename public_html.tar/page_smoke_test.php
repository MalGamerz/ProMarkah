<?php
/**
 * page_smoke_test.php — actually loads the real pages (not a SQL mimic)
 * and checks whether they render to completion, using YOUR OWN live
 * session, via the BROWSER (not a server-side loopback).
 *
 * Why browser-side: an earlier version of this made the PHP server
 * fetch its own pages over HTTP from within the same request. On a
 * small PHP-FPM pool that deadlocks — the outer request holds the only
 * free worker, then waits on an inner request that needs a free worker
 * that will never appear. Fetching from the browser instead means each
 * check is a real, independent HTTP connection like any normal page
 * load, so there's nothing to deadlock.
 *
 * Why this exists at all: db_health_check.php only tests hand-retyped
 * SQL that *mimics* the real queries — it never executes the actual
 * page files, so it can't catch a plain PHP bug (undefined variable,
 * wrong array key, etc.) that isn't a SQL error. This closes that gap
 * by requesting the real URLs for real.
 *
 * What it CAN detect: HTTP status != 200, or a response that doesn't
 * finish with the closing `</main></body></html>` every one of these
 * pages ends with — which happens if a fatal error kills the request
 * partway through rendering, regardless of display_errors settings.
 *
 * What it CANNOT detect: a non-fatal PHP warning/notice, since every
 * page explicitly sets display_errors=0 — those only go to the PHP
 * error log, whose exact path varies by host and isn't guessed here.
 * A visually wrong (but non-crashing) page still needs a human look.
 *
 * Coverage depends on YOUR current role, since the browser sends your
 * real session cookie — it can't fake a different role:
 *   - Logged in as pic/admin -> tests the PIC-facing pages.
 *   - Logged in as judge     -> tests the judge-facing pages.
 * Log in as each role separately and revisit this page for full coverage.
 *
 * Usage: log in normally, then visit page_smoke_test.php in the browser.
 *
 * ── DEEP DRAFT-SCORE TEST (admin only) ──────────────────────────────────
 * Below the page-render table is a second, opt-in section that exercises
 * the draft/half-saved score feature (save_draft_score.php, save_scores.php,
 * the judge.php lock logic, and the leaderboard's submitted=1 filtering)
 * at the database level — every INSERT/UPDATE/DELETE it runs happens
 * inside one transaction that is ALWAYS rolled back, so it can never
 * leave fixture data behind or affect a real group/student/leaderboard
 * row, pass or fail. It's gated to admin because it needs raw DB access
 * beyond what save_draft_score.php's own guards allow from the browser.
 */

session_start();
require __DIR__ . '/auth_check.php';

$role = $_SESSION['role'] ?? null;
if (!in_array($role, ['admin', 'pic', 'judge'], true)) {
    http_response_code(403);
    exit('Forbidden — log in first.');
}

// ── Target pages, grouped by which role can actually reach them ──
$targetsByRole = [
    'pic' => [
        'pic_groups.php',
        'pic_directory.php?tab=students_group',
        'pic_directory.php?tab=judges_school',
        'pic_directory.php?tab=groups_judge',
        'pic.php',
        'pic_master_list.php',
        'pic_view_marks.php',
        'pic_manual_marks.php',
        'pic_sessions.php',
        'pic_criteria.php',
        'pic_tests.php',
        'pic_students.php',
        'pic_schools.php',
        'manage_attendance.php',
        'upload_students.php',
        'leaderboard.php',
    ],
    'judge' => [
        'judge.php',
        'judge_view_marks.php',
        'leaderboard.php',
    ],
    // Admin has NO access to pic_*.php/leaderboard.php/manage_attendance.php —
    // every one of those pages checks role === 'pic' (or judge/pic for the
    // leaderboard) with no admin bypass. upload_students.php is the one
    // exception that explicitly allows ['pic', 'admin']. Don't add PIC-only
    // pages here — they will always redirect to login for an admin session.
    'admin' => [
        'admin.php',
        'admin_data.php',
        'admin_logs.php',
        'upload_students.php',
    ],
];

$targets = $targetsByRole[$role] ?? [];

// ══════════════════════════════════════════════════════════════════════
// DEEP DRAFT-SCORE TEST — runs server-side, only when explicitly asked
// for via ?deep_draft_test=1, and only for admin (needs raw DB access).
// ══════════════════════════════════════════════════════════════════════
$deep_results  = [];
$deep_ran      = false;
$deep_fixtures = [];

function deep_check(string $label, bool $ok, string $detail = ''): void
{
    global $deep_results;
    $deep_results[] = ['label' => $label, 'ok' => $ok, 'detail' => $detail];
}

if ($role === 'admin' && isset($_GET['deep_draft_test'])) {
    $deep_ran = true;
    include __DIR__ . '/db.php';
    $conn = getDB();
    $conn->begin_transaction();

    try {
        // ── Fixtures: fully self-contained, isolated from real data ──
        $conn->query("INSERT INTO sessions (session_name, siri_id) VALUES ('SMOKE_TEST_SESSION', NULL)");
        $session_id = $conn->insert_id;

        $conn->query("INSERT INTO levels (session_id, level_name) VALUES ($session_id, 'SMOKE_TEST_LEVEL')");
        $level_id = $conn->insert_id;

        $conn->query("INSERT INTO tests (level_id, test_name) VALUES ($level_id, 'SMOKE_TEST_TEST')");
        $test_id = $conn->insert_id;

        $conn->query("INSERT INTO criteria (test_id, criteria_name, max_mark) VALUES ($test_id, 'SMOKE_TEST_CRIT', 10)");
        $criteria_id = $conn->insert_id;

        $conn->query("INSERT INTO schools (school_name) VALUES ('SMOKE_TEST_SCHOOL')");
        $school_id = $conn->insert_id;

        $conn->query("INSERT INTO students (student_name, level_id, school_id, gender, year) VALUES ('SMOKE_TEST_STUDENT', $level_id, $school_id, 'Male', YEAR(CURDATE()))");
        $student_id = $conn->insert_id;

        // groups has no session_id column on this DB (confirmed against every
        // real INSERT in the app: pic_groups.php, upload_students.php) —
        // a group's session is derived indirectly via level_id -> levels.session_id.
        $conn->query("INSERT INTO `groups` (level_id, group_name, judge_id, edit_used) VALUES ($level_id, 'SMOKE_TEST_GROUP', NULL, 0)");
        $group_id = $conn->insert_id;

        $conn->query("INSERT INTO group_students (group_id, student_id) VALUES ($group_id, $student_id)");

        $deep_fixtures = compact('session_id', 'level_id', 'test_id', 'criteria_id', 'school_id', 'student_id', 'group_id');

        // ── Test 1: draft save inserts with submitted=0 (mirrors save_draft_score.php) ──
        $stmt = $conn->prepare("
            INSERT INTO scores (student_id, group_id, criteria_id, mark, submitted)
            VALUES (?, ?, ?, ?, 0)
            ON DUPLICATE KEY UPDATE mark = VALUES(mark), submitted = IF(submitted = 1, submitted, 0)
        ");
        $mark = 7;
        $stmt->bind_param("iiii", $student_id, $group_id, $criteria_id, $mark);
        $stmt->execute();
        $stmt->close();

        $row = $conn->query("SELECT mark, submitted FROM scores WHERE group_id=$group_id AND student_id=$student_id AND criteria_id=$criteria_id")->fetch_assoc();
        deep_check('Draft insert: row written successfully', $row !== null);
        deep_check('Draft insert: mark stored correctly', $row && (int)$row['mark'] === 7, 'expected 7, got ' . ($row['mark'] ?? 'null'));
        deep_check('Draft insert: submitted flag is 0', $row && (int)$row['submitted'] === 0, 'expected 0, got ' . ($row['submitted'] ?? 'null'));

        // ── Test 2: a group with only draft marks must NOT be considered locked ──
        $lockCheck = $conn->query("SELECT 1 FROM scores WHERE group_id=$group_id AND submitted=1 LIMIT 1");
        deep_check('Lock check: group with only a draft is NOT locked', $lockCheck->num_rows === 0);

        // ── Test 3: re-saving the draft (judge changes their mind) updates in place ──
        $mark2 = 9;
        $stmt = $conn->prepare("
            INSERT INTO scores (student_id, group_id, criteria_id, mark, submitted)
            VALUES (?, ?, ?, ?, 0)
            ON DUPLICATE KEY UPDATE mark = VALUES(mark), submitted = IF(submitted = 1, submitted, 0)
        ");
        $stmt->bind_param("iiii", $student_id, $group_id, $criteria_id, $mark2);
        $stmt->execute();
        $stmt->close();

        $row = $conn->query("SELECT mark FROM scores WHERE group_id=$group_id AND student_id=$student_id AND criteria_id=$criteria_id")->fetch_assoc();
        deep_check('Draft update: mark overwritten via upsert (no duplicate row)', $row && (int)$row['mark'] === 9, 'expected 9, got ' . ($row['mark'] ?? 'null'));
        $rowCount = $conn->query("SELECT COUNT(*) c FROM scores WHERE group_id=$group_id AND student_id=$student_id AND criteria_id=$criteria_id")->fetch_assoc()['c'];
        deep_check('Draft update: still exactly one row for this cell', (int)$rowCount === 1, "found $rowCount rows");

        // ── Test 4: clearing a draft (toggled "Abai") deletes it, but only while submitted=0 ──
        $conn->query("DELETE FROM scores WHERE group_id=$group_id AND student_id=$student_id AND criteria_id=$criteria_id AND submitted = 0");
        $rowCount = $conn->query("SELECT COUNT(*) c FROM scores WHERE group_id=$group_id AND student_id=$student_id AND criteria_id=$criteria_id")->fetch_assoc()['c'];
        deep_check('Draft clear: row removed when submitted=0', (int)$rowCount === 0);

        // ── Test 5: leaderboard-style aggregate must exclude drafts ──
        $mark3 = 6;
        $stmt = $conn->prepare("
            INSERT INTO scores (student_id, group_id, criteria_id, mark, submitted)
            VALUES (?, ?, ?, ?, 0)
            ON DUPLICATE KEY UPDATE mark = VALUES(mark), submitted = 0
        ");
        $stmt->bind_param("iiii", $student_id, $group_id, $criteria_id, $mark3);
        $stmt->execute();
        $stmt->close();

        $agg = $conn->query("SELECT COALESCE(SUM(mark),0) total FROM scores WHERE student_id=$student_id AND submitted=1")->fetch_assoc();
        deep_check('Leaderboard aggregate: draft-only student contributes 0 to submitted totals', (int)$agg['total'] === 0, 'got ' . $agg['total']);

        // ── Test 6: final submit (mirrors save_scores.php) flips submitted=1 ──
        $finalMark = 10;
        $stmt = $conn->prepare("
            INSERT INTO scores (student_id, group_id, criteria_id, mark, submitted)
            VALUES (?, ?, ?, ?, 1)
            ON DUPLICATE KEY UPDATE mark = VALUES(mark), submitted = 1
        ");
        $stmt->bind_param("iiii", $student_id, $group_id, $criteria_id, $finalMark);
        $stmt->execute();
        $stmt->close();

        $row = $conn->query("SELECT mark, submitted FROM scores WHERE group_id=$group_id AND student_id=$student_id AND criteria_id=$criteria_id")->fetch_assoc();
        deep_check('Final submit: mark updated to finalized value', $row && (int)$row['mark'] === 10, 'got ' . ($row['mark'] ?? 'null'));
        deep_check('Final submit: submitted flag flipped to 1', $row && (int)$row['submitted'] === 1);

        // ── Test 7: group is now locked ──
        $lockCheck = $conn->query("SELECT 1 FROM scores WHERE group_id=$group_id AND submitted=1 LIMIT 1");
        deep_check('Lock check: group with a finalized mark IS locked', $lockCheck->num_rows === 1);

        // ── Test 8: leaderboard aggregate now counts the finalized mark ──
        $agg = $conn->query("SELECT COALESCE(SUM(mark),0) total FROM scores WHERE student_id=$student_id AND submitted=1")->fetch_assoc();
        deep_check('Leaderboard aggregate: finalized mark now counted', (int)$agg['total'] === 10, 'got ' . $agg['total']);

        // ── Test 9: draft endpoint's own guard logic (PHP-level, replicated here) ──
        // save_draft_score.php refuses writes once submitted=1 exists AND edit_used=1.
        $edit_used_flag  = 1;
        $has_submitted   = $lockCheck->num_rows === 1;
        $wouldBeRejected = $has_submitted && $edit_used_flag === 1;
        deep_check('Draft endpoint guard: rejects further drafts once locked + edit token consumed', $wouldBeRejected === true);

        // ── Test 10: a second, different judge/group must never see this student's drafts ──
        // (sanity check that our WHERE clauses are scoped by group_id, not global)
        $conn->query("INSERT INTO `groups` (level_id, group_name, judge_id, edit_used) VALUES ($level_id, 'SMOKE_TEST_GROUP_2', NULL, 0)");
        $other_group_id = $conn->insert_id;
        $leak = $conn->query("SELECT 1 FROM scores WHERE group_id=$other_group_id LIMIT 1");
        deep_check('Isolation: an unrelated group sees none of this student\'s scores', $leak->num_rows === 0);

    } catch (Throwable $e) {
        deep_check('Unexpected exception during deep test', false, $e->getMessage());
    }

    $conn->rollback();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Page Smoke Test</title>
<style>
    body { font-family: -apple-system, Segoe UI, sans-serif; background:#111; color:#eee; padding:24px; }
    h1 { font-size:1.3rem; }
    h2 { font-size:1.05rem; margin-top:40px; border-top:1px solid #333; padding-top:24px; }
    .summary { margin-bottom:16px; font-size:0.95rem; }
    .pass { color:#4ADE80; }
    .fail { color:#F87171; }
    .pending { color:#facc15; }
    .note { color:#aaa; font-size:0.82rem; margin-bottom:16px; }
    table { width:100%; border-collapse:collapse; font-size:0.85rem; }
    th, td { text-align:left; padding:8px 10px; border-bottom:1px solid #333; word-break:break-word; }
    th { color:#888; text-transform:uppercase; font-size:0.72rem; letter-spacing:0.05em; }
    tr.fail-row { background:rgba(248,113,113,0.08); }
    .badge { display:inline-block; padding:2px 8px; border-radius:10px; font-size:0.72rem; font-weight:700; white-space:nowrap; }
    .badge.pass { background:rgba(74,222,128,0.15); color:#4ADE80; }
    .badge.fail { background:rgba(248,113,113,0.15); color:#F87171; }
    .badge.pending { background:rgba(250,204,21,0.15); color:#facc15; }
    .deep-btn {
        display:inline-block; margin-top:10px; padding:9px 16px; border-radius:6px;
        background:#7c3aed; color:#fff; text-decoration:none; font-size:0.85rem; font-weight:600;
    }
    .deep-btn:hover { background:#6d28d9; }
    .rollback-note {
        margin-top:16px; padding:10px 12px; border-left:3px solid #4ADE80;
        background:rgba(74,222,128,0.08); font-size:0.8rem; color:#bbf7d0; border-radius:0 4px 4px 0;
    }
</style>
</head>
<body>
<h1>Real-Page Smoke Test (role: <?= htmlspecialchars($role) ?>)</h1>
<div class="summary" id="summary">Running…</div>
<div class="note">
    Each row below is a real, independent browser request to the real page (your session cookie is sent
    automatically since this is same-origin). It can only test pages reachable by your current role
    (<?= htmlspecialchars($role) ?>). Log in as a different role and revisit this page to cover the rest.
</div>
<table>
<thead><tr><th>Status</th><th>Page</th><th>Result</th><th>Time</th></tr></thead>
<tbody id="rows"></tbody>
</table>

<?php if ($role === 'judge'): ?>
<h2>Draft-score endpoint guard checks (judge)</h2>
<div class="summary" id="draftSummary">Running…</div>
<div class="note">
    Live AJAX calls to <code>save_draft_score.php</code> under your real judge session — exercises the
    reject paths (bad method, bad CSRF, bad group) that must fail cleanly with the right status code
    and JSON body instead of a 500 crash or a silent write. No real group/student ID is used here, so
    every one of these calls is expected to be rejected — a PASS means "rejected correctly," not "a mark was saved."
</div>
<table>
<thead><tr><th>Status</th><th>Check</th><th>Result</th><th>Time</th></tr></thead>
<tbody id="draftRows"></tbody>
</table>
<?php endif; ?>

<?php if ($role === 'admin'): ?>
<h2>Deep draft-score test (admin, DB-level)</h2>
<div class="note">
    Exercises the full draft-score lifecycle directly against the database — fixture creation, draft
    insert, draft update, draft clear, lock detection, leaderboard aggregate exclusion, final submit,
    and cross-group isolation. Everything below runs inside one transaction that is <strong>always
    rolled back</strong>, pass or fail, so it never leaves fixture rows or touches real data.
</div>
<?php if (!$deep_ran): ?>
    <a class="deep-btn" href="?deep_draft_test=1">▶ Run deep draft-score test</a>
<?php else: ?>
    <?php
        $deepPass = count(array_filter($deep_results, fn($r) => $r['ok']));
        $deepFail = count($deep_results) - $deepPass;
    ?>
    <div class="summary">
        <span class="pass"><?= $deepPass ?> passed</span> &nbsp;|&nbsp;
        <span class="fail"><?= $deepFail ?> failed</span>
    </div>
    <table>
        <thead><tr><th>Status</th><th>Check</th><th>Detail</th></tr></thead>
        <tbody>
        <?php foreach ($deep_results as $r): ?>
            <tr class="<?= $r['ok'] ? '' : 'fail-row' ?>">
                <td><span class="badge <?= $r['ok'] ? 'pass' : 'fail' ?>"><?= $r['ok'] ? 'PASS' : 'FAIL' ?></span></td>
                <td><?= htmlspecialchars($r['label']) ?></td>
                <td><?= htmlspecialchars($r['detail']) ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div class="rollback-note">
        ✓ Transaction rolled back — fixture session/level/test/criteria/school/student/groups
        (<?= htmlspecialchars(json_encode($deep_fixtures)) ?>) and every score written above were all undone.
        Nothing in this run touched real data.
    </div>
    <p><a class="deep-btn" href="?deep_draft_test=1">↻ Run again</a></p>
<?php endif; ?>
<?php endif; ?>

<script>
const targets = <?= json_encode($targets) ?>;
const rowsEl = document.getElementById('rows');
const summaryEl = document.getElementById('summary');

targets.forEach((t) => {
    const tr = document.createElement('tr');
    tr.id = 'row-' + btoa(t).replace(/=/g, '');
    tr.innerHTML = `<td><span class="badge pending">…</span></td><td>${t}</td><td>pending</td><td></td>`;
    rowsEl.appendChild(tr);
});

function setRow(container, key, ok, label, msg, ms) {
    const tr = document.getElementById(container + '-' + key);
    tr.className = ok ? '' : 'fail-row';
    tr.innerHTML = `<td><span class="badge ${ok ? 'pass' : 'fail'}">${ok ? 'PASS' : 'FAIL'}</span></td>` +
                   `<td>${label}</td><td>${msg}</td><td>${ms}ms</td>`;
}

function esc(s) {
    return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

async function runOne(t) {
    const start = performance.now();
    try {
        const res = await fetch(t, { credentials: 'same-origin', redirect: 'manual' });
        const ms = Math.round(performance.now() - start);

        // redirect: 'manual' makes a redirect show up as an "opaqueredirect"
        // response (status 0, type opaqueredirect) instead of following it —
        // exactly what we want to catch here (an unexpected auth bounce).
        if (res.type === 'opaqueredirect') {
            setRow('row', btoa(t).replace(/=/g, ''), false, t, 'Unexpected redirect (likely an auth/session mismatch, not the page itself)', ms);
            return;
        }
        if (!res.ok) {
            setRow('row', btoa(t).replace(/=/g, ''), false, t, `HTTP ${res.status}`, ms);
            return;
        }
        const body = await res.text();
        const trimmed = body.trimEnd();
        const finished = /<\/main>\s*<\/body>\s*<\/html>\s*$/i.test(trimmed);
        const fatalMatch = body.match(/Fatal error|Parse error|Uncaught (Error|Exception|TypeError)[^<\n]*/i);

        if (fatalMatch) {
            setRow('row', btoa(t).replace(/=/g, ''), false, t, 'PHP error visible in output: ' + esc(fatalMatch[0]), ms);
        } else if (!finished) {
            const tail = esc(trimmed.slice(-200));
            setRow('row', btoa(t).replace(/=/g, ''), false, t, `Response truncated before &lt;/html&gt; (likely a fatal error mid-render). Last 200 chars: ${tail}`, ms);
        } else {
            setRow('row', btoa(t).replace(/=/g, ''), true, t, `HTTP 200, rendered to completion (${body.length} bytes)`, ms);
        }
    } catch (e) {
        const ms = Math.round(performance.now() - start);
        setRow('row', btoa(t).replace(/=/g, ''), false, t, 'Network/fetch error: ' + esc(String(e)), ms);
    }
}

(async () => {
    // Sequential, not parallel — keeps this gentle on the server and
    // keeps results in a stable, readable order.
    for (const t of targets) {
        await runOne(t);
    }
    const passCount = document.querySelectorAll('#rows .badge.pass').length;
    const failCount = document.querySelectorAll('#rows .badge.fail').length;
    summaryEl.innerHTML = `<span class="pass">${passCount} passed</span> &nbsp;|&nbsp; <span class="fail">${failCount} failed</span>`;
})();

<?php if ($role === 'judge'): ?>
// ── Draft-score endpoint guard checks ──────────────────────────────────
const draftRowsEl = document.getElementById('draftRows');
const draftSummaryEl = document.getElementById('draftSummary');

const draftChecks = [
    { key: 'get',       label: 'GET instead of POST → 405 method_not_allowed' },
    { key: 'badcsrf',   label: 'POST with wrong/missing CSRF → 403 invalid_token' },
    { key: 'nocsrf',    label: 'POST with CSRF field entirely omitted → 403 invalid_token' },
    { key: 'badgroup',  label: 'POST with invalid group_id (0) → rejected, never a 500' },
    { key: 'badcrit',   label: 'POST with non-existent criteria_id → 400 invalid_criteria (never a 500)' },
    { key: 'badmark',   label: 'POST with out-of-range mark (99) → 400 invalid_mark (never a 500)' },
];

draftChecks.forEach((c) => {
    const tr = document.createElement('tr');
    tr.id = 'draftRows-' + c.key;
    tr.innerHTML = `<td><span class="badge pending">…</span></td><td>${c.label}</td><td>pending</td><td></td>`;
    draftRowsEl.appendChild(tr);
});

async function postDraft(body) {
    const start = performance.now();
    const res = await fetch('save_draft_score.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: new URLSearchParams(body),
    });
    const ms = Math.round(performance.now() - start);
    let json = null;
    try { json = await res.json(); } catch (e) { /* non-JSON body */ }
    return { status: res.status, json, ms };
}

(async () => {
    // We have no real CSRF token available here on purpose — this section
    // only proves the endpoint's guard rails hold, not that a draft can be
    // successfully written (that would need a real group/student/criteria
    // and would actually persist a row — out of scope for a safe smoke test).

    // 1. GET → 405
    {
        const start = performance.now();
        const res = await fetch('save_draft_score.php', { credentials: 'same-origin' });
        const ms = Math.round(performance.now() - start);
        let json = null;
        try { json = await res.json(); } catch (e) {}
        const ok = res.status === 405 && json && json.error === 'method_not_allowed';
        setRow('draftRows', 'get', ok, draftChecks[0].label, ok ? `HTTP ${res.status} → method_not_allowed` : `HTTP ${res.status} → ${JSON.stringify(json)}`, ms);
    }

    // 2. Bad CSRF
    {
        const r = await postDraft({ csrf_token: 'not-the-real-token', group_id: 1, student_id: 1, criteria_id: 1, mark: 5 });
        const ok = r.status === 403 && r.json && r.json.error === 'invalid_token';
        setRow('draftRows', 'badcsrf', ok, draftChecks[1].label, ok ? `HTTP ${r.status} → invalid_token` : `HTTP ${r.status} → ${JSON.stringify(r.json)}`, r.ms);
    }

    // 3. No CSRF field at all
    {
        const r = await postDraft({ group_id: 1, student_id: 1, criteria_id: 1, mark: 5 });
        const ok = r.status === 403 && r.json && r.json.error === 'invalid_token';
        setRow('draftRows', 'nocsrf', ok, draftChecks[2].label, ok ? `HTTP ${r.status} → invalid_token` : `HTTP ${r.status} → ${JSON.stringify(r.json)}`, r.ms);
    }

    // 4. Invalid group_id (still bad CSRF, since we don't have a real token —
    //    the point is confirming no 500 crash regardless of which guard fires first)
    {
        const r = await postDraft({ csrf_token: 'not-the-real-token', group_id: 0, student_id: 1, criteria_id: 1, mark: 5 });
        const ok = r.status !== 500;
        setRow('draftRows', 'badgroup', ok, draftChecks[3].label, `HTTP ${r.status} → ${JSON.stringify(r.json)}`, r.ms);
    }

    // 5. Non-existent criteria_id
    {
        const r = await postDraft({ csrf_token: 'not-the-real-token', group_id: 1, student_id: 1, criteria_id: 999999999, mark: 5 });
        const ok = r.status !== 500;
        setRow('draftRows', 'badcrit', ok, draftChecks[4].label, `HTTP ${r.status} → ${JSON.stringify(r.json)}`, r.ms);
    }

    // 6. Out-of-range mark
    {
        const r = await postDraft({ csrf_token: 'not-the-real-token', group_id: 1, student_id: 1, criteria_id: 1, mark: 99 });
        const ok = r.status !== 500;
        setRow('draftRows', 'badmark', ok, draftChecks[5].label, `HTTP ${r.status} → ${JSON.stringify(r.json)}`, r.ms);
    }

    const passCount = document.querySelectorAll('#draftRows .badge.pass').length;
    const failCount = document.querySelectorAll('#draftRows .badge.fail').length;
    draftSummaryEl.innerHTML = `<span class="pass">${passCount} passed</span> &nbsp;|&nbsp; <span class="fail">${failCount} failed</span>`;
})();
<?php endif; ?>
</script>
</body>
</html>
