<?php
ini_set('display_errors', 0); ini_set('display_startup_errors', 0);
error_reporting(E_ALL); ini_set('log_errors', 1);

session_start();
require __DIR__ . '/auth_check.php';
include 'db.php';
$conn = getDB();

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {
    header("Location: login.php"); exit();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

// ── POST actions ──────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($csrf, $_POST['csrf_token'])) {
        header("Location: pic_students.php"); exit();
    }
    session_write_close();
    if ($_POST['action'] === 'add') {
        $stmt = $conn->prepare("INSERT INTO students (student_name,level_id,school_id,gender,year) VALUES (?,?,?,?,?)");
        $stmt->bind_param('siiss', $_POST['student_name'], $_POST['level_id'], $_POST['school_id'], $_POST['gender'], $_POST['year']);
        $stmt->execute(); $stmt->close();
    }
    if ($_POST['action'] === 'delete') {
        $stmt = $conn->prepare("DELETE FROM students WHERE student_id=?");
        $stmt->bind_param('i', $_POST['student_id']); $stmt->execute(); $stmt->close();
    }
    if ($_POST['action'] === 'save_all' && isset($_POST['students'])) {
        $stmt = $conn->prepare("UPDATE students SET student_name=?,level_id=?,gender=?,year=? WHERE student_id=?");
        foreach ($_POST['students'] as $id => $s) {
            $id = (int)$id;
            $stmt->bind_param('sissi', $s['student_name'], $s['level_id'], $s['gender'], $s['year'], $id);
            $stmt->execute();
        }
        $stmt->close();
    }
    header("Location: pic_students.php"); exit();
}

session_write_close();

// ── AJAX: return sessions (sidang) list scoped to a siri ──────────────────
if (isset($_GET['ajax_sessions'])) {
    header('Content-Type: application/json');
    $siriId = (int)($_GET['siri'] ?? 0);
    $out = [];
    if ($siriId > 0) {
        $stmt = $conn->prepare("SELECT session_id, session_name FROM sessions WHERE siri_id = ? ORDER BY session_name");
        $stmt->bind_param('i', $siriId);
        $stmt->execute();
        $res = $stmt->get_result();
        while ($row = $res->fetch_assoc()) $out[] = $row;
        $stmt->close();
    }
    echo json_encode($out);
    exit();
}

// ── AJAX: return table rows ───────────────────────────────────────────────
if (isset($_GET['ajax'])) {
    $search    = $_GET['search']    ?? '';
    $level     = $_GET['level']     ?? '';
    $gender    = $_GET['gender']    ?? '';
    $yearF     = $_GET['year']      ?? '';
    $school_id = $_GET['school_id'] ?? '';
    $siriF     = $_GET['siri']      ?? '';
    $sessionF  = $_GET['session']   ?? '';

    // Scope to the "Siri Aktif" picked in the sidebar — same filter pic.php's
    // Ringkasan dashboard uses (students -> level -> session -> siri).
    $active_siri = (int)($_SESSION['active_siri_id'] ?? 0);

    $whereArr = ["1=1"]; $bindTypes = ''; $bindVals = [];
    if ($search    !== '') { $whereArr[] = "st.student_name LIKE ?"; $bindTypes .= 's'; $bindVals[] = '%'.$search.'%'; }
    if ($level     !== '') { $whereArr[] = "st.level_id = ?";        $bindTypes .= 'i'; $bindVals[] = (int)$level;     }
    if ($gender    !== '') { $whereArr[] = "st.gender = ?";          $bindTypes .= 's'; $bindVals[] = $gender;         }
    if ($yearF     !== '') { $whereArr[] = "st.year = ?";            $bindTypes .= 's'; $bindVals[] = $yearF;          }
    if ($school_id !== '') { $whereArr[] = "st.school_id = ?";       $bindTypes .= 'i'; $bindVals[] = (int)$school_id; }
    if ($sessionF  !== '') { $whereArr[] = "l.session_id = ?";       $bindTypes .= 'i'; $bindVals[] = (int)$sessionF;  }
    elseif ($siriF !== '') { $whereArr[] = "se.siri_id = ?";         $bindTypes .= 'i'; $bindVals[] = (int)$siriF;     }
    elseif ($active_siri > 0) { $whereArr[] = "se.siri_id = ?";     $bindTypes .= 'i'; $bindVals[] = $active_siri;    }

    $where = implode(" AND ", $whereArr);
    $stmt = $conn->prepare("SELECT st.student_id, st.student_name, st.gender, st.year, st.level_id, st.school_id, l.level_name, sc.school_name
        FROM students st
        JOIN levels l  ON st.level_id  = l.level_id
        JOIN schools sc ON st.school_id = sc.school_id
        LEFT JOIN sessions se ON l.session_id = se.session_id
        WHERE $where ORDER BY st.year DESC, sc.school_name, l.level_name, st.student_name");
    if ($bindTypes) $stmt->bind_param($bindTypes, ...$bindVals);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    // Fetched ONCE up front and reused for every row's Peringkat <select> below
    // — this used to re-run the same query inside the per-student loop, once
    // per row, which is what made filtering slow as the result set grew.
    $all_levels_opts = [];
    $lvls_q2 = $active_siri > 0
        ? $conn->query("SELECT l.* FROM levels l JOIN sessions s ON l.session_id = s.session_id WHERE s.siri_id = $active_siri ORDER BY l.level_name")
        : $conn->query("SELECT l.*, si.siri_name FROM levels l LEFT JOIN sessions s ON l.session_id = s.session_id LEFT JOIN siri si ON s.siri_id = si.siri_id ORDER BY l.level_name");
    while ($l = $lvls_q2->fetch_assoc()) $all_levels_opts[] = $l;

    $current_school = '';
    $no = 1;
    while ($st = $result->fetch_assoc()) {
        $sch = htmlspecialchars($st['school_name']);
        if ($sch !== $current_school) {
            if ($current_school !== '') echo "</tbody></table></div></div></div></div>";
            $uid = 'school_' . $st['school_id'] . '_' . rand(1000,9999);
            echo "<div class='accordion-card'>
        <div class='school-header' onclick=\"toggleBlock('$uid')\">
            <span class='arrow'>▶</span>
            <strong>$sch</strong>
        </div>
        <div id='$uid' style='display:none;'>
            <div class='accordion-body'>
                <div class='school-sticky-bar' id='stickyBar_{$st['school_id']}'>
                    <span class='sticky-msg'>Ada <strong class='dirty-count'>0</strong> perubahan belum disimpan</span>
                    <button type='button' class='pm-btn pm-btn-primary btn-sm' onclick=\"saveSchool('{$st['school_id']}')\">💾 Simpan</button>
                    <button type='button' class='pm-btn btn-sm' style='background:transparent;color:var(--c-text-faint);' onclick=\"discardSchool('{$st['school_id']}')\">Batal</button>
                </div>
                <div class='table-responsive'><table class='students-table' data-school='{$st['school_id']}'><thead>
                <tr>
                    <th style='width:40px;text-align:center;'>No</th>
                    <th>Nama</th>
                    <th>Peringkat</th>
                    <th>Jantina</th>
                    <th>Tahun</th>
                    <th style='width:80px;'></th>
                </tr>
                </thead><tbody>";
            $current_school = $sch;
            $no = 1;
        }
        $sel_opts = '';
        // Scope to "Siri Aktif"; when "Semua Siri" is active, tag each level
        // with its siri so same-named levels across siri aren't ambiguous.
        foreach ($all_levels_opts as $l) {
            $sel = ($l['level_id'] == $st['level_id']) ? "selected" : "";
            $optLabel = htmlspecialchars($l['level_name']);
            if ($active_siri === 0 && !empty($l['siri_name'])) {
                $optLabel .= " — " . htmlspecialchars($l['siri_name']);
            }
            $sel_opts .= "<option value='{$l['level_id']}' $sel>$optLabel</option>";
        }
        echo "<tr data-id='{$st['student_id']}'>
                <td style='text-align:center;color:var(--c-text-faint);'>$no</td>
                <td><input form='masterSaveForm' name='students[{$st['student_id']}][student_name]' value='" . htmlspecialchars($st['student_name']) . "'></td>
                <td><select form='masterSaveForm' name='students[{$st['student_id']}][level_id]'>$sel_opts</select></td>
                <td><select form='masterSaveForm' name='students[{$st['student_id']}][gender]'>
                    <option value='Male'"   . ($st['gender']=='Male'   ? ' selected':'') . ">Lelaki</option>
                    <option value='Female'" . ($st['gender']=='Female' ? ' selected':'') . ">Perempuan</option>
                </select></td>
                <td><input type='number' form='masterSaveForm' name='students[{$st['student_id']}][year]' value='" . htmlspecialchars($st['year']) . "'></td>
                <td style='text-align:center;'>
                    <button type='button' class='pm-btn pm-btn-danger btn-sm'
                        onclick=\"deleteStu('{$st['student_id']}')\">Padam</button>
                </td>
              </tr>";
        $no++;
    }
    if ($current_school !== '') echo "</tbody></table></div></div></div></div>";
    if ($no === 1 && $current_school === '')
        echo "<p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Tiada pelajar ditemui.</p>";
    exit();
}

$pm_page = 'students';
include 'layout.php';
?>

<style>
    .pic-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 20px;
    }
    .pic-section-header h2 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.8rem;
        color: var(--c-white);
        letter-spacing: 0.05em;
        margin: 0;
    }
    .pic-section-sub {
        color: var(--c-text-faint);
        font-size: 0.82rem;
        margin-top: 2px;
    }

    /* ── Filter card ── */
    .filter-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border-strong);
        border-radius: 10px;
        padding: 16px 20px;
        margin-bottom: 18px;
    }
    .filter-card-title {
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--c-text-faint);
        margin-bottom: 12px;
    }
    .pic-filter-bar {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
        gap: 16px;
        align-items: end;
    }
    .pic-filter-bar > div {
        min-width: 0;
    }
    .pic-filter-bar label {
        display: block;
        margin-bottom: 6px;
        font-size: .75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: .08em;
        color: var(--c-text-faint);
    }
    .pic-filter-bar input,
    .pic-filter-bar select {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-white);
        border-radius: 6px;
        height: 46px;
        padding: 0 10px;
        font-size: 0.875rem;
        outline: none;
        width: 100%;
        transition: border-color .2s;
        box-sizing: border-box;
    }
    .pic-filter-bar input:focus,
    .pic-filter-bar select:focus {
        border-color: var(--c-red);
    }
    .pic-filter-bar select option {
        background: var(--c-surface-2);
        color: var(--c-white);
    }
    .pic-filter-bar input::placeholder {
        color: var(--c-text-faint);
    }

    /* ── Add card ── */
    .pic-add-card {
        display: none;
        background: var(--c-surface-1);
        border: 1px solid var(--c-red-border);
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 18px;
    }
    .pic-add-card h3 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.1rem;
        color: var(--c-white);
        margin-bottom: 14px;
        letter-spacing: 0.05em;
    }
    .pic-add-form {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 10px;
        align-items: end;
    }
    .pic-add-form input,
    .pic-add-form select {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-white);
        border-radius: 6px;
        padding: 9px 12px;
        font-size: 0.875rem;
        outline: none;
        width: 100%;
        box-sizing: border-box;
        transition: border-color .2s;
    }
    .pic-add-form input:focus,
    .pic-add-form select:focus {
        border-color: var(--c-red);
        box-shadow: 0 0 0 3px var(--c-red-dim);
    }
    .pic-add-form select option {
        background: var(--c-surface-2);
    }
    .pic-add-form label {
        display: block;
        font-size: 0.75rem;
        color: var(--c-text-faint);
        margin-bottom: 4px;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.07em;
    }

    /* ── Accordion ── */
    .accordion-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border);
        border-radius: 10px;
        margin-bottom: 12px;
    }
    .school-header {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 16px;
        background: var(--c-surface-1);
        border-bottom: 1px solid var(--c-border);
        cursor: pointer;
        color: var(--c-white);
        font-weight: 600;
        font-size: 0.92rem;
        transition: background .15s;
        border-radius: 10px;
    }
    .school-header:hover {
        background: var(--c-surface-2);
    }
    .school-header .arrow {
        color: var(--c-red);
        font-size: 0.9rem;
        transition: transform .2s ease;
        display: inline-block;
    }

    /* ── Accordion body ── */
    .accordion-body {
        max-height: 420px;
        overflow-y: auto;
        overflow-x: hidden;
    }
    .accordion-body .table-responsive {
        overflow-x: auto;
    }

    /* ── Save bar ── */
    .school-sticky-bar {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 16px;
        background: var(--c-surface-2);
        border-bottom: 2px solid var(--c-red);
        position: sticky;
        top: 0;
        z-index: 10;
        animation: slideDown .2s ease;
    }
    @keyframes slideDown {
        from { opacity: 0; transform: translateY(-6px); }
        to   { opacity: 1; transform: translateY(0); }
    }
    .school-sticky-bar .sticky-msg {
        font-size: 0.82rem;
        color: var(--c-text-faint);
        flex: 1;
    }
    .school-sticky-bar .sticky-msg strong {
        color: var(--c-white);
    }

    /* ── Students table ── */
    .table-responsive {
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
    }
    .students-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.875rem;
        min-width: 600px;
    }
    .students-table th {
        background: var(--c-surface-3);
        color: var(--c-text-muted);
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        padding: 11px 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 2px solid var(--c-red);
        position: sticky;
        top: 0;
        z-index: 5;
    }
    .students-table td {
        padding: 9px 14px;
        color: var(--c-text-muted);
        background: var(--c-surface-1);
        border-bottom: 1px solid var(--c-border);
        vertical-align: middle;
        transition: background .1s;
    }
    .students-table tbody tr:hover td {
        background: var(--c-surface-2);
    }
    .students-table tbody tr.row-dirty td {
        background: rgba(214, 40, 40, 0.06) !important;
    }
    .students-table input:not([type=hidden]),
    .students-table select {
        background: var(--c-surface-0) !important;
        border: 1px solid var(--c-border-strong) !important;
        color: var(--c-white) !important;
        border-radius: 4px !important;
        padding: 5px 8px !important;
        font-size: 0.82rem !important;
        outline: none !important;
        width: 100%;
        transition: border-color .2s;
    }
    .students-table input:focus,
    .students-table select:focus {
        border-color: var(--c-red) !important;
    }
    .students-table select option {
        background: var(--c-surface-2);
        color: var(--c-white);
    }

    .btn-sm {
        font-size: 0.78rem !important;
        padding: 5px 10px !important;
    }

    /* ── PAGINATION (matches pic_view_marks.php exactly) ── */
    .vm-pagination {
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-wrap: wrap;
        gap: 10px;
        margin-top: 14px;
        padding-top: 16px;
        border-top: 1px solid var(--c-border);
    }
    .vm-page-info {
        font-size: 0.8rem;
        color: var(--c-text-faint);
        font-weight: 500;
    }
    .vm-page-btns {
        display: flex;
        align-items: center;
        gap: 4px;
        flex-wrap: wrap;
    }
    .vm-page-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 34px;
        height: 34px;
        padding: 0 10px;
        border-radius: 6px;
        font-size: 0.82rem;
        font-weight: 600;
        color: var(--c-text-muted);
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        text-decoration: none;
        cursor: pointer;
        transition: all 0.15s;
        white-space: nowrap;
    }
    .vm-page-btn:hover:not(:disabled) {
        color: #fff;
        border-color: var(--c-red);
        background: var(--c-red-dim);
    }
    .vm-page-btn.vm-page-active {
        background: var(--c-red);
        border-color: var(--c-red);
        color: #fff;
        cursor: default;
        pointer-events: none;
    }
    .vm-page-btn:disabled { opacity: 0.4; cursor: not-allowed; }
    .vm-page-ellipsis {
        display: inline-flex;
        align-items: center;
        height: 34px;
        color: var(--c-text-faint);
        font-size: 0.85rem;
        padding: 0 4px;
    }
    html.pm-light .vm-page-info { color: #6b7280; }
    html.pm-light .vm-page-btn { background: #ffffff; border-color: #d1d5db; color: #374151; }
    html.pm-light .vm-page-btn:hover:not(:disabled) { background: #fee2e2; border-color: #e2581e; color: #b91c1c; }
    html.pm-light .vm-page-btn.vm-page-active { background: #e2581e; border-color: #e2581e; color: #ffffff; }
    html.pm-light .vm-page-ellipsis { color: #9ca3af; }
    html.pm-light .vm-pagination { border-top-color: #e5e7eb; }
    @media (max-width: 640px) {
        .vm-pagination { flex-direction: column; align-items: flex-start; }
        .vm-page-btns { width: 100%; }
    }

    /* ── Searchable dropdown ── */
    .dd-wrap { position: relative; }
    .dd-trigger{
        display:flex;
        align-items:center;
        justify-content:space-between;
        height:46px;
        box-sizing:border-box;
        width:100%;
        padding:0 14px;
        background:var(--c-surface-2);
        border:1px solid var(--c-border-strong);
        border-radius:8px;
        color:var(--c-white);
        font-size:.875rem;
        cursor:pointer;
        user-select:none;
        transition: border-color .2s, box-shadow .2s, background .2s;
    }
    .dd-trigger:hover{ border-color:var(--c-red); }
    .dd-trigger.open{ border-color:var(--c-red); box-shadow:0 0 0 3px var(--c-red-dim); }
    .dd-trigger.dd-trigger-disabled{ opacity:.5; cursor:not-allowed; }
    .dd-trigger .dd-arrow { color: var(--c-text-faint); font-size: 0.7rem; transition: transform .2s; }
    .dd-trigger.open .dd-arrow { transform: rotate(180deg); }

    .dd-panel{
        display:none;
        position:absolute;
        top:calc(100% + 6px);
        left:0;
        right:0;
        background:var(--c-surface-2);
        border:1px solid var(--c-red);
        border-radius:8px;
        overflow:hidden;
        z-index:999;
        box-shadow:0 10px 30px rgba(0,0,0,.25);
    }
    .dd-panel.open{ display:block; }
    .dd-search-box { padding: 8px; border-bottom: 1px solid var(--c-border-strong); }
    .dd-search-box input {
        width: 100%; background: var(--c-surface-0); border: 1px solid var(--c-border-strong);
        color: var(--c-white); border-radius: 4px; padding: 6px 8px; font-size: 0.8rem;
        outline: none; box-sizing: border-box; transition: border-color .2s;
    }
    .dd-search-box input:focus { border-color: var(--c-red); }
    .dd-search-box input::placeholder { color: var(--c-text-faint); }
    .dd-options { max-height: 180px; overflow-y: auto; scrollbar-width: thin; }
    .dd-opt { padding: 9px 12px; font-size: 0.875rem; color: var(--c-white); cursor: pointer; transition: background .1s; }
    .dd-opt:hover { background: var(--c-surface-3); }
    .dd-opt.selected { color: var(--c-red); font-weight: 600; }
    .dd-opt.hidden { display: none; }
    .dd-empty { padding: 10px 12px; color: var(--c-text-faint); font-size: 0.82rem; display: none; text-align: center; }

    html.pm-light .dd-trigger { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .dd-panel { background: #fff; box-shadow: 0 6px 20px rgba(0,0,0,0.12); }
    html.pm-light .dd-search-box { border-bottom-color: #e5e7eb; }
    html.pm-light .dd-search-box input { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .dd-opt { color: #111; }
    html.pm-light .dd-opt:hover { background: #f3f4f6; }
    #ajaxSpinner {
        display: none;
        padding: 30px;
        text-align: center;
        color: var(--c-text-faint);
    }

    /* ── STUDENT LIST: scrollable so pagination always stays on screen ── */
    #studentListScroll {
        overflow-y: auto;
        padding-right: 4px;
        scrollbar-width: thin;
        scrollbar-color: var(--c-border-strong) transparent;
    }
    #studentListScroll::-webkit-scrollbar { width: 4px; }
    #studentListScroll::-webkit-scrollbar-track { background: transparent; }
    #studentListScroll::-webkit-scrollbar-thumb { background: var(--c-border-strong); border-radius: 2px; }
    @media (max-width: 640px) {
        #studentListScroll { max-height: none !important; overflow-y: visible !important; }
    }

    /* ══════════════════════════════════════════════════════════
       LIGHT MODE
    ══════════════════════════════════════════════════════════ */
    html.pm-light .pic-section-header h2 { color: #111; }
    html.pm-light .pic-section-sub { color: #555; }

    html.pm-light .filter-card {
        background: #fff;
        border-color: #e5e7eb;
        box-shadow: 0 1px 4px rgba(0,0,0,0.06);
    }
    html.pm-light .filter-card-title { color: #888; }
    html.pm-light .pic-filter-bar label { color: #555; }
    html.pm-light .pic-filter-bar input,
    html.pm-light .pic-filter-bar select {
        background: #f9fafb;
        border-color: #d1d5db;
        color: #111;
    }
    html.pm-light .pic-filter-bar input::placeholder { color: #9ca3af; }
    html.pm-light .pic-filter-bar select option {
        background: #fff;
        color: #111;
    }

    html.pm-light .pic-add-card {
        background: #fff;
        border-color: var(--c-red-border);
    }
    html.pm-light .pic-add-card h3 { color: #111; }
    html.pm-light .pic-add-form input,
    html.pm-light .pic-add-form select {
        background: #f9fafb;
        border-color: #d1d5db;
        color: #111;
    }
    html.pm-light .pic-add-form select option {
        background: #fff;
        color: #111;
    }
    html.pm-light .pic-add-form label { color: #555; }

    html.pm-light .accordion-card {
        background: #fff;
        border-color: #e5e7eb;
    }
    html.pm-light .school-header {
        background: #f3f4f6;
        border-bottom-color: #e5e7eb;
        color: #111;
    }
    html.pm-light .school-header:hover { background: #e9eaec; }
    html.pm-light .school-sticky-bar { background: #f3f4f6; }
    html.pm-light .school-sticky-bar .sticky-msg strong { color: #111; }

    html.pm-light .students-table th {
        background: #374151;
        color: #f9fafb;
    }
    html.pm-light .students-table td {
        background: #fff;
        color: #222;
        border-bottom-color: #e5e7eb;
    }
    html.pm-light .students-table tbody tr:hover td { background: #f9fafb; }
    html.pm-light .students-table tbody tr.row-dirty td {
        background: rgba(214, 40, 40, 0.05) !important;
    }
    html.pm-light .students-table input:not([type=hidden]),
    html.pm-light .students-table select {
        background: #fff !important;
        border-color: #d1d5db !important;
        color: #111 !important;
    }
    html.pm-light .students-table input:focus,
    html.pm-light .students-table select:focus {
        border-color: var(--c-red) !important;
        box-shadow: 0 0 0 2px var(--c-red-dim) !important;
    }
    html.pm-light .students-table select option {
        background: #fff;
        color: #111;
    }
</style>

<form id='masterSaveForm' method='POST'>
    <input type='hidden' name='action' value='save_all'>
    <input type='hidden' name='csrf_token' value='<?= htmlspecialchars($csrf) ?>'>
</form>

<form id='delStuFrm' method='POST' style='display:none;'>
    <input type='hidden' name='action' value='delete'>
    <input type='hidden' name='student_id' value=''>
    <input type='hidden' name='csrf_token' value='<?= htmlspecialchars($csrf) ?>'>
</form>

<?php $active_siri_main = (int)($_SESSION['active_siri_id'] ?? 0); ?>

<div class='pic-section-header'>
    <div>
        <h2>🥋 Pengurusan Pelajar</h2>
        <div class='pic-section-sub'>Daftar dan kemaskini profil pelajar</div>
    </div>
    <button type='button' class='pm-btn pm-btn-primary' onclick="toggleBlock('addStudent')">+ Tambah Pelajar</button>
</div>

<div class='filter-card'>
    <div class='filter-card-title'>🔍 Tapis Pelajar</div>
    <div class='pic-filter-bar'>
        <div>
            <label>Tahun</label>
            <div class="dd-wrap" id="ddWrap_year">
                <div class="dd-trigger" id="ddTrigger_year" onclick="ddToggle('year')">
                    <span id="ddLabel_year" style="color:var(--c-text-faint);">Semua Tahun</span>
                    <span class="dd-arrow">▼</span>
                </div>
                <div class="dd-panel" id="ddPanel_year">
                    <div class="dd-search-box">
                        <input type="text" placeholder="Cari tahun..." oninput="ddFilter('year',this.value)" onclick="event.stopPropagation()">
                    </div>
                    <div class="dd-options" id="ddOpts_year">
                        <div class="dd-opt selected" data-value="" onclick="ddSelect('year','','Semua Tahun')">Semua Tahun</div>
                        <?php
                        $years = $conn->query("SELECT DISTINCT year FROM students ORDER BY year DESC");
                        while ($y = $years->fetch_assoc()) {
                            $yr = htmlspecialchars($y['year']);
                            echo "<div class='dd-opt' data-value='{$yr}' onclick=\"ddSelect('year','{$yr}','{$yr}')\">{$yr}</div>";
                        }
                        ?>
                    </div>
                    <div class="dd-empty" id="ddEmpty_year">Tiada hasil</div>
                </div>
                <input type="hidden" id="f_year" value="">
            </div>
        </div>
        <div>
            <label>Siri</label>
            <div class="dd-wrap" id="ddWrap_siri">
                <div class="dd-trigger" id="ddTrigger_siri" onclick="ddToggle('siri')">
                    <span id="ddLabel_siri" style="color:var(--c-text-faint);">-- Semua Siri --</span>
                    <span class="dd-arrow">▼</span>
                </div>
                <div class="dd-panel" id="ddPanel_siri">
                    <div class="dd-search-box">
                        <input type="text" placeholder="Cari siri..." oninput="ddFilter('siri',this.value)" onclick="event.stopPropagation()">
                    </div>
                    <div class="dd-options" id="ddOpts_siri">
                        <div class="dd-opt selected" data-value="" onclick="ddSelect('siri','','-- Semua Siri --')">-- Semua Siri --</div>
                        <?php
                        $siri_list = $conn->query("SELECT siri_id, siri_name FROM siri ORDER BY siri_year DESC, siri_name");
                        while ($sr = $siri_list->fetch_assoc()) {
                            $sid_  = $sr['siri_id'];
                            $sname = htmlspecialchars($sr['siri_name']);
                            echo "<div class='dd-opt' data-value='{$sid_}' onclick=\"ddSelect('siri','{$sid_}','{$sname}')\">{$sname}</div>";
                        }
                        ?>
                    </div>
                    <div class="dd-empty" id="ddEmpty_siri">Tiada hasil</div>
                </div>
                <input type="hidden" id="f_siri" value="">
            </div>
        </div>
        <div>
            <label>Sidang</label>
            <div class="dd-wrap" id="ddWrap_session">
                <div class="dd-trigger dd-trigger-disabled" id="ddTrigger_session" onclick="ddToggle('session')">
                    <span id="ddLabel_session" style="color:var(--c-text-faint);">-- Pilih Siri dahulu --</span>
                    <span class="dd-arrow">▼</span>
                </div>
                <div class="dd-panel" id="ddPanel_session">
                    <div class="dd-search-box">
                        <input type="text" placeholder="Cari sidang..." oninput="ddFilter('session',this.value)" onclick="event.stopPropagation()">
                    </div>
                    <div class="dd-options" id="ddOpts_session">
                        <div class="dd-opt selected" data-value="" onclick="ddSelect('session','','-- Semua Sidang --')">-- Semua Sidang --</div>
                    </div>
                    <div class="dd-empty" id="ddEmpty_session">Tiada hasil</div>
                </div>
                <input type="hidden" id="f_session" value="">
            </div>
        </div>
        <div>
            <label>Nama Pelajar</label>
            <input id='f_search' placeholder='Cari nama pelajar...' oninput='ajaxFilter()'>
        </div>
        <div>
            <label>Jantina</label>
            <div class="dd-wrap" id="ddWrap_gender">
                <div class="dd-trigger" id="ddTrigger_gender" onclick="ddToggle('gender')">
                    <span id="ddLabel_gender" style="color:var(--c-text-faint);">Semua Jantina</span>
                    <span class="dd-arrow">▼</span>
                </div>
                <div class="dd-panel" id="ddPanel_gender">
                    <div class="dd-search-box">
                        <input type="text" placeholder="Cari jantina..." oninput="ddFilter('gender',this.value)" onclick="event.stopPropagation()">
                    </div>
                    <div class="dd-options" id="ddOpts_gender">
                        <div class="dd-opt selected" data-value="" onclick="ddSelect('gender','','Semua Jantina')">Semua Jantina</div>
                        <div class="dd-opt" data-value="Male" onclick="ddSelect('gender','Male','Lelaki')">Lelaki</div>
                        <div class="dd-opt" data-value="Female" onclick="ddSelect('gender','Female','Perempuan')">Perempuan</div>
                    </div>
                    <div class="dd-empty" id="ddEmpty_gender">Tiada hasil</div>
                </div>
                <input type="hidden" id="f_gender" value="">
            </div>
        </div>
        <div>
            <label>Nama Cawangan</label>
            <div class="dd-wrap" id="ddWrap_school">
                <div class="dd-trigger" id="ddTrigger_school" onclick="ddToggle('school')">
                    <span id="ddLabel_school" style="color:var(--c-text-faint);">Semua Cawangan</span>
                    <span class="dd-arrow">▼</span>
                </div>
                <div class="dd-panel" id="ddPanel_school">
                    <div class="dd-search-box">
                        <input type="text" placeholder="Cari cawangan..." oninput="ddFilter('school',this.value)" onclick="event.stopPropagation()">
                    </div>
                    <div class="dd-options" id="ddOpts_school">
                        <div class="dd-opt selected" data-value="" onclick="ddSelect('school','','Semua Cawangan')">Semua Cawangan</div>
                        <?php
                        $schools_f = $conn->query("SELECT school_id, school_name FROM schools ORDER BY school_name");
                        while ($sc = $schools_f->fetch_assoc()) {
                            $scid = $sc['school_id'];
                            $scname = htmlspecialchars($sc['school_name']);
                            echo "<div class='dd-opt' data-value='{$scid}' onclick=\"ddSelect('school','{$scid}','{$scname}')\">{$scname}</div>";
                        }
                        ?>
                    </div>
                    <div class="dd-empty" id="ddEmpty_school">Tiada hasil</div>
                </div>
                <input type="hidden" id="f_school" value="">
            </div>
        </div>
    </div>
</div>

<div id='addStudent' class='pic-add-card'>
    <h3>+ Tambah Pelajar Baru</h3>
    <form method='POST' class='pic-add-form'>
        <input type='hidden' name='action' value='add'>
        <input type='hidden' name='csrf_token' value='<?= htmlspecialchars($csrf) ?>'>
        <div>
            <label>Nama Penuh</label>
            <input name='student_name' placeholder='Nama Penuh' required>
        </div>
        <div>
            <label>Peringkat</label>
            <select name='level_id' required>
                <?php
                $lvls = $active_siri_main > 0
                    ? $conn->query("SELECT l.* FROM levels l JOIN sessions s ON l.session_id = s.session_id WHERE s.siri_id = $active_siri_main ORDER BY l.level_name")
                    : $conn->query("SELECT l.*, si.siri_name FROM levels l LEFT JOIN sessions s ON l.session_id = s.session_id LEFT JOIN siri si ON s.siri_id = si.siri_id ORDER BY l.level_name");
                while ($l = $lvls->fetch_assoc()) {
                    $optLabel = htmlspecialchars($l['level_name']);
                    if ($active_siri_main === 0 && !empty($l['siri_name'])) {
                        $optLabel .= " — " . htmlspecialchars($l['siri_name']);
                    }
                    echo "<option value='{$l['level_id']}'>$optLabel</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label>Cawangan</label>
            <select name='school_id' required>
                <?php $schs = $conn->query("SELECT * FROM schools ORDER BY school_name"); while ($s=$schs->fetch_assoc()) echo "<option value='{$s['school_id']}'>" . htmlspecialchars($s['school_name']) . "</option>"; ?>
            </select>
        </div>
        <div>
            <label>Jantina</label>
            <select name='gender' required>
                <option value='Male'>Lelaki</option>
                <option value='Female'>Perempuan</option>
            </select>
        </div>
        <div>
            <label>Tahun</label>
            <input type='number' name='year' placeholder='Tahun' value='<?= date('Y') ?>' required>
        </div>
        <div style='display:flex;align-items:flex-end;'>
            <button class='pm-btn pm-btn-primary' style='width:100%;'>Tambah</button>
        </div>
    </form>
</div>

<div id='studentListScroll'>
    <div id='studentList'><p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Memuatkan...</p></div>
    <div id='ajaxSpinner'>⏳ Mencari...</div>
</div>

<div class="vm-pagination" id="studentsPaginationContainer" style="display:none;">
    <div class="vm-page-info" id="studentsPageInfo"></div>
    <div class="vm-page-btns" id="studentsPaginationButtons"></div>
</div>

<script>
let _filterTimer = null;
let _dirtyMap = {};

// Debounced — used by the free-text search box, so it doesn't fire a
// request on every single keystroke.
function ajaxFilter() {
    clearTimeout(_filterTimer);
    _filterTimer = setTimeout(_doFilter, 400);
}

// Immediate — used by dropdowns/selects, since a discrete choice (unlike
// typing) never fires rapidly and shouldn't wait out the text-search debounce.
function ajaxFilterNow() {
    clearTimeout(_filterTimer);
    _doFilter();
}

function _doFilter() {
    const params = new URLSearchParams({
        ajax:      '1',
        search:    document.getElementById('f_search').value,
        year:      document.getElementById('f_year').value,
        gender:    document.getElementById('f_gender').value,
        siri:      document.getElementById('f_siri').value,
        session:   document.getElementById('f_session').value,
        school_id: document.getElementById('f_school').value,
    });
    document.getElementById('ajaxSpinner').style.display = 'block';
    document.getElementById('studentList').style.opacity = '0.4';

    fetch('pic_students.php?' + params)
    .then(r => r.text())
    .then(html => {
        document.getElementById('studentList').innerHTML = html;
        document.getElementById('studentList').style.opacity = '1';
        document.getElementById('ajaxSpinner').style.display = 'none';
        _dirtyMap = {};
        attachDirtyListeners();
        // accordions start closed so bars start hidden — nothing to do here
        // but reset dirty count display
        document.querySelectorAll('.dirty-count').forEach(el => el.textContent = '0');
        studentsCurrentPage = 1;
        updateStudentsPagination();
        fitStudentListHeight();
    });
}

// ── PAGINATION (client-side, 20 school-accordions per page) ──
let studentsCurrentPage = 1;
const studentsPerPage = 20;

function updateStudentsPagination() {
    const cards = Array.from(document.querySelectorAll('#studentList > .accordion-card'));
    const container = document.getElementById('studentsPaginationContainer');
    const info = document.getElementById('studentsPageInfo');
    const btns = document.getElementById('studentsPaginationButtons');

    if (cards.length === 0) { container.style.display = 'none'; return; }

    const total = cards.length;
    const totalPages = Math.max(1, Math.ceil(total / studentsPerPage));
    if (studentsCurrentPage > totalPages) studentsCurrentPage = totalPages;
    if (studentsCurrentPage < 1) studentsCurrentPage = 1;

    container.style.display = totalPages <= 1 ? 'none' : 'flex';

    const start = (studentsCurrentPage - 1) * studentsPerPage;
    const end   = start + studentsPerPage;
    cards.forEach((c, i) => { c.style.display = (i >= start && i < end) ? '' : 'none'; });

    const s = start + 1;
    const e = Math.min(end, total);
    info.innerHTML = `Memaparkan <b>${s}–${e}</b> daripada <b>${total}</b> cawangan`;

    let html = `<button class="vm-page-btn" ${studentsCurrentPage === 1 ? 'disabled' : ''} onclick="studentsGoToPage(${studentsCurrentPage - 1})">&laquo;</button>`;
    let sp = Math.max(1, studentsCurrentPage - 2);
    let ep = Math.min(totalPages, sp + 4);
    if (ep - sp < 4) sp = Math.max(1, ep - 4);
    if (sp > 1) {
        html += `<button class="vm-page-btn" onclick="studentsGoToPage(1)">1</button>`;
        if (sp > 2) html += `<span class="vm-page-ellipsis">&hellip;</span>`;
    }
    for (let i = sp; i <= ep; i++) {
        html += `<button class="vm-page-btn ${i === studentsCurrentPage ? 'vm-page-active' : ''}" onclick="studentsGoToPage(${i})">${i}</button>`;
    }
    if (ep < totalPages) {
        if (ep < totalPages - 1) html += `<span class="vm-page-ellipsis">&hellip;</span>`;
        html += `<button class="vm-page-btn" onclick="studentsGoToPage(${totalPages})">${totalPages}</button>`;
    }
    html += `<button class="vm-page-btn" ${studentsCurrentPage === totalPages ? 'disabled' : ''} onclick="studentsGoToPage(${studentsCurrentPage + 1})">&raquo;</button>`;
    btns.innerHTML = html;
}

function studentsGoToPage(page) {
    studentsCurrentPage = page;
    updateStudentsPagination();
}

function onRowChange(e) {
    const row = e.target.closest('tr[data-id]');
    if (!row) return;
    const rowId    = row.dataset.id;
    const table    = row.closest('table[data-school]');
    if (!table) return;
    const schoolId = table.dataset.school;

    if (!_dirtyMap[schoolId]) _dirtyMap[schoolId] = new Set();

    const changed = Array.from(row.querySelectorAll('input:not([type=hidden]), select'))
        .some(el => el.dataset.orig !== undefined && el.value !== el.dataset.orig);

    if (changed) { _dirtyMap[schoolId].add(rowId); row.classList.add('row-dirty'); }
    else         { _dirtyMap[schoolId].delete(rowId); row.classList.remove('row-dirty'); }

    updateSchoolBar(schoolId);
}

function updateSchoolBar(schoolId) {
    const count   = _dirtyMap[schoolId]?.size ?? 0;
    const bar     = document.getElementById('stickyBar_' + schoolId);
    const counter = bar?.querySelector('.dirty-count');
    if (!bar) return;
    bar.style.display = 'flex';
    if (counter) counter.textContent = count;
}

function saveSchool(schoolId) {
    const form  = document.getElementById('masterSaveForm');
    const table = document.querySelector(`table[data-school="${schoolId}"]`);
    if (!table) return;

    form.querySelectorAll('.injected-input').forEach(el => el.remove());

    table.querySelectorAll('tbody tr[data-id]').forEach(row => {
        const id = row.dataset.id;
        ['student_name','level_id','gender','year'].forEach(key => {
            const el = document.querySelector(`[name="students[${id}][${key}]"]`);
            if (!el) return;
            const h = document.createElement('input');
            h.type = 'hidden';
            h.name = `students[${id}][${key}]`;
            h.value = el.value;
            h.className = 'injected-input';
            form.appendChild(h);
        });
    });

    form.submit();
}

function discardSchool(schoolId) {
    const table = document.querySelector(`table[data-school="${schoolId}"]`);
    if (!table) return;
    table.querySelectorAll('input:not([type=hidden]), select').forEach(el => {
        if (el.dataset.orig !== undefined) el.value = el.dataset.orig;
        el.closest('tr')?.classList.remove('row-dirty');
    });
    if (_dirtyMap[schoolId]) _dirtyMap[schoolId].clear();
    updateSchoolBar(schoolId);
}

function deleteStu(id) {
    if (!confirm('Padam pelajar ini?')) return;
    document.getElementById('delStuFrm').querySelector('[name=student_id]').value = id;
    document.getElementById('delStuFrm').submit();
}

function toggleBlock(id) {
    const el = document.getElementById(id);
    if (!el) return;
    const isOpen = el.style.display === 'block';
    el.style.display = isOpen ? 'none' : 'block';
    const card = el.closest('.accordion-card');
    const arrow = card?.querySelector('.school-header .arrow');
    if (arrow) arrow.style.transform = isOpen ? 'rotate(0deg)' : 'rotate(90deg)';
    if (id === 'addStudent') setTimeout(fitStudentListHeight, 0);
}

function attachDirtyListeners() {
    document.querySelectorAll('.students-table input:not([type=hidden]), .students-table select').forEach(el => {
        if (el.dataset.orig === undefined) {
            el.dataset.orig = el.value;
            el.addEventListener('change', onRowChange);
            el.addEventListener('input',  onRowChange);
        }
    });
}

function ddToggle(name) {
    const trigger = document.getElementById('ddTrigger_' + name);
    if (trigger.classList.contains('dd-trigger-disabled')) return;
    const panel = document.getElementById('ddPanel_' + name);
    const isOpen = panel.classList.contains('open');
    document.querySelectorAll('.dd-panel.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.dd-trigger.open').forEach(t => t.classList.remove('open'));
    if (!isOpen) {
        panel.classList.add('open'); trigger.classList.add('open');
        setTimeout(() => panel.querySelector('.dd-search-box input')?.focus(), 50);
    }
}

function ddFilter(name, val) {
    const opts = document.querySelectorAll('#ddOpts_' + name + ' .dd-opt');
    const empty = document.getElementById('ddEmpty_' + name);
    let any = false;
    opts.forEach(o => {
        const m = o.textContent.toLowerCase().includes(val.toLowerCase());
        o.classList.toggle('hidden', !m);
        if (m) any = true;
    });
    if (empty) empty.style.display = any ? 'none' : 'block';
}

function ddSelect(name, value, label) {
    document.getElementById('f_' + name).value = value;
    const lbl = document.getElementById('ddLabel_' + name);
    lbl.textContent = label;
    lbl.style.color = value === '' ? 'var(--c-text-faint)' : '';
    document.querySelectorAll('#ddOpts_' + name + ' .dd-opt').forEach(o => o.classList.toggle('selected', o.dataset.value === value));
    document.getElementById('ddPanel_' + name).classList.remove('open');
    document.getElementById('ddTrigger_' + name).classList.remove('open');

    if (name === 'siri') {
        loadSidangOptions(value);
    }
    ajaxFilterNow();
}

function loadSidangOptions(siriId) {
    const sessTrigger = document.getElementById('ddTrigger_session');
    const sessOpts = document.getElementById('ddOpts_session');
    const sessLbl = document.getElementById('ddLabel_session');

    document.getElementById('f_session').value = '';
    sessLbl.style.color = 'var(--c-text-faint)';

    if (!siriId) {
        sessLbl.textContent = '-- Pilih Siri dahulu --';
        sessOpts.innerHTML = "<div class='dd-opt selected' data-value='' onclick=\"ddSelect('session','','-- Semua Sidang --')\">-- Semua Sidang --</div>";
        sessTrigger.classList.add('dd-trigger-disabled');
        return;
    }
    sessLbl.textContent = '-- Semua Sidang --';
    sessOpts.innerHTML = "<div class='dd-opt selected' data-value='' onclick=\"ddSelect('session','','-- Semua Sidang --')\">-- Semua Sidang --</div>";
    sessTrigger.classList.remove('dd-trigger-disabled');

    fetch('pic_students.php?ajax_sessions=1&siri=' + encodeURIComponent(siriId))
        .then(r => r.json())
        .then(list => {
            list.forEach(s => {
                const opt = document.createElement('div');
                opt.className = 'dd-opt';
                opt.dataset.value = s.session_id;
                opt.textContent = s.session_name;
                opt.onclick = () => ddSelect('session', String(s.session_id), s.session_name);
                sessOpts.appendChild(opt);
            });
        });
}

document.addEventListener('click', e => {
    if (!e.target.closest('.dd-wrap')) {
        document.querySelectorAll('.dd-panel.open').forEach(p => p.classList.remove('open'));
        document.querySelectorAll('.dd-trigger.open').forEach(t => t.classList.remove('open'));
    }
});

// ── Fit the student list + pagination into the viewport, no page scroll ──
function fitStudentListHeight() {
    if (window.innerWidth <= 640) {
        document.getElementById('studentListScroll').style.maxHeight = '';
        return;
    }
    const scrollEl   = document.getElementById('studentListScroll');
    const pagination = document.getElementById('studentsPaginationContainer');
    const top = scrollEl.getBoundingClientRect().top;
    const paginationH = pagination.offsetHeight;
    const available = window.innerHeight - top - paginationH - 24; // 24px bottom breathing room
    scrollEl.style.maxHeight = Math.max(150, available) + 'px';
}
window.addEventListener('resize', fitStudentListHeight);

document.addEventListener('DOMContentLoaded', () => {
    _doFilter();
    fitStudentListHeight();
});
</script>

</main>
</body>
</html>