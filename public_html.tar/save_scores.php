<?php
session_start();
require __DIR__ . '/auth_check.php';
include 'db.php';
$conn = getDB();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['marks'])) {
    header("Location: judge.php");
    exit();
}

if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'judge') {
    header("Location: login.php");
    exit();
}

if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'])) {
    header("Location: judge.php?msg=invalid_request");
    exit();
}

$group_id = intval($_POST['group_id']);
$judge_id = intval($_SESSION['user_id']); // ✅ Always use session, never trust POST
$is_edit  = isset($_POST['edit_mode']) && $_POST['edit_mode'] == '1';

// ── GUARD: group_id and judge_id must be valid ───────────────────────────────
if ($group_id <= 0 || $judge_id <= 0) {
    header("Location: judge.php?msg=invalid_request");
    exit();
}

// ── STEP 1: Collect and validate marks — skip blanks ────────────────────────
$valid_marks = [];
foreach ($_POST['marks'] as $student_id => $criteria_marks) {
    $student_id = intval($student_id);
    if ($student_id <= 0) continue;

    foreach ($criteria_marks as $criteria_id => $mark_value) {
        if ($mark_value === '' || $mark_value === null) continue; // Skip unentered

        $criteria_id = intval($criteria_id);
        $mark        = intval($mark_value); // tinyint in DB — no floats needed
        if ($mark < 0 || $mark > 10) continue; // Sanity check against DB constraint

        $valid_marks[] = [
            'student_id'  => $student_id,
            'criteria_id' => $criteria_id,
            'mark'        => $mark,
        ];
    }
}

// ── GUARD: Do NOT assign judge or save anything if no marks were entered ─────
if (empty($valid_marks)) {
    header("Location: judge.php?msg=empty_submission");
    exit();
}

// ── GUARD: Ownership check — fetch who currently owns this group ─────────────
$own_stmt = $conn->prepare("SELECT judge_id, edit_used FROM `groups` WHERE group_id = ?");
$own_stmt->bind_param("i", $group_id);
$own_stmt->execute();
$own_row = $own_stmt->get_result()->fetch_assoc();
$own_stmt->close();

$current_owner   = (int)($own_row['judge_id'] ?? 0);
$edit_used_flag  = (int)($own_row['edit_used'] ?? 0);

if ($is_edit) {
    // Edit mode: only the original owner can edit, and only if edit hasn't been used yet
    if ($current_owner !== 0 && $current_owner !== $judge_id) {
        // Different judge trying to edit — reject
        header("Location: judge.php?msg=access_denied");
        exit();
    }
    if ($edit_used_flag === 1) {
        // Edit token already consumed — reject even for the owner
        header("Location: judge.php?msg=edit_locked");
        exit();
    }
} else {
    // First submission: only allowed if group is unowned
    if ($current_owner !== 0 && $current_owner !== $judge_id) {
        // Another judge already owns this group — reject
        header("Location: judge.php?msg=access_denied");
        exit();
    }
}

// ── STEP 1.5: Persist any deferred test/criteria additions from the modal ────
// The judge may have used "Tambah Peringkat & Ujian" before submitting marks.
// Nothing was written to the DB then — the selections arrived here as
// pending_params[] JSON strings. We resolve them now, atomically with the save.
if (!empty($_POST['pending_params'])) {
    foreach ($_POST['pending_params'] as $raw) {
        $entry = json_decode($raw, true);
        if (!$entry) continue;

        $lvl_id = (int)   ($entry['levelId']     ?? 0);
        $t_name = trim(    $entry['testName']     ?? '');
        $c_name = trim(    $entry['criteriaName'] ?? '');

        if ($lvl_id === 0 || $t_name === '' || $c_name === '') continue;

        // Resolve test — reuse if already exists for this level
        $tst_id = 0;
        $chkT = $conn->prepare(
            "SELECT test_id FROM tests WHERE level_id = ? AND test_name = ? LIMIT 1"
        );
        $chkT->bind_param("is", $lvl_id, $t_name);
        $chkT->execute();
        $rT = $chkT->get_result();
        if ($rT && $rT->num_rows > 0) {
            $tst_id = (int) $rT->fetch_assoc()['test_id'];
        } else {
            $insT = $conn->prepare(
                "INSERT INTO tests (level_id, test_name) VALUES (?, ?)"
            );
            $insT->bind_param("is", $lvl_id, $t_name);
            $insT->execute();
            $tst_id = (int) $conn->insert_id;
            $insT->close();
        }
        $chkT->close();

        if ($tst_id === 0) continue;

        // Resolve criteria — insert only if it doesn't already exist for this test
        $chkC = $conn->prepare(
            "SELECT criteria_id FROM criteria WHERE test_id = ? AND criteria_name = ? LIMIT 1"
        );
        $chkC->bind_param("is", $tst_id, $c_name);
        $chkC->execute();
        $rC = $chkC->get_result();
        if (!$rC || $rC->num_rows === 0) {
            $insC = $conn->prepare(
                "INSERT INTO criteria (test_id, criteria_name, max_mark) VALUES (?, ?, 10)"
            );
            $insC->bind_param("is", $tst_id, $c_name);
            $insC->execute();
            $insC->close();
        }
        $chkC->close();
    }
}


// ── STEP 3: Save scores using INSERT ... ON DUPLICATE KEY UPDATE ─────────────
// scores.test_id is NOT NULL, so it must be resolved per criteria_id
// even though the app otherwise treats test_id as derived data.
$criteria_ids = array_unique(array_column($valid_marks, 'criteria_id'));
$test_id_by_criteria = [];
if (!empty($criteria_ids)) {
    $placeholders = implode(',', array_fill(0, count($criteria_ids), '?'));
    $types = str_repeat('i', count($criteria_ids));
    $tstmt = $conn->prepare("SELECT criteria_id, test_id FROM criteria WHERE criteria_id IN ($placeholders)");
    $tstmt->bind_param($types, ...$criteria_ids);
    $tstmt->execute();
    $tres = $tstmt->get_result();
    while ($trow = $tres->fetch_assoc()) {
        $test_id_by_criteria[(int) $trow['criteria_id']] = (int) $trow['test_id'];
    }
    $tstmt->close();
}

$score_stmt = $conn->prepare("
    INSERT INTO scores (student_id, group_id, test_id, criteria_id, mark, submitted)
    VALUES (?, ?, ?, ?, ?, 1)
    ON DUPLICATE KEY UPDATE mark = VALUES(mark), submitted = 1
");

foreach ($valid_marks as $entry) {
    $test_id = $test_id_by_criteria[$entry['criteria_id']] ?? 0;
    if ($test_id === 0) continue; // criteria no longer exists — skip defensively

    $score_stmt->bind_param(
        "iiiii",
        $entry['student_id'],
        $group_id,
        $test_id,
        $entry['criteria_id'],
        $entry['mark']
    );
    $score_stmt->execute();
}
$score_stmt->close();

// ── STEP 4: Assign judge to group ONLY after scores are saved ────────────────
if ($is_edit) {
    $grp_stmt = $conn->prepare("UPDATE `groups` SET judge_id = ?, edit_used = 1 WHERE group_id = ? AND judge_id = ?");
    $grp_stmt->bind_param("iii", $judge_id, $group_id, $judge_id);
} else {
    $grp_stmt = $conn->prepare("UPDATE `groups` SET judge_id = ? WHERE group_id = ? AND (judge_id IS NULL OR judge_id = 0)");
    $grp_stmt->bind_param("ii", $judge_id, $group_id);
}
$grp_stmt->execute();
$grp_stmt->close();


// ── STEP 5: Generate a single notification for the PIC ───────────────────────
// Fetch Judge Name and Group Name so the notification is highly readable
$notif_stmt = $conn->prepare("
    SELECT j.name as judge_name, g.group_name
    FROM `groups` g
    LEFT JOIN judges j ON j.id = ?
    WHERE g.group_id = ?
");
$notif_stmt->bind_param("ii", $judge_id, $group_id);
$notif_stmt->execute();
$notif_res = $notif_stmt->get_result()->fetch_assoc();
$notif_stmt->close();

$jname = htmlspecialchars($notif_res['judge_name'] ?? 'Juri');
$gname = htmlspecialchars($notif_res['group_name'] ?? 'Tidak Diketahui');

// Differentiate the message based on whether they are new marks or edits
if ($is_edit) {
    $message = "Juri <b style='color:#E25822;'>{$jname}</b> telah mengemaskini markah untuk Kumpulan <b>{$gname}</b>.";
} else {
    $message = "Juri <b style='color:#E25822;'>{$jname}</b> telah memasukkan markah untuk Kumpulan <b>{$gname}</b>.";
}

$ins_notif = $conn->prepare("INSERT INTO notifications (message) VALUES (?)");
$ins_notif->bind_param("s", $message);
$ins_notif->execute();
$ins_notif->close();


// ── STEP 6: Redirect back to Judge Dashboard ─────────────────────────────────
header("Location: judge.php?status=success");
exit();
?>