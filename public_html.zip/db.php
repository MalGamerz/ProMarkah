<?php

define('DB_HOST',    'localhost');
define('DB_USER',    'u985209750_promarkah');
define('DB_PASS',    '9Dkrj:AidEA*');
define('DB_NAME',    'u985209750_promarkah');
define('DB_CHARSET', 'utf8mb4');

function getDB(): mysqli {
    static $conn = null;

    if ($conn !== null) {
        return $conn;
    }

    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

    try {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        $conn->set_charset(DB_CHARSET);
    } catch (mysqli_sql_exception $e) {
        error_log('Database connection failed: ' . $e->getMessage());
        http_response_code(503);
        exit('Service unavailable. Please try again later.');
    }

    return $conn;
}