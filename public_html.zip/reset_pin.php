<?php
$newPin = 'promarkah123'; // the new PIN you want
$hash = password_hash($newPin, PASSWORD_BCRYPT);

echo $hash;
