-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 10, 2025 at 07:20 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `promarkah`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `status` enum('Present','Absent') NOT NULL DEFAULT 'Absent',
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `criteria`
--

CREATE TABLE `criteria` (
  `criteria_id` int(11) NOT NULL,
  `test_id` int(11) NOT NULL,
  `criteria_name` varchar(100) NOT NULL,
  `max_mark` int(11) DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `criteria`
--

INSERT INTO `criteria` (`criteria_id`, `test_id`, `criteria_name`, `max_mark`) VALUES
(22, 1, 'Jurus 1', 10),
(23, 1, 'Jurus 2', 10),
(24, 1, 'Jurus 3', 10),
(25, 1, 'Bunga Tanjung (i)', 10),
(26, 2, 'Asas Elakan 1', 10),
(27, 2, 'Asas Elakan 2', 10),
(28, 2, 'Asas Elakan 3', 10),
(29, 24, 'Jurus 4', 10),
(30, 24, 'Jurus 5', 10),
(31, 24, 'Jurus 6', 10),
(32, 24, 'Jurus 7', 10),
(33, 24, 'Bunga Tanjung (ii)', 10),
(34, 25, 'Jurus 1', 10),
(35, 25, 'Jurus 2', 10),
(36, 25, 'Jurus 3', 10),
(37, 11, 'Asas Elakan 4', 10),
(38, 11, 'Asas Elakan 5', 10),
(39, 11, 'Elakan Tangkapan Pukulan 1', 10),
(40, 11, 'Elakan Tangkapan Pukulan 2', 10),
(41, 11, 'Elakan Tangkapan Pukulan 3', 10),
(42, 12, 'Jurus 4', 10),
(43, 12, 'Jurus 5', 10),
(44, 47, 'Gerakan Anak Harimau Pecahan 10', 10),
(45, 48, 'Serangan Anak Harimau 1', 10),
(46, 48, 'Serangan Anak Harimau 2', 10),
(47, 48, 'Serangan Anak Harimau 3', 10),
(48, 49, 'Jurus 1 - Golok', 10),
(49, 49, 'Jurus 2 - Golok', 10),
(50, 49, 'Jurus 3 - Golok', 10),
(51, 50, 'Serangan Anak Harimau 4', 10),
(52, 50, 'Serangan Anak Harimau 5', 10),
(53, 50, 'Serangan Anak Harimau 6', 10),
(54, 50, 'Serangan Anak Harimau 7', 10),
(55, 51, ' Jurus 1 ', 10),
(56, 51, ' Jurus 2', 10),
(57, 51, ' Jurus 3', 10),
(58, 44, 'Jurus 1 - Tembak Lurus Bertapak', 10),
(59, 44, 'Jurus 2 -Tangkis Atas Balas Tumbuk', 10),
(60, 44, 'Jurus 3 - Tangkis Bawah Balas Tumbuk', 10),
(61, 44, 'Jurus 4 - Tumbuk Tangkis Atas dan Bawah', 10),
(62, 44, 'Jurus 5 - Tangkis Dalam ke Bawah', 10),
(63, 44, 'Jurus 6 - Tendang Lurus Balas Tumbuk', 10),
(64, 44, 'Jurus 7 - Sepak Layang Balas Tolak Lintang', 10),
(65, 45, 'Elakan Tangkapan dan Pukulan 5', 10),
(66, 45, 'Elakan Tangkapan dan Pukulan 6', 10),
(67, 45, 'Elakan Tangkapan dan Pukulan 7', 10),
(68, 46, 'Jurus 4 - Tangan Kosong', 10),
(69, 46, 'Jurus 5 - Tangan Kosong', 10),
(70, 46, 'Jurus 6 - Tangan Kosong', 10),
(71, 46, 'Jurus 7 - Tangan Kosong', 10),
(72, 40, 'Bunga Tanjung', 10),
(73, 41, 'Jurus 1 -Tumbuk Kanan dan Kiri ke Hadapan', 10),
(74, 41, 'Jurus 2 -Tumbuk Kanan dan Kiri', 10),
(75, 41, 'Jurus 3 - Pancung Kanan dan Kiri', 10),
(76, 41, 'Jurus 4 - Tumbuk Balas Pancung', 10),
(77, 41, 'Jurus 5 - Tumbuk Tangkis Atas dan Bawah', 10),
(78, 41, 'Jurus 6 - Tendang Lurus Kanan dan Kiri', 10),
(79, 41, 'Jurus 7 - Tendang Juring Kanan dan Kiri', 10),
(80, 42, 'Elakan Tangkapan dan Pukulan 1', 10),
(81, 42, 'Elakan Tangkapan dan Pukulan 2', 10),
(82, 42, 'Elakan Tangkapan dan Pukulan 3', 10),
(83, 42, 'Elakan Tangkapan dan Pukulan 4', 10),
(84, 43, 'Jurus 1 - Tangan Kosong', 10),
(85, 43, 'Jurus 2 - Tangan Kosong', 10),
(86, 43, 'Jurus 3 - Tangan Kosong', 10),
(87, 37, 'Jurus Bergerak 6', 10),
(88, 37, 'Jurus Bergerak 7', 10),
(89, 38, 'Serangan Anak Harimau 3', 10),
(90, 38, 'Serangan Anak Harimau 4', 10),
(91, 39, 'Jurus 1', 10),
(92, 39, 'Jurus 2', 10),
(93, 39, 'Jurus 3', 10),
(94, 17, 'Jurus Bergerak 4', 10),
(95, 17, 'Jurus Bergerak 5', 10),
(96, 18, 'Serangan Anak Harimau 1', 10),
(97, 18, 'Serangan Anak Harimau 2', 10),
(98, 22, 'Jurus 1', 10),
(99, 22, 'Jurus 2', 10),
(100, 22, 'Jurus 3', 10),
(101, 15, 'Jurus Bergerak 1', 10),
(102, 15, 'Jurus Bergerak 2', 10),
(103, 15, 'Jurus Bergerak 3', 10),
(104, 16, 'Elakan Tangkapan dan Pukulan 6', 10),
(105, 16, 'Elakan Tangkapan dan Pukulan 7', 10),
(106, 21, 'Jurus 1', 10),
(107, 21, 'Jurus 2', 10),
(108, 21, 'Jurus 3', 10),
(109, 13, 'Asas Elakan 6', 10),
(110, 13, 'Asas Elakan 7', 10),
(111, 13, 'Elakan Tangkapan dan Pukulan 4', 10),
(112, 13, 'Elakan Tangkapan dan Pukulan 5', 10),
(113, 14, 'Jurus 6', 10),
(114, 14, 'Jurus 7', 10);

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE `groups` (
  `group_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `group_name` varchar(50) NOT NULL,
  `judge_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group_students`
--

CREATE TABLE `group_students` (
  `group_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `levels`
--

CREATE TABLE `levels` (
  `level_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `level_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `levels`
--

INSERT INTO `levels` (`level_id`, `session_id`, `level_name`) VALUES
(1, 1, 'Ujian Awan Putih Cula Hijau 1'),
(2, 2, 'Ujian Awan Putih Cula Hijau 2'),
(3, 2, 'Ujian Awan Putih Cula Hijau 3'),
(4, 3, 'Ujian Awan Putih Cula Merah 1'),
(5, 3, 'Ujian Awan Putih Cula Merah 2'),
(6, 3, 'Ujian Awan Putih Cula Merah 3'),
(7, 3, 'Ujian Awan Putih Cula Kuning 1'),
(8, 3, 'Ujian Awan Putih Cula Kuning 2'),
(9, 3, 'Ujian Awan Putih Cula Kuning 3'),
(13, 3, 'Ujian Awan Putih Cula Merah 1 - Menengah'),
(14, 3, 'Ujian Awan Putih Cula Merah 3 - Menengah'),
(15, 3, 'Ujian Awan Putih Cula Kuning 1 - Menengah'),
(16, 3, 'Ujian Awan Putih Cula Kuning 3 - Menengah');

-- --------------------------------------------------------

--
-- Table structure for table `schools`
--

CREATE TABLE `schools` (
  `school_id` int(11) NOT NULL,
  `school_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schools`
--

INSERT INTO `schools` (`school_id`, `school_name`) VALUES
(1, 'SMK TAMAN DESA TEBRAU'),
(2, 'SRITI ILMI'),
(3, 'KANGKAR PULAI – SEKOLAH MENENGAH'),
(4, 'KANGKAR PULAI – SESI 1'),
(5, 'KANGKAR PULAI – SESI 2 & 3'),
(6, 'KANGKAR PULAI – SESI 4 & 5'),
(7, 'KANGKAR PULAI – SESI 6 & 7'),
(8, 'KANGKAR PULAI – SESI 8'),
(9, 'KANGKAR PULAI – SESI 9 & 11'),
(10, 'KANGKAR PULAI – SESI 10 & 12'),
(11, 'TAMAN UNIVERSITI'),
(12, 'TAMAN ANGGERIK'),
(13, 'LARKIN'),
(14, 'MASJID BANDAR UDA UTAMA'),
(15, 'SMK TDT'),
(16, 'KANGKAR PULAI - DEWASA'),
(17, 'MASJID BANDAR BARU UDA');

-- --------------------------------------------------------

--
-- Table structure for table `scores`
--

CREATE TABLE `scores` (
  `score_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `criteria_id` int(11) NOT NULL,
  `mark` float DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `session_id` int(11) NOT NULL,
  `session_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`session_id`, `session_name`) VALUES
(1, 'Sidang 1'),
(2, 'Sidang 2'),
(3, 'Sidang 3');

-- --------------------------------------------------------

--
-- Table structure for table `session_schools`
--

CREATE TABLE `session_schools` (
  `id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `school_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `session_schools`
--

INSERT INTO `session_schools` (`id`, `session_id`, `school_id`) VALUES
(1, 1, 2),
(2, 1, 10),
(3, 1, 11),
(4, 1, 14),
(5, 1, 9),
(6, 1, 10),
(7, 2, 2),
(8, 2, 7),
(9, 2, 8),
(10, 2, 9),
(11, 2, 11),
(12, 2, 12),
(13, 2, 13),
(14, 2, 14),
(15, 3, 1),
(16, 3, 2),
(17, 3, 3),
(18, 3, 4),
(19, 3, 5),
(20, 3, 6),
(21, 3, 7),
(22, 3, 11),
(23, 3, 12),
(24, 3, 13),
(25, 3, 14);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `student_id` int(11) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `level_id` int(11) DEFAULT NULL,
  `school_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `gender` enum('Male','Female') DEFAULT 'Male',
  `age` int(11) NOT NULL
) ;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`student_id`, `student_name`, `level_id`, `school_id`, `date`, `gender`, `age`) VALUES
(383, 'Afiq Mukhriz Bin Faisal Riza', 8, 15, '2025-12-31', '', 13),
(384, 'Adam Safwan Bin Nasharudin', 7, 15, '2025-12-31', '', 13),
(385, 'Amir Zayed Bin Mohd Sahari', 7, 15, '2025-12-31', '', 13),
(386, 'Mohamad Nabil Nasrullah Bin Mohamad Azli', 7, 15, '2025-12-31', '', 13),
(387, 'Muhammad Izwan Aris Bin Abdullah', 7, 15, '2025-12-31', '', 13),
(388, 'Noraziman Bin Zolkefle', 7, 15, '2025-12-31', '', 13),
(389, 'Syed Ali Hamzah Bin Syed Shah Khalid', 7, 15, '2025-12-31', '', 13),
(390, 'Mia Nur Insyirah Binti Fauzi', 6, 15, '2025-12-31', '', 13),
(391, 'Nur Dini Qaisara Binti Mohd Fazli', 6, 15, '2025-12-31', '', 13),
(392, 'Ahmad Akhir Izzani Bin Mizan', 6, 15, '2025-12-31', '', 13),
(393, 'Mohamad Adam Daniel Bin Abdullah', 6, 15, '2025-12-31', '', 13),
(394, 'Mohamad Al Fatih Bin Mohamed Esa', 6, 15, '2025-12-31', '', 13),
(395, 'Muhammad Darius Zafran Bin Mahadzir', 6, 15, '2025-12-31', '', 13),
(396, 'Muhammad Qayyum Bin Ab. Aziz', 6, 15, '2025-12-31', '', 13),
(397, 'Muhammad Zarif Zikri Bin Mohd Azrai', 6, 15, '2025-12-31', '', 13),
(398, 'Zamatul Fahmi Mikail Bin Zamatul Amri', 6, 15, '2025-12-31', '', 13),
(399, 'Ferry Nizam Bin Herman', 3, 15, '2025-12-31', '', 13),
(400, 'Muhammad Daniel Zulkarnain Bin Abdullah', 3, 15, '2025-12-31', '', 13),
(401, 'Nur Anis Amani Binti Abd Rahman', 4, 2, '2025-12-31', '', 10),
(402, 'Muhammad Abbas Bin Mohd Zuhaili', 4, 2, '2025-12-31', '', 10),
(403, 'Muhammad Az Zuhri Bin Tarmizi', 4, 2, '2025-12-31', '', 10),
(404, 'Putera Amsyar Fayyadh Bin Mohammed Firdaus', 4, 2, '2025-12-31', '', 10),
(405, 'Amrah Zafirah Binti Tarmizi', 3, 2, '2025-12-31', '', 5),
(406, 'Puteri Alisya Binti Mohammed Firdaus', 3, 2, '2025-12-31', '', 5),
(407, 'Muhammad Adiy Zihny Bin Mohd.zamirudin', 3, 2, '2025-12-31', '', 5),
(408, 'Muhammad Khair Tsaqif Bin Muhammad Khalqia', 3, 2, '2025-12-31', '', 5),
(409, 'Muhammad Naufal Khairi Bin Mohd Helmi', 3, 2, '2025-12-31', '', 5),
(410, 'Muhammad Umar Al-Farouq Bin Muhammad Saufi', 3, 2, '2025-12-31', '', 5),
(411, 'Muhammad Umar Bin Mohd Zuhaili', 3, 2, '2025-12-31', '', 5),
(412, 'Muhammad Zarif Amjad Bin Mohd Yazid', 3, 2, '2025-12-31', '', 5),
(413, 'Rhea Qaila Al Mahyra Binti Samsul', 2, 2, '2025-12-31', '', 5),
(414, 'Muhammad ?Imran Khairi Bin Mohd Shamlan', 2, 2, '2025-12-31', '', 5),
(415, 'Muhammad Khairun Nasirin Bin Mat Hussin', 2, 2, '2025-12-31', '', 10),
(416, 'Marya Lufya Binti Mohamad Humaizi', 1, 2, '2025-12-31', '', 5),
(417, 'Nayla Humaira Binti Suhail', 1, 2, '2025-12-31', '', 5),
(418, 'Nur Qaireen Darwisya Binti Ahmad Iskandar', 1, 2, '2025-12-31', '', 5),
(419, 'Ufairah An Nailah Binti Muhammad Saufi', 1, 2, '2025-12-31', '', 5),
(420, 'Wafa Zulaikha Binti Mohd Khairul Farkham', 1, 2, '2025-12-31', '', 5),
(421, 'Abdullah Az Zubayr Bin Zulnizzam', 1, 2, '2025-12-31', '', 5),
(422, 'Ahmad Adam Al Fateh Bin Mohd Nashih Ulwan', 1, 2, '2025-12-31', '', 5),
(423, 'Asyraff Muallim Bin Mohd Khairul Farkham', 1, 2, '2025-12-31', '', 5),
(424, 'Dhamir Harraz Bin Mohammad Afiff', 1, 2, '2025-12-31', '', 5),
(425, 'Muhammad Arshad Bin Khairul Zaman', 1, 2, '2025-12-31', '', 5),
(426, 'Muhammad Eshan Bin Muhammad Syafiq', 1, 2, '2025-12-31', '', 5),
(427, 'Muhammad Khair Syauqie Bin Muhammad Khalqia', 1, 2, '2025-12-31', '', 5),
(428, 'Muhammad Razin Firas Bin Mohd Helmi', 1, 2, '2025-12-31', '', 5),
(429, 'Muhammad Zarif Afnan Bin Mohd Yazid', 1, 2, '2025-12-31', '', 5),
(430, 'Syifaa? Bin Ahmad Qurrata Ain', 1, 2, '2025-12-31', '', 5),
(431, 'Uwais Bin Mohd Fadhil', 1, 2, '2025-12-31', '', 5),
(432, 'Aifa Afryna Binti Helmi Adly', 9, 3, '2025-12-31', '', 13),
(433, 'Hayfa Allesya Binti Mohd Hasril', 7, 3, '2025-12-31', '', 13),
(434, 'Puteri Aisyah Humayra Binti Megat Rizal Helmey', 7, 3, '2025-12-31', '', 13),
(435, 'Sharifah Nurhumaira Binti Syed Muhammad Zakwan', 7, 3, '2025-12-31', '', 13),
(436, 'Arfa Muslim Bin Mohd Fazli', 7, 3, '2025-12-31', '', 13),
(437, 'Muhammad Adam Syahmi Bin Hasibah', 7, 3, '2025-12-31', '', 13),
(438, 'Muhammad Amar Izzuddin Bin Mohd Amrizul Zahri', 7, 3, '2025-12-31', '', 13),
(439, 'Muhammad Izz Rayyan Rifqi Bin Mohd Khairuddin', 7, 3, '2025-12-31', '', 13),
(440, 'Noor Akmal Syazwan Bin Noor Azlan', 7, 3, '2025-12-31', '', 13),
(441, 'Airis Aryssa Binti Helmi Adly', 7, 4, '2025-12-31', '', 10),
(442, 'Arfa Imaani Bt. Ihsan Sobri', 7, 4, '2025-12-31', '', 10),
(443, 'Nur Aina Fatihah Binti Rosnizam', 7, 4, '2025-12-31', '', 10),
(444, 'Ali Izzudin Bin Rosnizam', 7, 4, '2025-12-31', '', 13),
(445, 'Umar Solihin Bin Rosnizam', 7, 4, '2025-12-31', '', 10),
(446, 'Wan Muhammad Hazim Bin Wan Mohd Fahrul Rozy', 7, 4, '2025-12-31', '', 10),
(447, 'Adni Damia Mohd Rizal', 4, 3, '2025-12-31', '', 13),
(448, 'Nur Huda Binti Khairul Anuar', 4, 3, '2025-12-31', '', 13),
(449, 'Nurin Darwisyah Uzma Bt Rosnizan', 4, 3, '2025-12-31', '', 13),
(450, 'Nurul Khairin Eshal Bte Mohd.herwan', 4, 3, '2025-12-31', '', 13),
(451, 'Qaseh Qurratul Aini Binti Abd Razak', 4, 3, '2025-12-31', '', 13),
(452, 'Muhammad Norhafize Bin Azmi', 4, 3, '2025-12-31', '', 16),
(453, 'Muhammad Rifqi Rozadi Bin Abdul Rahman', 4, 3, '2025-12-31', '', 13),
(454, 'Muhammad Taufieeq Bin Maharam', 4, 3, '2025-12-31', '', 16),
(455, 'Raiyan Amir Bin Mohamad Raziz', 4, 3, '2025-12-31', '', 13),
(456, 'Aisyah Haziqah Binti Afiq Aiman', 5, 5, '2025-12-31', '', 10),
(457, 'Inas Arissa Binti Ainol Izzat', 5, 5, '2025-12-31', '', 10),
(458, 'Nur Amani Binti Mohd Shaiful Azlan', 5, 5, '2025-12-31', '', 13),
(459, 'Raja Aisyah Humaira Binti Raja Mohd Hafriz', 5, 5, '2025-12-31', '', 10),
(460, 'Nur Jannah Binti Mohd Shaiful Azlan', 5, 5, '2025-12-31', '', 10),
(461, 'Nurin Zara Afrina Binti Abdul Muiz', 5, 5, '2025-12-31', '', 10),
(462, 'Sharifah Nurhairien Binti Syed Muhammad Zakwan', 5, 5, '2025-12-31', '', 5),
(463, 'Sharifah Nurhairiena Binti Syed Muhammad Zakwan', 5, 5, '2025-12-31', '', 10),
(464, 'Wan Nur Sofea Binti Wan Mohd Fahrul Rozy', 5, 5, '2025-12-31', '', 5),
(465, 'Adam Harraz Bin Nor Azmi', 5, 5, '2025-12-31', '', 5),
(466, 'Afwan Fahri Bin Izuddin Shah', 5, 5, '2025-12-31', '', 10),
(467, 'Ammar Harith Bin Muhamed Latife', 5, 5, '2025-12-31', '', 10),
(468, 'Daniyal Izz Rizqi Bin Ainol Izzat', 5, 5, '2025-12-31', '', 10),
(469, 'Fathul Amiin Bin Khairul Nizam', 5, 5, '2025-12-31', '', 10),
(470, 'Khalil Zarif Bin Mohd Zaki', 5, 5, '2025-12-31', '', 10),
(471, 'Khayr Zahran Bin Mohd Zaki', 5, 5, '2025-12-31', '', 5),
(472, 'Muawwiz Zuhayr Bin Mohd Zaki', 5, 5, '2025-12-31', '', 5),
(473, 'Muhammad Adam Zikri Bin Mohd Khairuddin', 5, 5, '2025-12-31', '', 10),
(474, 'Muhammad Afirul Adha Bin Muhammad Azral', 5, 5, '2025-12-31', '', 13),
(475, 'Muhammad Danish Irfan Bin Kamarul Ariffin', 5, 5, '2025-12-31', '', 10),
(476, 'Muhammad Naeemullah Bin Mohamad Shukri', 5, 5, '2025-12-31', '', 10),
(477, 'Muhammad Zahin Al Aisy Bin Mohd Zaki', 5, 5, '2025-12-31', '', 10),
(478, 'Noah Ayden Bin Rahmat', 5, 5, '2025-12-31', '', 5),
(479, 'Zunnur Rifqi Bin Mohd Zaharin', 5, 5, '2025-12-31', '', 13),
(480, 'Afeeya Sumayyah Bt Izuddin Shah', 4, 6, '2025-12-31', '', 5),
(481, 'Aisy Irfan Bin Mohd Nur Idham', 4, 6, '2025-12-31', '', 5),
(482, 'Amalisa Binti Mohd Noor', 4, 6, '2025-12-31', '', 10),
(483, 'Fatima Az Zahra Binti Aniq Syazwan', 4, 6, '2025-12-31', '', 10),
(484, 'Hasanatul Husna Binti Mohd Syafiq', 4, 6, '2025-12-31', '', 5),
(485, 'Izz Ziqrie B Mohd Nor Azhar', 4, 6, '2025-12-31', '', 10),
(486, 'Khalish Naufal Bin Abdul Karim', 4, 6, '2025-12-31', '', 10),
(487, 'Khalish Rayyan Bin Abdul Karim', 4, 6, '2025-12-31', '', 5),
(488, 'Muhammad Adam Mukhlis Bin Mohd Firdaus', 4, 6, '2025-12-31', '', 10),
(489, 'Muhammad Ashraf Haziq Bin Aziz', 4, 6, '2025-12-31', '', 10),
(490, 'Muhammad Raiyan Arsyad Bin Muhammad Sufian', 4, 6, '2025-12-31', '', 10),
(491, 'Muhammad Raiyan Zarif Bin Muhammad Sufian', 4, 6, '2025-12-31', '', 5),
(492, 'Muhammad Wafi Bin Muhamad Farid', 4, 6, '2025-12-31', '', 5),
(493, 'Muhammad Waiz Bin Muhamad Farid', 4, 6, '2025-12-31', '', 10),
(494, 'Nur Athirah Binti Mohd Khairul Anuar', 4, 6, '2025-12-31', '', 5),
(495, 'Nur Fatihah Mohd Faiz', 4, 6, '2025-12-31', '', 10),
(496, 'Nur Hasanah Safiyya Binti Mohd Firdaus', 4, 6, '2025-12-31', '', 10),
(497, 'Nur Qaisarah Mohd Faiz', 4, 6, '2025-12-31', '', 10),
(498, 'Nur Qaliesha Humayra Bt Aziz', 4, 6, '2025-12-31', '', 5),
(499, 'Nurfarisha Hawani Binti Sakim', 4, 6, '2025-12-31', '', 10),
(500, 'Siti Nur Aisyah Binti Mohd Firdaus', 4, 6, '2025-12-31', '', 5),
(501, 'Aafiyah Khayla Binti Mohd Heidir', 4, 7, '2025-12-31', '', 10),
(502, 'Nur Arissa Badriyya Bt Baharuddin', 4, 7, '2025-12-31', '', 10),
(503, 'Amsyar Bazlisyah Bin Baharuddin', 4, 7, '2025-12-31', '', 5),
(504, 'Mirza Hanif Bin Mazrim', 4, 7, '2025-12-31', '', 10),
(505, 'Muhammad Firas Ali', 4, 7, '2025-12-31', '', 5),
(506, 'Muhammad Iqram Tasnim Rizal Bin Abdul Azim', 4, 7, '2025-12-31', '', 5),
(507, 'Muhammad Thaqif Taqiuddin Bin Azli', 4, 7, '2025-12-31', '', 5),
(508, 'Muhammad Uqail Taqiuddin Bin Azli', 4, 7, '2025-12-31', '', 10),
(509, 'Muhammad Ziyad Taqiuddin Bin Azli', 4, 7, '2025-12-31', '', 10),
(510, 'Raja Muhammad Nasrulhaq Bin Raja Mohd Hafriz', 4, 7, '2025-12-31', '', 5),
(511, 'Airish Medina Bt Muhammad Hairul Adzhar', 3, 7, '2025-12-31', '', 10),
(512, 'Aisyah Binti Mohammad Taufik', 3, 7, '2025-12-31', '', 10),
(513, 'Awfiyah Adriani Binti Ahmad Saifuddin', 3, 7, '2025-12-31', '', 5),
(514, 'Najwa Marissa Alfahmi', 3, 7, '2025-12-31', '', 10),
(515, 'Nurlaylah Khalish Binti Mohammed Khairul Anwar', 3, 7, '2025-12-31', '', 10),
(516, 'Raisya Medina Binti Muhammad Termizi', 3, 7, '2025-12-31', '', 5),
(517, 'Akhtar Ameeruddin Bin Ahmad Saifuddin', 3, 7, '2025-12-31', '', 10),
(518, 'Alfaqeh Alfahmi', 3, 7, '2025-12-31', '', 5),
(519, 'Ammar Amsyar Bin Adam Aizuddin', 3, 7, '2025-12-31', '', 5),
(520, 'Asyraf Bin Mohammad Taufik', 3, 7, '2025-12-31', '', 5),
(521, 'Firas Azmi Bin Helmi Azmi', 3, 7, '2025-12-31', '', 5),
(522, 'Harith Mikael Bin Mazrim', 3, 7, '2025-12-31', '', 5),
(523, 'Khalish Ramadhan Bin Mohammed Khairul Anwar', 3, 7, '2025-12-31', '', 5),
(524, 'Megat Hassan Muhafiz Bin Megat Rizal Helmey', 3, 7, '2025-12-31', '', 5),
(525, 'Muhammad Al-Fateh Bin Mohd Taufik Rizal', 3, 7, '2025-12-31', '', 10),
(526, 'Muhammad Anas Bin Mohd Taufik Rizal', 3, 7, '2025-12-31', '', 5),
(527, 'Muhammad Emir Faezeen Bin Muhammad Ezuan', 3, 7, '2025-12-31', '', 5),
(528, 'Muhammad Rifqi Bin Muhammad Termizi', 3, 7, '2025-12-31', '', 10),
(529, 'Muhammad Saif Aidan Bin Muhammad Ikhmal', 3, 7, '2025-12-31', '', 5),
(530, 'Muhammad Saif Aidin Bin Muhammad Ikhmal', 3, 7, '2025-12-31', '', 5),
(531, 'Noor Aryan Rizqi Bin Noor Aminudin', 3, 7, '2025-12-31', '', 10),
(532, 'Noor Raden Rizqi Bin Noor Aminudin', 3, 7, '2025-12-31', '', 10),
(533, 'Ryu Shaqeel Bin Mohd Saharudin', 3, 7, '2025-12-31', '', 5),
(534, 'Tariq Ziyad Bin Mohd Taufik Rizal', 3, 7, '2025-12-31', '', 10),
(535, 'Umar Faaiz Bin Abdul Qahhaar', 3, 7, '2025-12-31', '', 10),
(536, 'Zaffran Noah Bin Muhammad Hairul Adzhar', 3, 7, '2025-12-31', '', 5),
(537, 'Aira Aryana Binti Helmi Adly', 3, 8, '2025-12-31', '', 5),
(538, 'Nur Hana Binti Khairul Anuar', 3, 8, '2025-12-31', '', 10),
(539, 'Nur Khalishah Amani Binti Mohd Azwandi', 3, 8, '2025-12-31', '', 5),
(540, 'Wan Nur Hazirah Binti Wan Mohd Fahrul Rozi', 3, 8, '2025-12-31', '', 5),
(541, 'Aisar Asyraf Bin Helmi Adly', 3, 8, '2025-12-31', '', 5),
(542, 'Arfan Ilman Bin Ihsan Sobri', 3, 8, '2025-12-31', '', 5),
(543, 'Hud Aysar Bin Rahmat', 3, 8, '2025-12-31', '', 5),
(544, 'Khalish Amsyar Bin Mohd Azwandi', 3, 8, '2025-12-31', '', 5),
(545, 'Mohammad Danish Thaqif', 3, 8, '2025-12-31', '', 10),
(546, 'Muhammad Al Fateh', 3, 8, '2025-12-31', '', 5),
(547, 'Muhammad Amar Irfan Bin Mohd Amrizul Zahri', 3, 8, '2025-12-31', '', 10),
(548, 'Muhammad Arsyad Zahin Bin Mohd Salihin', 3, 8, '2025-12-31', '', 10),
(549, 'Muhammad Asyraf Zahin Bin Mohd Salihin', 3, 8, '2025-12-31', '', 10),
(550, 'Muhammad Luqmanul Hakim', 3, 8, '2025-12-31', '', 5),
(551, 'Umar Ziyad Bin Zahari', 3, 8, '2025-12-31', '', 5),
(552, 'Nur Hanania Nashwa Binti Mohd Yazid', 2, 9, '2025-12-31', '', 5),
(553, 'Nurul Khairin Lashira Bte Mohd.herwan', 2, 9, '2025-12-31', '', 5),
(554, 'Aif Fahim Bin Noormuhamad Azrol', 2, 9, '2025-12-31', '', 5),
(555, 'Aqil Anaqi Bin Abdul Mutholeb', 2, 9, '2025-12-31', '', 5),
(556, 'Muhammad Afiq Bin Kamarul Hanif', 2, 9, '2025-12-31', '', 10),
(557, 'Muhammad Afiq Ziqri Bin Muhamad Fauzi', 2, 9, '2025-12-31', '', 5),
(558, 'Muhammad Amar Niyaz Bin Mohd Yazid', 2, 9, '2025-12-31', '', 10),
(559, 'Muhammad Aqif Bin Kamarul Hanif', 2, 9, '2025-12-31', '', 5),
(560, 'Muhammad Hasif', 2, 9, '2025-12-31', '', 5),
(561, 'Muhammad Qabil Khalifah Bin Mohammad Shah Khalifah', 2, 9, '2025-12-31', '', 5),
(562, 'Muhammad Qayyim Khalifah Bin Mohammad Shah Khalifah', 2, 9, '2025-12-31', '', 5),
(563, 'Muhammad Qhair Nawfal Bin Md Zapi', 2, 9, '2025-12-31', '', 5),
(564, 'Muhammad Thaqif', 2, 9, '2025-12-31', '', 10),
(565, 'Muhammad Zafri Bin Mohd Nur Hafiz', 2, 9, '2025-12-31', '', 5),
(566, 'Muhammad Zarif Bin Mohd Nur Hafiz', 2, 9, '2025-12-31', '', 10),
(567, 'Muhammad Zunnur Iman Bin Muhammad Farhan', 2, 9, '2025-12-31', '', 10),
(568, 'Nufail Asyraf Bin Idlan Zarizi', 2, 9, '2025-12-31', '', 13),
(569, 'Aisyah Nur Iman Binti Safarin', 1, 9, '2025-12-31', '', 5),
(570, 'Aulia Izzatunnisha', 1, 9, '2025-12-31', '', 10),
(571, 'Damia Batrisya Azhar Binti Abdun Nafi', 1, 9, '2025-12-31', '', 5),
(572, 'Mawar Medina Binti Muhamad Aiman Faris', 1, 9, '2025-12-31', '', 5),
(573, 'Nawlaa Asyiffa Binti Nuhammad Asyraf', 1, 9, '2025-12-31', '', 5),
(574, 'Nur Dhia Delisha Binti Mohd Norizam', 1, 9, '2025-12-31', '', 5),
(575, 'Nur Ezra Feerda Binti Muhammad Ezuan', 1, 9, '2025-12-31', '', 5),
(576, 'Abqori Hafiz Bin Mohd Hirzi', 1, 9, '2025-12-31', '', 5),
(577, 'Adam Daniel Bin Zulazri', 1, 9, '2025-12-31', '', 10),
(578, 'Adam Wafiy Bin Zulazri', 1, 9, '2025-12-31', '', 5),
(579, 'Hadi Izz Faaeq Bin Muhammad Saufi', 1, 9, '2025-12-31', '', 5),
(580, 'Haris Mateen Bin Mohamad Zulhilmi', 1, 9, '2025-12-31', '', 5),
(581, 'Mohamad Amir Almukmin Bin Mohamad Firdaus', 1, 9, '2025-12-31', '', 5),
(582, 'Muhamad Harith Aidil Bin Muhamad Hairy', 1, 9, '2025-12-31', '', 5),
(583, 'Muhammad Adam Bin Mohd Afandi', 1, 9, '2025-12-31', '', 5),
(584, 'Muhammad Aidan Hafiy Bin Mohd Hasbullah', 1, 9, '2025-12-31', '', 5),
(585, 'Muhammad Ariff Ariqin Bin Azizi', 1, 9, '2025-12-31', '', 5),
(586, 'Muhammad Aryan Hafidh Bin Mohd Hasbullah', 1, 9, '2025-12-31', '', 5),
(587, 'Muhammad Bin Mohd Yusof', 1, 9, '2025-12-31', '', 5),
(588, 'Muhammad Daiyan Anaqi Bin Mohd Hasruldani', 1, 9, '2025-12-31', '', 5),
(589, 'Muhammad Harraz Naufal Bin Abdul Hakim', 1, 9, '2025-12-31', '', 5),
(590, 'Muhammad Isyraq Iman Bin Nadzreeq', 1, 9, '2025-12-31', '', 5),
(591, 'Muhammad Radhi Bin Mohd Ridhwan', 1, 9, '2025-12-31', '', 10),
(592, 'Muhammad Rayyan Bin Mohd Ridhwan', 1, 9, '2025-12-31', '', 5),
(593, 'Muhammad Rayyan Nabil Bin Mohd Najib', 1, 9, '2025-12-31', '', 5),
(594, 'Muhammad Wafiy Iman Bin Muhamad Yuslee', 1, 9, '2025-12-31', '', 5),
(595, 'Neil Umar Bin Muhammad Nazri', 1, 9, '2025-12-31', '', 5),
(596, 'Noah Ismail Bin Muhammad Nazri', 1, 9, '2025-12-31', '', 5),
(597, 'Norsyahir Darwisy Bin Mohd Senin', 1, 9, '2025-12-31', '', 10),
(598, 'Saraneesan A/L Athavan', 1, 9, '2025-12-31', '', 10),
(599, 'Umar Zafran Bin Mohamad Zulhilmi', 1, 9, '2025-12-31', '', 5),
(600, 'Yusuf Ammar Bin Md Zainal Abidin', 1, 9, '2025-12-31', '', 5),
(601, 'Nor Dhia Zainab Binti Abdullah', 1, 10, '2025-12-31', '', 10),
(602, 'Nur Adriana Arissa Binti Mohd Nazri', 1, 10, '2025-12-31', '', 10),
(603, 'Nur Keisha Nuha Binti Khirul Ikwan', 1, 10, '2025-12-31', '', 10),
(604, 'Nur Khayra Hana Binti Khirul Ikwan', 1, 10, '2025-12-31', '', 5),
(605, 'Nur Qisya Sumayyah Binti Mohd Khataman', 1, 10, '2025-12-31', '', 5),
(606, 'Nur Zahra Sofea', 1, 10, '2025-12-31', '', 10),
(607, 'Putri Rifda Zayyaani Bt Mohamad Shahrizal', 1, 10, '2025-12-31', '', 5),
(608, 'Abdurrahman Bin Muhamad Azwan', 1, 10, '2025-12-31', '', 5),
(609, 'Adam Mu?iz Bin Ahmad Fauzani', 1, 10, '2025-12-31', '', 10),
(610, 'Ahmed Voorel', 1, 10, '2025-12-31', '', 5),
(611, 'Anas Mikael Bin Ahmad Fauzani', 1, 10, '2025-12-31', '', 5),
(612, 'Baihaqqi Muslim Bin Syahrul Ruzuan', 1, 10, '2025-12-31', '', 5),
(613, 'Fathul Rafeeq Bin Mohd Fadali', 1, 10, '2025-12-31', '', 5),
(614, 'Fathul Rifqee Bin Mohd Fadali', 1, 10, '2025-12-31', '', 5),
(615, 'Izz Raqib Bin Azri Luqman', 1, 10, '2025-12-31', '', 5),
(616, 'Mohamad Ziyad Fazle Bin Mohamad Fauzi', 1, 10, '2025-12-31', '', 5),
(617, 'Muhammad Adam Aqasya Bin Mohd Khataman', 1, 10, '2025-12-31', '', 10),
(618, 'Muhammad Adam Naufal Bin Ahmad', 1, 10, '2025-12-31', '', 5),
(619, 'Muhammad Afif Al Fateh Bin Mohamad Akmal', 1, 10, '2025-12-31', '', 5),
(620, 'Muhammad Rahman Asyraf Bin Syaiful Anuar', 1, 10, '2025-12-31', '', 5),
(621, 'Muhammad Razeen Jalil Bin Syaiful Anuar', 1, 10, '2025-12-31', '', 10),
(622, 'Muhammad Zakwanhelmi Bin Mohd Fairudin', 1, 10, '2025-12-31', '', 5),
(623, 'Raja Muhammad Naqiuddin Bin Raja Mohd Hafriz', 1, 10, '2025-12-31', '', 5),
(624, 'Adwa Rayqah Bt Mohd Fauzi', 4, 11, '2025-12-31', '', 10),
(625, 'Adwa Rizqah Bt Mohd Fauzi', 4, 11, '2025-12-31', '', 10),
(626, 'Nur Aleesya Humaira Bt Hishamuddin', 4, 11, '2025-12-31', '', 10),
(627, 'Nur Hasanah Bt Muhammad Lutfi', 4, 11, '2025-12-31', '', 5),
(628, 'Nur Humaira Bt Maslizan', 4, 11, '2025-12-31', '', 5),
(629, 'Nur Husnina Umairah Binti Mohd Hasmidi', 4, 11, '2025-12-31', '', 13),
(630, 'Wan Nureen Qhalisya Bt Wan Hazli', 4, 11, '2025-12-31', '', 10),
(631, 'Airil Iffat Bin Mohd Aizat', 4, 11, '2025-12-31', '', 10),
(632, 'Fatehul Khaleef B. Mohd. Fairos', 4, 11, '2025-12-31', '', 10),
(633, 'Mohammad Rayyan Darwish Bin Mohd Mustaqim', 4, 11, '2025-12-31', '', 5),
(634, 'Muhammad Adam Aish Bin Mohd Nur Khafiz', 4, 11, '2025-12-31', '', 10),
(635, 'Muhammad Adam Haqim Bin Mohd Hairul Anuar', 4, 11, '2025-12-31', '', 10),
(636, 'Muhammad Alghazali Bin Mohd Muzamar', 4, 11, '2025-12-31', '', 10),
(637, 'Muhammad Aliff Aish Bin Mohd Nur Khafiz', 4, 11, '2025-12-31', '', 5),
(638, 'Wan Nafeez Qhalif Bin Wan Hazli', 4, 11, '2025-12-31', '', 13),
(639, 'Yusuf Mikael Bin Muhammad Syakir', 4, 11, '2025-12-31', '', 5),
(640, 'Na?ila Farisyah Binti Mohd Fadzil', 3, 11, '2025-12-31', '', 10),
(641, 'Puteri Eris Binti Jamaluddin', 3, 11, '2025-12-31', '', 10),
(642, 'Radin Anisah Zulaikha Binti Radin Md Asnawi Nazaruddin', 3, 11, '2025-12-31', '', 13),
(643, 'Radin Ayu Zuhaira Binti Radin Md Asnawi Nazaruddin', 3, 11, '2025-12-31', '', 5),
(644, 'Dg Muhammad Aariz Bin Dg Mohd Al Hafidz', 3, 11, '2025-12-31', '', 5),
(645, 'Dg Muhammad Ammar Bin Dg Mohd Al Hafidz', 3, 11, '2025-12-31', '', 10),
(646, 'Dg Muhammad Harraz Bin Dg Mohd Al Hafidz', 3, 11, '2025-12-31', '', 5),
(647, 'Na?il Furqan Mikail Bin Mohd Fadzil', 3, 11, '2025-12-31', '', 13),
(648, 'Ahmad Imran Bin Shaiful', 2, 11, '2025-12-31', '', 5),
(649, 'Nur Aisyah Binti Shaiful', 2, 11, '2025-12-31', '', 13),
(650, 'Amani Nazran Binti Mohd Zul Azman', 1, 11, '2025-12-31', '', 10),
(651, 'Khadijah Yusra Binti Khairul Nizam', 1, 11, '2025-12-31', '', 5),
(652, 'Nur Husnia Zahra Binti Mohd Hasmidi', 1, 11, '2025-12-31', '', 5),
(653, 'Nur Jasmin Medina Binti Muhammad Izzat', 1, 11, '2025-12-31', '', 5),
(654, 'Nur Raisha Qairina Bt Omar', 1, 11, '2025-12-31', '', 10),
(655, 'Airis Zulaikha Binti Mohd Aizat', 1, 11, '2025-12-31', '', 5),
(656, 'Raisya Sumayyah Binti Shahres Ammerul', 1, 11, '2025-12-31', '', 10),
(657, 'Najla Insyirah Bt. Mohd Fairos', 1, 11, '2025-12-31', '', 5),
(658, 'Qisya Athirah Binti Zamani', 1, 11, '2025-12-31', '', 5),
(659, 'Khayra Marsya Binti Mohd Khairi Amri', 1, 11, '2025-12-31', '', 5),
(660, 'Daanya Natasya Chuah Binti Muhammad Syibli', 1, 11, '2025-12-31', '', 5),
(661, 'Nur Aisyah Insyirah Binti Ashraff', 1, 11, '2025-12-31', '', 5),
(662, 'Ainul Mardhiah Binti Faiz', 1, 11, '2025-12-31', '', 5),
(663, 'Afham Rifqi Bin Reynullah', 1, 11, '2025-12-31', '', 10),
(664, 'Ahmad Nazran Bin Mohd Zul Azman', 1, 11, '2025-12-31', '', 5),
(665, 'Fauzann Bin Muhammad Syafiq', 1, 11, '2025-12-31', '', 5),
(666, 'Fayyadh Fakrullah Qusyairi Bin Othman', 1, 11, '2025-12-31', '', 5),
(667, 'Mohammad Thaqif Anaqi', 1, 11, '2025-12-31', '', 5),
(668, 'Muhamad Hadif Elman Bin Mohd Khairi Amri', 1, 11, '2025-12-31', '', 10),
(669, 'Muhammad Al Fateh Bin Akmal', 1, 11, '2025-12-31', '', 5),
(670, 'Muhammad Arif Iman Bin Amin', 1, 11, '2025-12-31', '', 5),
(671, 'Muhammad Hafiy Al Jufri Bin Sani', 1, 11, '2025-12-31', '', 5),
(672, 'Muhammad Hassan Al-Jufri Bin Sani', 1, 11, '2025-12-31', '', 5),
(673, 'Muhammad Iffat Lutfi Bin Nur Hilhamsyahmi', 1, 11, '2025-12-31', '', 5),
(674, 'Muhammad Khairul Naim Bin Khairul Nizam', 1, 11, '2025-12-31', '', 10),
(675, 'Muhammad Naufal Bin Mohammed Khairul Hidzwan', 1, 11, '2025-12-31', '', 5),
(676, 'Muhammad Qaid Mikael Bin Mohd Farid', 1, 11, '2025-12-31', '', 5),
(677, 'Muhammad Sayyid Rizqi Bin Mohd Rizuan', 1, 11, '2025-12-31', '', 5),
(678, 'Muhammad Umar Irsyad Bin Ashraf', 1, 11, '2025-12-31', '', 10),
(679, 'Muhammad Zayyan Zuhair Bin Muhammad Izzat', 1, 11, '2025-12-31', '', 5),
(680, 'Rizqi Hayyan Bin Shahres Ammerul', 1, 11, '2025-12-31', '', 10),
(681, 'Rafique Zachary Chuah Bin Muhammad Syibli', 1, 11, '2025-12-31', '', 10),
(682, 'Keisha Fitiya Binti Mohamad Fairuz', 5, 12, '2025-12-31', '', 10),
(683, 'Mayyasah Adni Nuraa Binti Mohd Azmi', 5, 12, '2025-12-31', '', 10),
(684, 'Misha Afiya Binti Mohamad Fairuz', 5, 12, '2025-12-31', '', 5),
(685, 'Muhammad Arfa Dzeko Bin Mohd Azmi', 5, 12, '2025-12-31', '', 13),
(686, 'Khairunnas Zalikha Binti Khairul Hafizi', 4, 12, '2025-12-31', '', 5),
(687, 'Dhia Marissa Binti Mohamad', 3, 12, '2025-12-31', '', 10),
(688, 'Rania Husna Binti Ramdan', 3, 12, '2025-12-31', '', 5),
(689, 'Aaron Wafri Bin Mohd Farhan Azme', 3, 12, '2025-12-31', '', 13),
(690, 'Abdul Rahim Bin Ramdan', 3, 12, '2025-12-31', '', 10),
(691, 'Abdul Rahman Bin Ramdan', 3, 12, '2025-12-31', '', 10),
(692, 'Amzar Affan Bin Mohd Aminurashid', 3, 12, '2025-12-31', '', 5),
(693, 'Azim Azfar Bin Mohd Aminurashid', 3, 12, '2025-12-31', '', 10),
(694, 'Hamka Ziqri Bin Mohamad Amin Shaadan', 3, 12, '2025-12-31', '', 5),
(695, 'Izz Fatiyh Iskandar Bin Mohamad', 3, 12, '2025-12-31', '', 10),
(696, 'Muhammad Aniq Lutfi', 3, 12, '2025-12-31', '', 5),
(697, 'Muhammad Aydin Imran Bin Abdullah Ihsan', 3, 12, '2025-12-31', '', 5),
(698, 'Muhammad Ian Lutfi', 3, 12, '2025-12-31', '', 5),
(699, 'Muhammad Izz Zayyan Bin Mohamad Azri', 3, 12, '2025-12-31', '', 13),
(700, 'Muhammad Kasyaf Mikail Bin Muhammad Nurhakim', 3, 12, '2025-12-31', '', 5),
(701, 'Muhammad Rizqi Zafran Bin Abdul Fattah', 3, 12, '2025-12-31', '', 5),
(702, 'Wan Hadif Yusuf Bin Wan Muhamad Nur Zikri', 3, 12, '2025-12-31', '', 5),
(703, 'Zahin Ziqri Bin Mohamad Amin Shaadan', 3, 12, '2025-12-31', '', 5),
(704, 'Akmal Syarif Bin Mohd Khairul', 4, 13, '2025-12-31', '', 13),
(705, 'Muhd Ikhmal Bin Abdullah', 4, 13, '2025-12-31', '', 13),
(706, 'Huda Ramadhani Binti Mohd Hanis', 3, 13, '2025-12-31', '', 10),
(707, 'Husna Rasyada Binti Mohd Hanis', 3, 13, '2025-12-31', '', 5),
(708, 'Ahmad Al Fateh Bin Mohd Syahmi', 3, 13, '2025-12-31', '', 5),
(709, 'Muhammad Adif Bin Abdullah', 3, 13, '2025-12-31', '', 10),
(710, 'Muhammad Rayyan Iskandar', 3, 13, '2025-12-31', '', 10),
(711, 'Muhd Haikal Bin Zulkifli', 3, 13, '2025-12-31', '', 10),
(712, 'Muhd Ikram Bin Abdullah', 3, 13, '2025-12-31', '', 10),
(713, 'Muhd Shafiz Rayyan Bin Abdullah', 3, 13, '2025-12-31', '', 10),
(714, 'Putra Mirza Bin Abd Hakim', 3, 13, '2025-12-31', '', 10),
(715, 'Shafwan Adam Bin Abdullah', 3, 13, '2025-12-31', '', 10),
(716, 'Hariz Haikal Bin Hishamuddin', 9, 14, '2025-12-31', '', 13),
(717, 'Izzad Hazziq Bin Masalan', 9, 14, '2025-12-31', '', 13),
(718, 'Muhammad Alauddin Darwisy', 9, 14, '2025-12-31', '', 13),
(719, 'Muhammad Azim Darwisy Bin Mohd Safur', 9, 14, '2025-12-31', '', 13),
(720, 'Muhammad Amsyar Bin Mohd Izwan', 9, 14, '2025-12-31', '', 13),
(721, 'Muhammad Hafiy Bin Mohd Shairee', 9, 14, '2025-12-31', '', 13),
(722, 'Muhammad Hazim Muzammil Bin Nazrul', 9, 14, '2025-12-31', '', 13),
(723, 'Muhammad Syah Putra Bin Khairuddin', 9, 14, '2025-12-31', '', 13),
(724, 'Muhammad Hael Mikhael Bin Mohd Hafizi', 4, 14, '2025-12-31', '', 5),
(725, 'Muhammad Syawal Mikhail Bin Mohd Hafizi', 4, 14, '2025-12-31', '', 5),
(726, 'Nur Raihan Binti Mohd Shahrin', 4, 14, '2025-12-31', '', 13),
(727, 'Che Nur Dhia Kamalia Binti Che Hanafiah', 4, 14, '2025-12-31', '', 10),
(728, 'Che Nur Zara Kamalia Binti Che Hanafiah', 4, 14, '2025-12-31', '', 5),
(729, 'Muhammad Iqbal Qhushairey Bin Hamzah', 4, 14, '2025-12-31', '', 10),
(730, 'Humaira Ardani Binti Hafizan', 3, 14, '2025-12-31', '', 5),
(731, 'Nur Fahziani Lutfi Binti Halim', 3, 14, '2025-12-31', '', 10),
(732, 'Nur Raihan Binti Mohd Shahrin', 3, 14, '2025-12-31', '', 13),
(733, 'Nur Tamamah Binti Mohd Shahrin', 3, 14, '2025-12-31', '', 5),
(734, 'Ahmad Ammar Bin Amri', 3, 14, '2025-12-31', '', 10),
(735, 'Ahmad Ammar Bin Hishamuddin', 3, 14, '2025-12-31', '', 10),
(736, 'Muhamad Izz Haidar Anaqi Bin Muhamad Norhafiz', 3, 14, '2025-12-31', '', 10),
(737, 'Mohamad Harraz Irfan Bin Mohd Raamirrul', 3, 14, '2025-12-31', '', 5),
(738, 'Muhammad Faiq Sufi Bin Muhammad Faiz', 3, 14, '2025-12-31', '', 5),
(739, 'Muhammad Faliq Sufi Bin Muhammad Faiz', 3, 14, '2025-12-31', '', 5),
(740, 'Muhammad Hafiy Bin Halim', 3, 14, '2025-12-31', '', 5),
(741, 'Muhammad Harraz Bin Hafizan', 3, 14, '2025-12-31', '', 5),
(742, 'Aafiyah Husna Mazlan Binti Abdul Majid', 1, 14, '2025-12-31', '', 5),
(743, 'Aisyah Sofia Binti Muhammad Azhar', 1, 14, '2025-12-31', '', 5),
(744, 'Intan Nur Lisa Farhana Binti Mohd Faizal', 1, 14, '2025-12-31', '', 5),
(745, 'Khaira Aleesa Binti Ahmad Haidhar', 1, 14, '2025-12-31', '', 5),
(746, 'Nur Aishah Humaira Binti Muhammad Shah Awaludin', 1, 14, '2025-12-31', '', 5),
(747, 'Nur Safa Binti Idzuan Asraf', 1, 14, '2025-12-31', '', 5),
(748, 'Nur Safiyyah Binti Idzuan Asraf', 1, 14, '2025-12-31', '', 10),
(749, 'Nurul Hannah Alisha', 1, 14, '2025-12-31', '', 5),
(750, 'Qabila Hulya Binti Muhamad Hariz', 1, 14, '2025-12-31', '', 5),
(751, 'Saidatul Aisyah Binti Khairul An Nur', 1, 14, '2025-12-31', '', 5),
(752, 'Ahmad Ammar Rafeeq Bin Mohd Alias', 1, 14, '2025-12-31', '', 5),
(753, 'Brian Anaqi Bin Baharim', 1, 14, '2025-12-31', '', 5),
(754, 'Hariz Arfa Bin Zainul Akmal', 1, 14, '2025-12-31', '', 5),
(755, 'Megat Falliq Hamka Bin Megat Mohd Haafiz', 1, 14, '2025-12-31', '', 5),
(756, 'Megat Fayyadh Hadif Bin Megat Mohd Haafiz', 1, 14, '2025-12-31', '', 5),
(757, 'Mohamad Harraz Irfan Bin Mohamad Raamirrul', 1, 14, '2025-12-31', '', 5),
(758, 'Mohamad Rayyan Bin Mohd Raziz', 1, 14, '2025-12-31', '', 10),
(759, 'Mohamed Aidan Hannan Bin Abdul Hafiz', 1, 14, '2025-12-31', '', 10),
(760, 'Mohamed Solah Bin Idzuan Asraf', 1, 14, '2025-12-31', '', 5),
(761, 'Muhamad Adam Aress Bin Mohd Amie', 1, 14, '2025-12-31', '', 5),
(762, 'Muhammad Afiq Syakirin Bin Mohd Afizal', 1, 14, '2025-12-31', '', 5),
(763, 'Muhammad Alauddin Darwisy', 1, 14, '2025-12-31', '', 5),
(764, 'Muhammad Amsyar', 1, 14, '2025-12-31', '', 5),
(765, 'Muhammad Arif Bin Mohamed Azurul', 1, 14, '2025-12-31', '', 5),
(766, 'Muhammad Arryan Darwish Bin Abdul Barr', 1, 14, '2025-12-31', '', 5),
(767, 'Muhammad Azim Darwisy Bin Mohd Safur', 1, 14, '2025-12-31', '', 13),
(768, 'Muhammad Danial Raqif Bin Mohd Rozan', 1, 14, '2025-12-31', '', 13),
(769, 'Muhammad Hamka B Muhammad Amir Firdaus', 1, 14, '2025-12-31', '', 5),
(770, 'Muhammad Harraz Bin Mohd Aznee', 1, 14, '2025-12-31', '', 5),
(771, 'Muhammad Izz Nafiyy Bin Muhammad Ashrull Haikall', 1, 14, '2025-12-31', '', 5),
(772, 'Muhammad Muhaimin Bin Mohd Azhar', 1, 14, '2025-12-31', '', 5),
(773, 'Muhammad Nur Hakim Bin Mohd Khairuzin', 1, 14, '2025-12-31', '', 5),
(774, 'Muhammad Rayhan Muqri Bin Mohd Shahzreen', 1, 14, '2025-12-31', '', 5),
(775, 'Muhammad Riyaaz Mikhail Bin Mohd Shahzreen', 1, 14, '2025-12-31', '', 10),
(776, 'Nik Muhammad Yusuf Bin Nik Mohd Azizi', 1, 14, '2025-12-31', '', 5),
(777, 'Muhammad Harith Naufal Bin Samsul Aripin', 1, 14, '2025-12-31', '', 5),
(778, 'Rayyan Iskandar Abdur Rahman', 1, 14, '2025-12-31', '', 5);

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE `tests` (
  `test_id` int(11) NOT NULL,
  `level_id` int(11) NOT NULL,
  `test_name` varchar(100) NOT NULL,
  `total_mark` int(11) DEFAULT 0,
  `judge_name` varchar(100) DEFAULT NULL,
  `status` enum('inactive','active') DEFAULT 'inactive'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`test_id`, `level_id`, `test_name`, `total_mark`, `judge_name`, `status`) VALUES
(1, 1, 'Jurus dan Bunga Tanjung', 0, 'yana', 'inactive'),
(2, 1, 'Asas Elakan', 0, 'farhan', 'inactive'),
(11, 3, 'Elakan Tangkapan Pukulan', 0, NULL, 'inactive'),
(12, 3, 'Tunggal Baku', 0, NULL, 'inactive'),
(13, 4, 'Elakan Tangkapan Pukulan', 0, NULL, 'inactive'),
(14, 4, 'Tunggal Baku', 0, NULL, 'inactive'),
(15, 5, 'Jurus Bergerak', 0, NULL, 'inactive'),
(16, 5, 'Elakan Tangkapan Pukulan', 0, NULL, 'inactive'),
(17, 6, 'Jurus Bergerak', 0, NULL, 'inactive'),
(18, 6, 'Serangan Anak Harimau', 0, NULL, 'inactive'),
(21, 5, 'Tunggal Baku - Jurus Jolok', 0, NULL, 'inactive'),
(22, 6, 'Tunggal Baku - Jurus Tongkat', 0, NULL, 'inactive'),
(24, 2, 'Jurus dan Bunga Tanjung', 0, 'assus', 'inactive'),
(25, 2, 'Tunggal Baku', 0, 'yana', 'inactive'),
(37, 7, 'Jurus Bergerak', 0, NULL, 'inactive'),
(38, 7, 'Serangan Anak Harimau', 0, NULL, 'inactive'),
(39, 7, 'Jurus Wajib', 0, NULL, 'inactive'),
(40, 13, 'Bunga Tanjung', 0, NULL, 'inactive'),
(41, 13, 'Jurus', 0, NULL, 'inactive'),
(42, 13, 'Elakan Tangkapan dan Pukulan', 0, NULL, 'inactive'),
(43, 13, 'Jurus Tunggal Baku-Tangan Kosong', 0, NULL, 'inactive'),
(44, 14, 'Jurus Bergerak', 0, NULL, 'inactive'),
(45, 14, 'Elakan Tangkapan dan Pukulan', 0, NULL, 'inactive'),
(46, 14, 'Jurus Tunggal Baku', 0, NULL, 'inactive'),
(47, 15, 'Gerakan Anak Harimau Pecahan 10', 0, NULL, 'inactive'),
(48, 15, 'Serangan Anak Harimau', 0, NULL, 'inactive'),
(49, 15, 'Jurus Tunggal Baku - Golok', 0, NULL, 'inactive'),
(50, 16, 'Serangan Anak Harimau', 0, NULL, 'inactive'),
(51, 16, 'Jurus Tunggal Baku - Tongkat', 0, NULL, 'inactive');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('recorder','pic','judge') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`) VALUES
(1, 'recorder', '827ccb0eea8a706c4c34a16891f84e7b', 'recorder'),
(2, 'pic_admin', '827ccb0eea8a706c4c34a16891f84e7b', 'pic'),
(3, 'judge_1', '827ccb0eea8a706c4c34a16891f84e7b', 'judge');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`attendance_id`),
  ADD UNIQUE KEY `unique_attendance` (`student_id`,`session_id`),
  ADD KEY `session_id` (`session_id`);

--
-- Indexes for table `criteria`
--
ALTER TABLE `criteria`
  ADD PRIMARY KEY (`criteria_id`),
  ADD KEY `test_id` (`test_id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`group_id`),
  ADD KEY `session_id` (`session_id`);

--
-- Indexes for table `group_students`
--
ALTER TABLE `group_students`
  ADD PRIMARY KEY (`group_id`,`student_id`),
  ADD KEY `student_id` (`student_id`);

--
-- Indexes for table `levels`
--
ALTER TABLE `levels`
  ADD PRIMARY KEY (`level_id`),
  ADD KEY `session_id` (`session_id`);

--
-- Indexes for table `schools`
--
ALTER TABLE `schools`
  ADD PRIMARY KEY (`school_id`);

--
-- Indexes for table `scores`
--
ALTER TABLE `scores`
  ADD PRIMARY KEY (`score_id`),
  ADD KEY `student_id` (`student_id`),
  ADD KEY `criteria_id` (`criteria_id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`session_id`);

--
-- Indexes for table `session_schools`
--
ALTER TABLE `session_schools`
  ADD PRIMARY KEY (`id`),
  ADD KEY `session_id` (`session_id`),
  ADD KEY `school_id` (`school_id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`student_id`),
  ADD KEY `school_id` (`school_id`),
  ADD KEY `fk_level` (`level_id`);

--
-- Indexes for table `tests`
--
ALTER TABLE `tests`
  ADD PRIMARY KEY (`test_id`),
  ADD KEY `level_id` (`level_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `attendance_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=325;

--
-- AUTO_INCREMENT for table `criteria`
--
ALTER TABLE `criteria`
  MODIFY `criteria_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `group_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `levels`
--
ALTER TABLE `levels`
  MODIFY `level_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `schools`
--
ALTER TABLE `schools`
  MODIFY `school_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `scores`
--
ALTER TABLE `scores`
  MODIFY `score_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=231;

--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `session_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `session_schools`
--
ALTER TABLE `session_schools`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `student_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tests`
--
ALTER TABLE `tests`
  MODIFY `test_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `attendance_ibfk_2` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`session_id`) ON DELETE CASCADE;

--
-- Constraints for table `criteria`
--
ALTER TABLE `criteria`
  ADD CONSTRAINT `criteria_ibfk_1` FOREIGN KEY (`test_id`) REFERENCES `tests` (`test_id`);

--
-- Constraints for table `groups`
--
ALTER TABLE `groups`
  ADD CONSTRAINT `groups_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`session_id`);

--
-- Constraints for table `group_students`
--
ALTER TABLE `group_students`
  ADD CONSTRAINT `group_students_ibfk_1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`group_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `group_students_ibfk_2` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE;

--
-- Constraints for table `levels`
--
ALTER TABLE `levels`
  ADD CONSTRAINT `levels_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`session_id`);

--
-- Constraints for table `scores`
--
ALTER TABLE `scores`
  ADD CONSTRAINT `scores_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  ADD CONSTRAINT `scores_ibfk_2` FOREIGN KEY (`criteria_id`) REFERENCES `criteria` (`criteria_id`);

--
-- Constraints for table `session_schools`
--
ALTER TABLE `session_schools`
  ADD CONSTRAINT `session_schools_ibfk_1` FOREIGN KEY (`session_id`) REFERENCES `sessions` (`session_id`),
  ADD CONSTRAINT `session_schools_ibfk_2` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`);

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `fk_level` FOREIGN KEY (`level_id`) REFERENCES `levels` (`level_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`school_id`) REFERENCES `schools` (`school_id`);

--
-- Constraints for table `tests`
--
ALTER TABLE `tests`
  ADD CONSTRAINT `tests_ibfk_1` FOREIGN KEY (`level_id`) REFERENCES `levels` (`level_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
