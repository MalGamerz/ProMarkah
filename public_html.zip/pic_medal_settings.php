<?php

// ── Production error handling ──────────────────────────────────────────────

ini_set('display_errors', 0);

ini_set('display_startup_errors', 0);

error_reporting(E_ALL);

ini_set('log_errors', 1);



session_start();

include 'db.php';

$conn = getDB();



if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {

    header("Location: login.php");

    exit();

}

$pm_page = 'medal_settings';

include 'layout.php';



// ── Determine active scope ─────────────────────────────────────────────────

// Scope: 'overall' | 'sidang' | 'peringkat' | 'sekolah'

$scope = $_GET['scope'] ?? 'peringkat';

$filter_session = $_GET['session_id'] ?? '';

$filter_level   = $_GET['level_id']   ?? '';



$validScopes = ['overall', 'sidang', 'peringkat', 'sekolah'];

if (!in_array($scope, $validScopes)) $scope = 'peringkat';



// ── Handle POST save ───────────────────────────────────────────────────────

$saveMsg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['quotas'])) {



    // overall  → medal_quotas_overall (gold_quota, silver_quota, bronze_quota) — single row

    // sidang   → medal_quotas_session (session_id, gold_quota, …)

    // peringkat→ medal_quotas          (level_id,   gold_quota, …)

    // sekolah  → medal_quotas_school  (school_id,  session_id?, gold_quota, …)



    $postedScope = $_POST['scope'] ?? 'peringkat';



    if ($postedScope === 'overall') {

        // Single global row

        $q = $_POST['quotas'][0] ?? ['gold' => 0, 'silver' => 0, 'bronze' => 0];

        $g = (int)$q['gold'];

        $s = (int)$q['silver'];

        $b = (int)$q['bronze'];

        // Use a config table; fall back to medal_quotas with level_id = 0 as sentinel

        $conn->query("DELETE FROM medal_quotas WHERE level_id = 0");

        if ($g || $s || $b) {

            $stmt = $conn->prepare("INSERT INTO medal_quotas (level_id, gold_quota, silver_quota, bronze_quota) VALUES (0, ?, ?, ?)");

            $stmt->bind_param('iii', $g, $s, $b);

            $stmt->execute();

            $stmt->close();

        }



    } elseif ($postedScope === 'sidang') {

        $stmtDel = $conn->prepare("DELETE FROM medal_quotas_session WHERE session_id = ?");

        $stmtIns = $conn->prepare("INSERT INTO medal_quotas_session (session_id, gold_quota, silver_quota, bronze_quota)

                                   VALUES (?, ?, ?, ?)

                                   ON DUPLICATE KEY UPDATE gold_quota=VALUES(gold_quota), silver_quota=VALUES(silver_quota), bronze_quota=VALUES(bronze_quota)");

        foreach ($_POST['quotas'] as $sid => $q) {

            $sid = (int)$sid;

            $g   = (int)$q['gold'];

            $s   = (int)$q['silver'];

            $b   = (int)$q['bronze'];

            if ($g === 0 && $s === 0 && $b === 0) {

                $stmtDel->bind_param('i', $sid);

                $stmtDel->execute();

            } else {

                $stmtIns->bind_param('iiii', $sid, $g, $s, $b);

                $stmtIns->execute();

            }

        }

        if ($stmtDel) $stmtDel->close();

        if ($stmtIns) $stmtIns->close();



    } elseif ($postedScope === 'peringkat') {

        $stmtDel = $conn->prepare("DELETE FROM medal_quotas WHERE level_id = ?");

        $stmtIns = $conn->prepare("INSERT INTO medal_quotas (level_id, gold_quota, silver_quota, bronze_quota)

                                   VALUES (?, ?, ?, ?)

                                   ON DUPLICATE KEY UPDATE gold_quota=VALUES(gold_quota), silver_quota=VALUES(silver_quota), bronze_quota=VALUES(bronze_quota)");

        foreach ($_POST['quotas'] as $lid => $q) {

            $lid = (int)$lid;

            if ($lid === 0) continue; // skip global sentinel

            $g   = (int)$q['gold'];

            $s   = (int)$q['silver'];

            $b   = (int)$q['bronze'];

            if ($g === 0 && $s === 0 && $b === 0) {

                $stmtDel->bind_param('i', $lid);

                $stmtDel->execute();

            } else {

                $stmtIns->bind_param('iiii', $lid, $g, $s, $b);

                $stmtIns->execute();

            }

        }

        if ($stmtDel) $stmtDel->close();

        if ($stmtIns) $stmtIns->close();



    } elseif ($postedScope === 'sekolah') {

        $stmtDel = $conn->prepare("DELETE FROM medal_quotas_school WHERE school_id = ?");

        $stmtIns = $conn->prepare("INSERT INTO medal_quotas_school (school_id, gold_quota, silver_quota, bronze_quota)

                                   VALUES (?, ?, ?, ?)

                                   ON DUPLICATE KEY UPDATE gold_quota=VALUES(gold_quota), silver_quota=VALUES(silver_quota), bronze_quota=VALUES(bronze_quota)");

        foreach ($_POST['quotas'] as $scid => $q) {

            $scid = (int)$scid;

            $g    = (int)$q['gold'];

            $s    = (int)$q['silver'];

            $b    = (int)$q['bronze'];

            if ($g === 0 && $s === 0 && $b === 0) {

                $stmtDel->bind_param('i', $scid);

                $stmtDel->execute();

            } else {

                $stmtIns->bind_param('iiii', $scid, $g, $s, $b);

                $stmtIns->execute();

            }

        }

        if ($stmtDel) $stmtDel->close();

        if ($stmtIns) $stmtIns->close();

    }



    $saveMsg = "<div class='pic-alert-success' style='background: var(--c-surface-2); border: 1px solid var(--c-border-strong); border-left: 4px solid #4ADE80; color: #4ADE80; padding: 12px 16px; border-radius: 6px; margin-bottom: 16px; font-weight: 600; font-size: 0.9rem;'>✅ Tetapan pingat berjaya dikemaskini.</div>";

}

?>



<style>

    /* ── Scope tab strip (Full Width) ── */
    .scope-strip {
        display: flex;
        gap: 0;
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        border-radius: 8px;
        padding: 4px;
        width: 100%; /* Spans full width */
        box-sizing: border-box;
        flex-wrap: wrap;
    }
    
    .scope-tab {
        flex: 1; /* Makes tabs stretch equally */
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 7px;
        padding: 10px 18px;
        border-radius: 6px;
        border: none;
        background: transparent;
        color: var(--c-text-muted);
        font-family: 'DM Mono', monospace;
        font-size: 0.85rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        cursor: pointer;
        text-decoration: none;
        transition: all 0.18s ease;
        white-space: nowrap;
    }

    .scope-tab:hover {
        color: var(--c-white);
        background: var(--c-surface-3);
    }

    .scope-tab.active {
        background: var(--c-red);
        color: #fff;
        box-shadow: 0 2px 10px rgba(214, 40, 40, 0.45);
    }

    .scope-tab .scope-icon {
        font-size: 1.1rem;
    }



    /* ── Scope description badge ── */

    .scope-desc {

        background: var(--c-surface-1);

        border: 1px solid var(--c-border);

        border-left: 3px solid var(--c-red);

        border-radius: 6px;

        padding: 10px 14px;

        color: var(--c-text-muted);

        font-size: 0.82rem;

        line-height: 1.5;

        margin-bottom: 16px;

    }



    /* ── Number inputs ── */

    .sleek-num-input {

        width: 60px;

        height: 38px;

        background: var(--c-surface-0);

        border: 1px solid var(--c-border-strong);

        border-radius: 6px;

        color: var(--c-white);

        font-family: 'DM Mono', monospace;

        font-size: 1.1rem;

        font-weight: 700;

        text-align: center;

        transition: all 0.2s ease;

        outline: none;

    }



    .sleek-num-input:focus {

        border-color: var(--c-red);

        box-shadow: 0 0 12px rgba(214, 40, 40, 0.4);

        background: var(--c-surface-1);

    }



    .sleek-num-input::-webkit-outer-spin-button,

    .sleek-num-input::-webkit-inner-spin-button {

        -webkit-appearance: none;

        margin: 0;

    }



    /* ── Overall scope single card ── */

    .overall-card {

        display: flex;

        align-items: center;

        justify-content: space-between;

        flex-wrap: wrap;

        gap: 24px;

        background: var(--c-surface-2);

        border: 1px solid var(--c-border-strong);

        border-radius: 10px;

        padding: 28px 32px;

        margin-bottom: 24px;

    }



    .overall-card .label-block {

        display: flex;

        flex-direction: column;

        gap: 4px;

    }



    .overall-card .label-block strong {

        font-family: 'Bebas Neue', sans-serif;

        font-size: 1.4rem;

        letter-spacing: 0.06em;

        color: var(--c-white);

    }



    .overall-card .label-block span {

        font-size: 0.8rem;

        color: var(--c-text-faint);

    }



    .overall-medal-row {

        display: flex;

        gap: 20px;

        align-items: center;

        flex-wrap: wrap;

    }



    .overall-medal-row .medal-cell {

        display: flex;

        flex-direction: column;

        align-items: center;

        gap: 6px;

    }



    .overall-medal-row .medal-cell label {

        font-size: 0.75rem;

        font-family: 'DM Mono', monospace;

        letter-spacing: 0.05em;

        color: var(--c-text-muted);

        font-weight: 600;

    }



    /* ── Table ── */

    .medal-table th {

        background: var(--c-surface-2) !important;

        color: var(--c-white) !important;

        font-family: 'Bebas Neue', sans-serif;

        font-size: 1.15rem !important;

        letter-spacing: 0.05em;

        position: sticky;

        top: 0;

        z-index: 10;

        border: none !important;

        box-shadow: 0 2px 0 var(--c-red);

    }



    .medal-table td {

        vertical-align: middle !important;

    }



    /* ── Pagination Styles (Flush with table) ── */
    .pagination-container {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        padding: 10px 16px; /* Slightly tighter padding */
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border-strong); /* Matches the table border */
        gap: 16px;
        margin-top: auto; /* Pushes pagination flush against the bottom of the table */
        width: 100%;
        box-sizing: border-box;
    }

    .pagination-left {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }

    .pagination-info {
        font-size: 0.85rem;
        color: var(--c-text-muted);
        font-weight: 600;
    }

    .pagination-controls {
        display: flex;
        gap: 6px;
    }

    .page-btn {
        padding: 4px 12px;
        font-size: 0.85rem;
        border: 1px solid var(--c-border-strong);
        background: var(--c-surface-1);
        color: var(--c-text-muted);
        border-radius: 4px;
        cursor: pointer;
        font-weight: 600;
        transition: 0.2s ease;
    }

    .page-btn:hover:not(:disabled) {
        background: var(--c-surface-3);
        color: var(--c-white);
    }

    .page-btn.active {
        background: var(--c-red);
        color: #fff;
        border-color: var(--c-red);
    }

    .page-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
    }

    @media (max-width: 640px) {
        .scope-tab { padding: 8px 5px; font-size: 0.75rem; flex-direction: column; gap: 2px; }
        .pagination-container { flex-direction: column; justify-content: center; text-align: center; }
        .pagination-left { justify-content: center; }
        .pagination-controls { width: 100%; justify-content: center; flex-wrap: wrap; }
    }

    /* ── Scroll Wrapper (Hugs Content & Fits Screen) ── */
    .table-scroll-wrapper {
        max-height: calc(100vh - 400px); /* Maximizes available vertical space */
        min-height: auto; /* REMOVED fixed minimum height to fix the huge gap */
        overflow-y: auto;
        position: relative;
        scrollbar-width: thin;
        scrollbar-color: var(--c-surface-3) transparent;
        border: none;
    }
    
    /* ── Unified Card Container ── */
    /* Add this to ensure the table and pagination wrap together perfectly */
    .pm-card {
        display: flex;
        flex-direction: column;
        padding: 0 !important; 
        border: 1px solid var(--c-border-strong) !important;
        border-radius: 10px;
        overflow: hidden; /* Clips the table header and pagination corners */
        margin-bottom: 0;
    }

    @media (max-width: 640px) {

        .scope-strip { width: 100%; }

        .scope-tab { flex: 1; justify-content: center; padding: 8px 10px; font-size: 0.75rem; }

        .overall-card { flex-direction: column; }

        .overall-medal-row { width: 100%; justify-content: space-around; }

        .pagination-controls { flex-direction: column; align-items: stretch; }

    }
    
    /* ── Filter Card (Matches pic_tests.php layout) ── */
    .filter-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border-strong);
        border-radius: 12px;
        padding: 20px;
        margin-bottom: 24px;
        box-shadow: 0 4px 12px rgba(0,0,0,.08);
    }

    .filter-card-title {
        font-size: .72rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .12em;
        color: var(--c-text-faint);
        margin-bottom: 16px;
    }

    .pic-filter-bar {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 16px;
        align-items: end;
    }

    .pic-filter-bar > div {
        min-width: 0;
    }

    .pic-filter-bar label {
        display: block;
        margin-bottom: 6px;
        font-size: .75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: .08em;
        color: var(--c-text-faint);
    }

    .pic-filter-bar select {
        width: 100%;
        background-color: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-white);
        padding: 10px 14px;
        border-radius: 8px;
        font-family: inherit;
        font-size: 0.95rem;
        outline: none;
        transition: all 0.2s ease;
        appearance: none;
        background-image: url("data:image/svg+xml;charset=UTF-8,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23888' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3e%3cpolyline points='6 9 12 15 18 9'%3e%3c/polyline%3e%3c/svg%3e");
        background-repeat: no-repeat;
        background-position: right 14px center;
        background-size: 16px;
        cursor: pointer;
    }

    .pic-filter-bar select:hover {
        border-color: var(--c-text-faint);
    }

    .pic-filter-bar select:focus {
        border-color: var(--c-red);
        background-color: var(--c-surface-1);
        box-shadow: 0 0 0 3px rgba(214, 40, 40, 0.15);
    }

    /* Light mode sync for filter card */
    html.pm-light .filter-card { background: #fff; border-color: #e5e7eb; border-top-color: var(--c-red); box-shadow: 0 1px 4px rgba(0,0,0,0.06); }
    html.pm-light .filter-card-title { color: #888; }
    html.pm-light .pic-filter-bar label { color: #555; }
    html.pm-light .pic-filter-bar select { background-color: #f9fafb; border-color: #d1d5db; color: #111; }

    /* Mobile overrides */
    @media (max-width: 640px) {
        .filter-form {
            grid-template-columns: 1fr; /* Stack vertically on mobile */
            gap: 10px;
        }
        
        .filter-form.single-filter {
            max-width: 100% !important; /* Full width on mobile */
        }
    }
</style>



<!-- ── Page header ── -->

<div style='display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:18px;flex-wrap:wrap;gap:12px;'>

    <div>

        <h2 style='color: var(--c-white); font-family: "Bebas Neue", sans-serif; font-size: 1.8rem; letter-spacing: 0.05em;'>

            🏆 Tetapan Kuota Pingat

        </h2>

        <div style='color:var(--c-text-faint);font-size:0.85rem;'>

            Tetapkan jumlah maksimum pingat mengikut skop yang dipilih. Nilai 0 bermaksud penentuan automatik.

        </div>

    </div>

</div>



<?= $saveMsg ?>



<!-- ── Scope selector strip ── -->

<div style='margin-bottom:16px;'>

    <div class='scope-strip'>

        <?php

        $scopes = [

            'overall'   => ['icon' => '🌐', 'label' => 'Keseluruhan'],

            'sidang'    => ['icon' => '📅', 'label' => 'Mengikut Sidang'],

            'peringkat' => ['icon' => '🏆', 'label' => 'Mengikut Peringkat'],

            'sekolah'   => ['icon' => '🏫', 'label' => 'Mengikut Sekolah'],

        ];

        foreach ($scopes as $key => $info) {

            $active = ($scope === $key) ? 'active' : '';

            $url    = "?scope={$key}";

            echo "<a href='{$url}' class='scope-tab {$active}'>

                    <span class='scope-icon'>{$info['icon']}</span>

                    {$info['label']}

                  </a>";

        }

        ?>

    </div>

</div>



<!-- ── Scope description ── -->

<?php

$scopeDesc = [

    'overall'   => '🌐 <strong>Keseluruhan</strong> — Satu kuota global yang digunakan sebagai lalai untuk semua sidang, peringkat, dan sekolah jika tiada tetapan khusus ditemui.',

    'sidang'    => '📅 <strong>Mengikut Sidang</strong> — Tetapkan kuota berasingan bagi setiap sidang. Mengatasi tetapan Keseluruhan jika ditetapkan.',

    'peringkat' => '🏆 <strong>Mengikut Peringkat</strong> — Tetapkan kuota berasingan bagi setiap peringkat dalam sidang. Mengatasi tetapan Sidang dan Keseluruhan.',

    'sekolah'   => '🏫 <strong>Mengikut Sekolah</strong> — Tetapkan kuota berasingan bagi setiap sekolah peserta. Mengatasi semua tetapan lain.',

];

echo "<div class='scope-desc'>{$scopeDesc[$scope]}</div>";

?>



<form method='POST'>

    <input type='hidden' name='scope' value='<?= htmlspecialchars($scope) ?>'>



    <?php if ($scope === 'overall'): ?>

    <!-- ╔══════════════════════════════════════╗ -->

    <!-- ║         OVERALL — single card         ║ -->

    <!-- ╚══════════════════════════════════════╝ -->

    <?php

        $globalRow = $conn->query("SELECT * FROM medal_quotas WHERE level_id = 0")->fetch_assoc();

        $gG = $globalRow['gold_quota']   ?? 0;

        $gS = $globalRow['silver_quota'] ?? 0;

        $gB = $globalRow['bronze_quota'] ?? 0;

    ?>

    <div class='overall-card'>

        <div class='label-block'>

            <strong>🌐 Kuota Global</strong>

            <span>Digunakan sebagai nilai lalai jika tiada tetapan khusus.</span>

        </div>

        <div class='overall-medal-row'>

            <div class='medal-cell'>

                <label>EMAS 🥇</label>

                <input type='number' min='0' name='quotas[0][gold]'   value='<?= $gG ?>' class='sleek-num-input'>

            </div>

            <div class='medal-cell'>

                <label>PERAK 🥈</label>

                <input type='number' min='0' name='quotas[0][silver]' value='<?= $gS ?>' class='sleek-num-input'>

            </div>

            <div class='medal-cell'>

                <label>GANGSA 🥉</label>

                <input type='number' min='0' name='quotas[0][bronze]' value='<?= $gB ?>' class='sleek-num-input'>

            </div>

        </div>

    </div>



    <?php elseif ($scope === 'sidang'): ?>

    <!-- ╔══════════════════════════════════════╗ -->

    <!-- ║         SIDANG — per-session           ║ -->

    <!-- ╚══════════════════════════════════════╝ -->

    <div class='pm-card' style='padding:0; border-color: var(--c-border-strong);'>

        <div class='pm-table-wrap table-scroll-wrapper' style='border:none;'>

            <table class='pm-table medal-table' id='medalTable'>

                <thead>

                    <tr>

                        <th style='width:60px; text-align:center;'>No</th>

                        <th>Sidang</th>

                        <th style='width:130px; text-align:center;'>Emas 🥇</th>

                        <th style='width:130px; text-align:center;'>Perak 🥈</th>

                        <th style='width:130px; text-align:center;'>Gangsa 🥉</th>

                    </tr>

                </thead>

                <tbody id='medalTableBody'>

                    <?php

                    // Ensure table exists (graceful fallback)

                    $conn->query("CREATE TABLE IF NOT EXISTS medal_quotas_session (

                        session_id INT PRIMARY KEY,

                        gold_quota INT DEFAULT 0,

                        silver_quota INT DEFAULT 0,

                        bronze_quota INT DEFAULT 0

                    )");



                    // Scope to "Siri Aktif".
                    $active_siri = (int)($_SESSION['active_siri_id'] ?? 0);
                    $siriWhere = $active_siri > 0 ? "WHERE s.siri_id = $active_siri" : "";

                    $sql = "SELECT s.session_id, s.session_name,

                                   COALESCE(mqs.gold_quota,   0) AS gold,

                                   COALESCE(mqs.silver_quota, 0) AS silver,

                                   COALESCE(mqs.bronze_quota, 0) AS bronze

                            FROM sessions s

                            LEFT JOIN medal_quotas_session mqs ON s.session_id = mqs.session_id

                            $siriWhere

                            ORDER BY s.session_name";

                    $result = $conn->query($sql);

                    $no = 1;

                    while ($row = $result->fetch_assoc()):

                        $sid = $row['session_id'];

                    ?>

                    <tr class='medal-row'>

                        <td style='text-align:center; color: var(--c-text-faint);'><?= $no++ ?></td>

                        <td style='font-weight:600; color: var(--c-white);'><?= htmlspecialchars($row['session_name']) ?></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $sid ?>][gold]'   value='<?= $row['gold'] ?>'   class='sleek-num-input'></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $sid ?>][silver]' value='<?= $row['silver'] ?>' class='sleek-num-input'></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $sid ?>][bronze]' value='<?= $row['bronze'] ?>' class='sleek-num-input'></td>

                    </tr>

                    <?php endwhile; ?>

                </tbody>

            </table>

        </div>

    </div>



    <?php elseif ($scope === 'peringkat'): ?>

    <!-- ╔══════════════════════════════════════╗ -->

    <!-- ║    PERINGKAT — original behaviour      ║ -->

    <!-- ╚══════════════════════════════════════╝ -->



    <!-- Filters -->

   <form method='GET'>
        <input type='hidden' name='scope' value='peringkat'>
        
        <div class="filter-card">
            <div class="filter-card-title">Penapis Peringkat</div>
            
            <div class="pic-filter-bar">
                <div>
                    <label>Sidang</label>
                    <select name='session_id' onchange='this.form.submit()'>
                        <option value=''>-- Semua Sidang --</option>
                        <?php
                        // Scope to "Siri Aktif".
                        $active_siri = (int)($_SESSION['active_siri_id'] ?? 0);
                        $sessions = $active_siri > 0
                            ? $conn->query("SELECT * FROM sessions WHERE siri_id = $active_siri ORDER BY session_name")
                            : $conn->query("SELECT * FROM sessions ORDER BY session_name");
                        while ($s = $sessions->fetch_assoc()) {
                            $sel = ($filter_session == $s['session_id']) ? "selected" : "";
                            echo "<option value='{$s['session_id']}' $sel>{$s['session_name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div>
                    <label>Peringkat</label>
                    <select name='level_id' onchange='this.form.submit()'>
                        <option value=''>-- Semua Peringkat --</option>
                        <?php
                        $lvlWhere = $filter_session
                            ? " WHERE session_id=" . (int)$filter_session
                            : ($active_siri > 0 ? " WHERE session_id IN (SELECT session_id FROM sessions WHERE siri_id = $active_siri)" : "");
                        $levels    = $conn->query("SELECT * FROM levels{$lvlWhere} ORDER BY level_name");
                        while ($l = $levels->fetch_assoc()) {
                            $sel = ($filter_level == $l['level_id']) ? "selected" : "";
                            echo "<option value='{$l['level_id']}' $sel>{$l['level_name']}</option>";
                        }
                        ?>
                    </select>
                </div>
            </div>
        </div>
    </form>



    <div class='pm-card' style='padding:0; border-color: var(--c-border-strong);'>

        <div class='pm-table-wrap table-scroll-wrapper' style='border:none;'>

            <table class='pm-table medal-table' id='medalTable'>

                <thead>

                    <tr>

                        <th style='width:60px; text-align:center;'>No</th>

                        <th>Sidang</th>

                        <th>Peringkat</th>

                        <th style='width:120px; text-align:center;'>Emas 🥇</th>

                        <th style='width:120px; text-align:center;'>Perak 🥈</th>

                        <th style='width:120px; text-align:center;'>Gangsa 🥉</th>

                    </tr>

                </thead>

                <tbody id='medalTableBody'>

                    <?php

                    $whereArr = ["l.level_id != 0"]; // exclude global sentinel

                    if ($filter_session !== '') $whereArr[] = "s.session_id = " . (int)$filter_session;

                    if ($filter_level   !== '') $whereArr[] = "l.level_id = "   . (int)$filter_level;

                    if ($active_siri    > 0)    $whereArr[] = "s.siri_id = " . $active_siri;

                    $whereSql = implode(" AND ", $whereArr);



                    $sql = "SELECT l.level_id, l.level_name, s.session_name,

                                   COALESCE(mq.gold_quota,   0) AS gold,

                                   COALESCE(mq.silver_quota, 0) AS silver,

                                   COALESCE(mq.bronze_quota, 0) AS bronze

                            FROM levels l

                            JOIN sessions s ON l.session_id = s.session_id

                            LEFT JOIN medal_quotas mq ON l.level_id = mq.level_id

                            WHERE $whereSql

                            ORDER BY s.session_name, l.level_name";



                    $result = $conn->query($sql);

                    $no = 1;

                    if ($result->num_rows > 0) {

                        while ($row = $result->fetch_assoc()):

                            $lid = $row['level_id'];

                    ?>

                    <tr class='medal-row'>

                        <td style='text-align:center; color: var(--c-text-faint);'><?= $no++ ?></td>

                        <td style='color: var(--c-text-muted);'><?= htmlspecialchars($row['session_name']) ?></td>

                        <td style='font-weight:600; color: var(--c-white);'><?= htmlspecialchars($row['level_name']) ?></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $lid ?>][gold]'   value='<?= $row['gold'] ?>'   class='sleek-num-input'></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $lid ?>][silver]' value='<?= $row['silver'] ?>' class='sleek-num-input'></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $lid ?>][bronze]' value='<?= $row['bronze'] ?>' class='sleek-num-input'></td>

                    </tr>

                    <?php

                        endwhile;

                    } else {

                        echo "<tr><td colspan='6' style='text-align:center;padding:30px;color:var(--c-text-faint);'>Tiada peringkat dijumpai untuk tapisan ini.</td></tr>";

                    }

                    ?>

                </tbody>

            </table>

        </div>

    </div>



    <?php elseif ($scope === 'sekolah'): ?>

    <!-- ╔══════════════════════════════════════╗ -->

    <!-- ║         SEKOLAH — per-school           ║ -->

    <!-- ╚══════════════════════════════════════╝ -->



    <form method='GET'>
        <input type='hidden' name='scope' value='sekolah'>
        
        <div class="filter-card">
            <div class="filter-card-title">Penapis Sekolah</div>
            
            <div class="pic-filter-bar">
                <div>
                    <label>Sidang</label>
                    <select name='session_id' onchange='this.form.submit()'>
                        <option value=''>-- Semua Sidang --</option>
                        <?php
                        // Scope to "Siri Aktif".
                        $active_siri = (int)($_SESSION['active_siri_id'] ?? 0);
                        $sessions = $active_siri > 0
                            ? $conn->query("SELECT * FROM sessions WHERE siri_id = $active_siri ORDER BY session_name")
                            : $conn->query("SELECT * FROM sessions ORDER BY session_name");
                        while ($s = $sessions->fetch_assoc()) {
                            $sel = ($filter_session == $s['session_id']) ? "selected" : "";
                            echo "<option value='{$s['session_id']}' $sel>{$s['session_name']}</option>";
                        }
                        ?>
                    </select>
                </div>

                <div></div>
            </div>
        </div>
    </form>



    <div class='pm-card' style='padding:0; border-color: var(--c-border-strong);'>

        <div class='pm-table-wrap table-scroll-wrapper' style='border:none;'>

            <table class='pm-table medal-table' id='medalTable'>

                <thead>

                    <tr>

                        <th style='width:60px; text-align:center;'>No</th>

                        <th>Sekolah</th>

                        <th style='width:130px; text-align:center;'>Emas 🥇</th>

                        <th style='width:130px; text-align:center;'>Perak 🥈</th>

                        <th style='width:130px; text-align:center;'>Gangsa 🥉</th>

                    </tr>

                </thead>

                <tbody id='medalTableBody'>

                    <?php

                    // Ensure table exists

                    $conn->query("CREATE TABLE IF NOT EXISTS medal_quotas_school (

                        school_id INT PRIMARY KEY,

                        gold_quota INT DEFAULT 0,

                        silver_quota INT DEFAULT 0,

                        bronze_quota INT DEFAULT 0

                    )");



                    // Scope to "Siri Aktif" via siri_schools (schools aren't
                    // siri-specific themselves, but siri_schools records which
                    // ones participate in each siri — see pic_siri.php).
                    $schoolWhere = $active_siri > 0
                        ? "WHERE sc.school_id IN (SELECT school_id FROM siri_schools WHERE siri_id = $active_siri)"
                        : "";

                    $sql = "SELECT sc.school_id, sc.school_name,

                                   COALESCE(msc.gold_quota,   0) AS gold,

                                   COALESCE(msc.silver_quota, 0) AS silver,

                                   COALESCE(msc.bronze_quota, 0) AS bronze

                            FROM schools sc

                            LEFT JOIN medal_quotas_school msc ON sc.school_id = msc.school_id

                            $schoolWhere

                            ORDER BY sc.school_name";



                    $result = $conn->query($sql);

                    $no = 1;

                    if ($result && $result->num_rows > 0) {

                        while ($row = $result->fetch_assoc()):

                            $scid = $row['school_id'];

                    ?>

                    <tr class='medal-row'>

                        <td style='text-align:center; color: var(--c-text-faint);'><?= $no++ ?></td>

                        <td style='font-weight:600; color: var(--c-white);'><?= htmlspecialchars($row['school_name']) ?></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $scid ?>][gold]'   value='<?= $row['gold'] ?>'   class='sleek-num-input'></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $scid ?>][silver]' value='<?= $row['silver'] ?>' class='sleek-num-input'></td>

                        <td style='text-align:center;'><input type='number' min='0' name='quotas[<?= $scid ?>][bronze]' value='<?= $row['bronze'] ?>' class='sleek-num-input'></td>

                    </tr>

                    <?php

                        endwhile;

                    } else {

                        echo "<tr><td colspan='5' style='text-align:center;padding:30px;color:var(--c-text-faint);'>Tiada sekolah dijumpai. Pastikan jadual <code>schools</code> wujud dan mempunyai rekod.</td></tr>";

                    }

                    ?>

                </tbody>

            </table>

        </div>

    </div>

    <?php endif; ?>



    <?php if ($scope !== 'overall'): ?>
    <div class="pagination-container" id="paginationControls">
        <div class="pagination-left">
            <select id="rowsPerPage" class="sleek-select" style="padding: 6px 12px; height: auto; width: auto; font-size: 0.8rem; background-position: right 8px center; padding-right: 30px;" onchange="changeRowsPerPage()">
                <option value="10">10 / mukasurat</option>
                <option value="25">25 / mukasurat</option>
                <option value="50">50 / mukasurat</option>
                <option value="all">Semua</option>
            </select>
            <div class="pagination-info" id="pageInfo">Memaparkan 0 rekod</div>
        </div>
        <div class="pagination-controls" id="paginationButtons">
            </div>
    </div>
    <?php endif; ?>

    <div style='text-align:right; margin-top:16px;'>
        <button type='submit' class='pm-btn pm-btn-primary'
            style='padding: 12px 28px; font-size: 1rem; letter-spacing: 0.05em; text-transform: uppercase;'>
            💾 Simpan Tetapan Pingat
        </button>
    </div>
</form>



<script>
    const pmMedalTbody = document.getElementById('medalTableBody');
    const pmMedalRows  = pmMedalTbody ? Array.from(pmMedalTbody.getElementsByClassName('medal-row')) : [];
    let pmCurrentPage  = 1;
    let pmRowsPerPage  = 10;

    function updateMedalPagination() {
        const ctrl = document.getElementById('paginationControls');
        const btnContainer = document.getElementById('paginationButtons');
        const infoText = document.getElementById('pageInfo');
        
        if (!ctrl || !pmMedalTbody || pmMedalRows.length === 0) {
            if (ctrl) ctrl.style.display = 'none';
            return;
        }

        const totalRows = pmMedalRows.length;

        if (pmRowsPerPage === 'all') {
            pmMedalRows.forEach(r => r.style.display = '');
            infoText.innerHTML = `Memaparkan semua <b>${totalRows}</b> rekod`;
            btnContainer.innerHTML = '';
            return;
        }

        const rpp        = parseInt(pmRowsPerPage);
        const totalPages = Math.ceil(totalRows / rpp) || 1;
        
        if (pmCurrentPage > totalPages) pmCurrentPage = totalPages;
        if (pmCurrentPage < 1)          pmCurrentPage = 1;

        const start = (pmCurrentPage - 1) * rpp;
        const end   = start + rpp;

        // Hide/Show Rows
        pmMedalRows.forEach((r, i) => { 
            r.style.display = (i >= start && i < end) ? '' : 'none'; 
        });

        // Update Info Text
        const endDisplay = Math.min(end, totalRows);
        const startDisplay = totalRows === 0 ? 0 : start + 1;
        infoText.innerHTML = `Memaparkan <b>${startDisplay} - ${endDisplay}</b> daripada <b>${totalRows}</b> rekod`;

        // Render Buttons
        let html = '';
        
        // Prev Button
        html += `<button type="button" class="page-btn" ${pmCurrentPage === 1 ? 'disabled' : ''} onclick="changeMedalPage(-1)">«</button>`;
        
        // Logic to show max of 5 page numbers
        let startPage = Math.max(1, pmCurrentPage - 2);
        let endPage = Math.min(totalPages, startPage + 4);
        if (endPage - startPage < 4) {
            startPage = Math.max(1, endPage - 4);
        }

        if (startPage > 1) {
            html += `<button type="button" class="page-btn" onclick="goToMedalPage(1)">1</button>`;
            if (startPage > 2) html += `<span style="color: var(--c-text-faint); margin: 0 2px; align-self: end;">...</span>`;
        }

        for (let i = startPage; i <= endPage; i++) {
            html += `<button type="button" class="page-btn ${i === pmCurrentPage ? 'active' : ''}" onclick="goToMedalPage(${i})">${i}</button>`;
        }

        if (endPage < totalPages) {
            if (endPage < totalPages - 1) html += `<span style="color: var(--c-text-faint); margin: 0 2px; align-self: end;">...</span>`;
            html += `<button type="button" class="page-btn" onclick="goToMedalPage(${totalPages})">${totalPages}</button>`;
        }

        // Next Button
        html += `<button type="button" class="page-btn" ${pmCurrentPage === totalPages || totalPages === 0 ? 'disabled' : ''} onclick="changeMedalPage(1)">»</button>`;

        btnContainer.innerHTML = html;
    }

    function changeRowsPerPage() {
        pmRowsPerPage = document.getElementById('rowsPerPage').value;
        pmCurrentPage = 1;
        updateMedalPagination();
    }

    function changeMedalPage(dir) {
        if (pmRowsPerPage === 'all') return;
        if (dir === -1) pmCurrentPage--;
        else if (dir === 1) pmCurrentPage++;
        goToMedalPage(pmCurrentPage);
    }

    function goToMedalPage(page) {
        pmCurrentPage = page;
        updateMedalPagination();
        
        // Scroll to the top of the TABLE container only, avoiding full page scroll
        const wrapper = document.querySelector('.table-scroll-wrapper');
        if (wrapper) wrapper.scrollTo({ top: 0, behavior: 'smooth' });
    }

    // Initialize on page load
    updateMedalPagination();
</script>

</main>

</body>

</html>