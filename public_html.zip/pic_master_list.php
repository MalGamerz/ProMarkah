<?php
// ── Production error handling ──────────────────────────────────────────────
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(E_ALL);
ini_set('log_errors', 1);

session_start();
include 'db.php';
$conn = getDB();


if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {
    header("Location: login.php");
    exit();
}
session_write_close();

// ── AJAX endpoint for real-time master list updates ────────────────────────
if (isset($_GET['ajax_master_list'])) {
    $filter_session = $_GET['session_id'] ?? '';
    $filter_level = $_GET['level_id'] ?? '';
    $filter_school = $_GET['school_id'] ?? '';
    $filter_gender = $_GET['gender'] ?? '';
    $filter_year = $_GET['year'] ?? '';
    $search = $_GET['search'] ?? '';
    $sort_name = $_GET['sort_name'] ?? ''; // New sort variable

    // Scope to "Siri Aktif" — se (sessions) is already joined below.
    $active_siri = (int)($_SESSION['active_siri_id'] ?? 0);

    $whereArr = ["1=1"];
    $bindTypes = '';
    $bindVals = [];

    if ($filter_session !== '') {
        $whereArr[] = "l.session_id = ?";
        $bindTypes .= 'i';
        $bindVals[] = (int) $filter_session;
    }
    if ($filter_level !== '') {
        $whereArr[] = "st.level_id = ?";
        $bindTypes .= 'i';
        $bindVals[] = (int) $filter_level;
    }
    if ($filter_school !== '') {
        $whereArr[] = "st.school_id = ?";
        $bindTypes .= 'i';
        $bindVals[] = (int) $filter_school;
    }
    if ($filter_gender !== '') {
        $whereArr[] = "st.gender = ?";
        $bindTypes .= 's';
        $bindVals[] = $filter_gender;
    }
    if ($filter_year !== '') {
        $whereArr[] = "st.year = ?";
        $bindTypes .= 's';
        $bindVals[] = $filter_year;
    }
    if ($search !== '') {
        $whereArr[] = "st.student_name LIKE ?";
        $bindTypes .= 's';
        $bindVals[] = '%' . $search . '%';
    }
    if ($active_siri > 0) {
        $whereArr[] = "se.siri_id = ?";
        $bindTypes .= 'i';
        $bindVals[] = $active_siri;
    }

    $whereSql = implode(" AND ", $whereArr);

    $sql = "
        SELECT st.student_id, st.student_name, st.gender, st.year,
               COALESCE(sc.school_name,'Tiada Rekod') AS school_name,
               COALESCE(l.level_name,'Tiada Rekod')   AS level_name,
               COALESCE(se.session_name,'Tiada Rekod') AS session_name,
               SUM(scores.mark)  AS total_mark,
               SUM(c.max_mark)   AS max_mark,
               GROUP_CONCAT(DISTINCT j.name SEPARATOR ', ') AS judges
        FROM students st
        LEFT JOIN schools  sc ON st.school_id = sc.school_id
        LEFT JOIN levels   l  ON st.level_id  = l.level_id
        LEFT JOIN sessions se ON l.session_id = se.session_id
        LEFT JOIN group_students gs ON st.student_id = gs.student_id
        LEFT JOIN `groups` g ON gs.group_id = g.group_id
        LEFT JOIN judges   j  ON g.judge_id  = j.id
        LEFT JOIN scores      ON scores.student_id = st.student_id
        LEFT JOIN criteria c  ON scores.criteria_id = c.criteria_id
        WHERE $whereSql
        GROUP BY st.student_id
    ";

    // Conditionally apply sorting
    if ($sort_name === 'ASC') {
        $sql .= " ORDER BY st.student_name ASC";
    } elseif ($sort_name === 'DESC') {
        $sql .= " ORDER BY st.student_name DESC";
    } else {
        // Default sorting
        $sql .= " ORDER BY st.year DESC, se.session_name, l.level_name, sc.school_name, st.student_name";
    }

    $stmt = $conn->prepare($sql);
    if ($bindTypes)
        $stmt->bind_param($bindTypes, ...$bindVals);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    $no = 1;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $tot = $row['total_mark'] ?: 0;
            $max = $row['max_mark'] ?: 0;
            $pct = $max > 0 ? round(($tot / $max) * 100, 1) : 0;
            $judges = htmlspecialchars($row['judges'] ?: '-');

            // Translate gender to Malay
            $jantina = $row['gender'];
            if ($jantina === 'Male') {
                $jantina = 'Lelaki';
            } elseif ($jantina === 'Female') {
                $jantina = 'Perempuan';
            }

            echo "<tr class='master-row'>
                    <td style='text-align:center; color: var(--c-text-faint);'>$no</td>
                    <td><span class='student-name'>" . htmlspecialchars($row['student_name']) . "</span></td>
                    <td style='color:var(--c-text-muted);'>" . htmlspecialchars($jantina) . "</td>
                    <td><span class='year-val'>" . htmlspecialchars($row['year']) . "</span></td>
                    <td style='color:var(--c-text-muted);'>" . htmlspecialchars($row['school_name']) . "</td>
                    <td style='color:var(--c-text-muted);'>" . htmlspecialchars($row['level_name']) . "</td>
                    <td><span class='session-badge'>" . htmlspecialchars($row['session_name']) . "</span></td>
                    <td>
                        <div class='mark-pill'>
                            $tot / $max <span class='mark-pct'>($pct%)</span>
                        </div>
                    </td>
                    <td style='color:var(--c-text-muted); font-size:0.9rem;'>$judges</td>
                  </tr>";
            $no++;
        }
    } else {
        echo "<tr><td colspan='9' style='text-align:center;padding:30px;color:var(--c-text-faint);'>Tiada rekod ditemui untuk tapisan ini.</td></tr>";
    }
    exit();
}

$pm_page = 'master_list';
include 'layout.php';
?>

<style>
    /* ── TABLE HEADER: theme-aware, no hardcoded dark ── */
    .master-table th {
        background: var(--c-surface-2) !important;
        color: var(--c-text) !important;
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.05rem !important;
        letter-spacing: 0.05em;
        position: sticky;
        top: 0;
        z-index: 10;
        border: none !important;
        box-shadow: 0 2px 0 var(--c-red);
        white-space: nowrap;
    }

    /* ── TABLE CELLS: use theme text colors ── */
    .master-table td {
        vertical-align: middle !important;
        border-bottom: 1px solid var(--c-border);
        color: var(--c-text);
    }

    .master-table td .student-name {
        font-weight: 800;
        font-size: 1.05rem;
        letter-spacing: 0.3px;
        color: var(--c-text);
    }

    .master-table td .year-val {
        font-weight: 600;
        color: var(--c-text);
    }

    .master-table td .mark-pill {
        background: var(--c-surface-0);
        border: 1px solid var(--c-border-strong);
        color: var(--c-text);
        padding: 4px 12px;
        border-radius: 20px;
        font-weight: 700;
        font-size: 1rem;
        font-family: "DM Mono", monospace;
        display: inline-flex;
        align-items: baseline;
        gap: 4px;
        white-space: nowrap;
    }

    .master-table td .mark-pct {
        font-family: "DM Sans", sans-serif;
        font-size: 0.65rem;
        font-weight: 600;
        text-transform: uppercase;
        color: var(--c-text-faint);
    }

    .master-table td .session-badge {
        background: rgba(214,40,40,0.15);
        padding: 4px 8px;
        border-radius: 4px;
        color: var(--c-red);
        font-weight: 600;
        font-size: 0.85rem;
        white-space: nowrap;
        display: inline-block;
    }

    /* ── TABLE SCROLL: fixed height so pagination stays on screen ── */
    .table-scroll-wrapper {
        max-height: calc(100vh - 340px);
        overflow-y: auto;
        position: relative;
        scrollbar-width: thin;
        scrollbar-color: var(--c-surface-3) transparent;
    }

    /* ── PAGINATION: silibus-style ── */
    .pagination-container {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        padding: 12px 20px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        gap: 16px;
    }

    .pagination-left {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }

    .pagination-info {
        font-size: 0.85rem;
        color: var(--c-text-muted);
        font-weight: 600;
    }

    .pagination-controls {
        display: flex;
        gap: 6px;
        flex-wrap: wrap;
    }

    .page-btn {
        padding: 4px 12px;
        font-size: 0.85rem;
        border: 1px solid var(--c-border-strong);
        background: var(--c-surface-1);
        color: var(--c-text);
        border-radius: 4px;
        cursor: pointer;
        font-weight: 600;
        transition: 0.2s ease;
    }

    .page-btn:hover:not(:disabled) {
        background: var(--c-surface-3);
        border-color: var(--c-text-muted);
    }

    .page-btn.active {
        background: var(--c-red);
        color: #fff;
        border-color: var(--c-red);
    }

    .page-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
    }

    @media (max-width: 640px) {
        .pagination-container {
            flex-direction: column;
            justify-content: center;
            text-align: center;
        }
        .pagination-left { justify-content: center; }
        .pagination-controls { width: 100%; justify-content: center; }
    }

    /* ── FILTER FORM ── */
    #masterFilterForm label {
        display: block;
        font-size: 0.75rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.07em;
        color: var(--c-text-faint);
        margin-bottom: 5px;
    }

    #masterFilterForm input,
    #masterFilterForm select {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-text);
        border-radius: 6px;
        padding: 8px 10px;
        font-size: 0.875rem;
        font-family: 'DM Sans', sans-serif;
        outline: none;
        width: 100%;
        transition: border-color 0.2s, box-shadow 0.2s;
    }

    #masterFilterForm input:focus,
    #masterFilterForm select:focus {
        border-color: var(--c-red);
        box-shadow: 0 0 0 3px var(--c-red-dim);
    }

    #masterFilterForm input::placeholder {
        color: var(--c-text-faint);
    }

    /* ── SEARCHABLE DROPDOWN ── */
    .name-dropdown-wrapper {
        position: relative;
    }

    .name-dropdown-box {
        position: absolute;
        top: calc(100% + 4px);
        left: 0;
        right: 0;
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        border-radius: 6px;
        z-index: 100;
        max-height: 220px;
        overflow-y: auto;
        box-shadow: 0 8px 24px rgba(0,0,0,0.25);
        display: none;
    }

    .name-dropdown-box.open { display: block; }

    .name-dropdown-box .dd-search {
        position: sticky;
        top: 0;
        background: var(--c-surface-2);
        padding: 8px;
        border-bottom: 1px solid var(--c-border);
    }

    .name-dropdown-box .dd-search input {
        width: 100%;
        padding: 6px 10px;
        border-radius: 4px;
        border: 1px solid var(--c-border-strong);
        background: var(--c-surface-1);
        color: var(--c-text);
        font-size: 0.85rem;
        outline: none;
    }

    .name-dropdown-box .dd-option {
        padding: 8px 12px;
        cursor: pointer;
        font-size: 0.875rem;
        color: var(--c-text);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .name-dropdown-box .dd-option:hover,
    .name-dropdown-box .dd-option.selected {
        background: var(--c-red-dim);
        color: var(--c-red);
    }

    .name-dropdown-box .dd-empty {
        padding: 12px;
        font-size: 0.85rem;
        color: var(--c-text-faint);
        text-align: center;
    }
    
    @media (max-width: 768px) {
        .master-table th,
        .master-table td { font-size: 0.75rem; padding: 6px 8px; }
        .master-table td .student-name { font-size: 0.85rem; }
        .master-table td .mark-pill { font-size: 0.8rem; padding: 3px 8px; }
        .pm-table-wrap { overflow-x: auto; -webkit-overflow-scrolling: touch; }
    }
</style>

<div style='display:flex;justify-content:space-between;align-items:center;margin-bottom:18px;'>
    <div>
        <h2
            style='color: var(--c-text); font-family: "Bebas Neue", sans-serif; font-size: 1.8rem; letter-spacing: 0.05em; margin-bottom: 4px;'>
            📋 Senarai Induk Pesilat <span
                style='font-size:0.4em; color:#fff; vertical-align:middle; background:var(--c-red); padding:2px 6px; border-radius:4px; letter-spacing:0.1em;'>LIVE</span>
        </h2>
        <div style='color:var(--c-text-faint); font-size:0.85rem;'>Markah dan Juri dikemaskini secara automatik.</div>
    </div>
</div>

<div class='pm-card' style='margin-bottom:20px; border-color: var(--c-border-strong);'>
    <form id='masterFilterForm' method='GET'
        style='display:grid; grid-template-columns:repeat(auto-fit,minmax(150px,1fr)); gap:12px; align-items:end;'>
        <div>
            <label>Carian Nama</label>
            <div class="name-dropdown-wrapper" id="nameDropdownWrapper">
                <input type="text" id="nameDropdownTrigger" class="pm-input" placeholder="Semua Pesilat"
                    readonly style="cursor:pointer; background:var(--c-surface-2); border:1px solid var(--c-border-strong); color:var(--c-text); border-radius:6px; padding:8px 10px; font-size:0.875rem; width:100%;"
                    onclick="toggleNameDropdown()">
                <!-- Hidden input carries the actual search value to the form -->
                <input type="hidden" name="search" id="nameSearchValue" value="<?= htmlspecialchars($_GET['search'] ?? '') ?>">
                <div class="name-dropdown-box" id="nameDropdownBox">
                    <div class="dd-search">
                        <input type="text" id="nameDropdownSearch" placeholder="Taip untuk cari..." oninput="filterNameOptions(this.value)" onclick="event.stopPropagation()">
                    </div>
                    <div id="nameDropdownList">
                        <!-- Options injected by JS after data loads -->
                    </div>
                </div>
            </div>
        </div>
        <div>
            <label>Tahun</label>
            <select name='year' onchange='fetchMasterData(true)'>
                <option value=''>Semua Tahun</option>
                <?php
                $years = $conn->query("SELECT DISTINCT year FROM students ORDER BY year DESC");
                while ($y = $years->fetch_assoc()) {
                    $sel = (($_GET['year'] ?? '') == $y['year']) ? "selected" : "";
                    echo "<option value='{$y['year']}' $sel>{$y['year']}</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label>Sidang</label>
            <select name='session_id' onchange='fetchMasterData(true)'>
                <option value=''>Semua Sidang</option>
                <?php
                $sessions = $conn->query("SELECT * FROM sessions ORDER BY session_name");
                while ($s = $sessions->fetch_assoc()) {
                    $sel = (($_GET['session_id'] ?? '') == $s['session_id']) ? "selected" : "";
                    echo "<option value='{$s['session_id']}' $sel>{$s['session_name']}</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label>Peringkat</label>
            <select name='level_id' onchange='fetchMasterData(true)'>
                <option value=''>Semua Peringkat</option>
                <?php
                $levels = $conn->query("SELECT * FROM levels ORDER BY level_name");
                while ($l = $levels->fetch_assoc()) {
                    $sel = (($_GET['level_id'] ?? '') == $l['level_id']) ? "selected" : "";
                    echo "<option value='{$l['level_id']}' $sel>{$l['level_name']}</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label>Cawangan</label>
            <select name='school_id' onchange='fetchMasterData(true)'>
                <option value=''>Semua Cawangan</option>
                <?php
                $schools = $conn->query("SELECT * FROM schools ORDER BY school_name");
                while ($sch = $schools->fetch_assoc()) {
                    $sel = (($_GET['school_id'] ?? '') == $sch['school_id']) ? "selected" : "";
                    echo "<option value='{$sch['school_id']}' $sel>{$sch['school_name']}</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label>Jantina</label>
            <select name='gender' onchange='fetchMasterData(true)'>
                <option value=''>Semua</option>
                <option value='Male' <?= (($_GET['gender'] ?? '') == 'Male' ? 'selected' : '') ?>>Lelaki</option>
                <option value='Female' <?= (($_GET['gender'] ?? '') == 'Female' ? 'selected' : '') ?>>Perempuan</option>
            </select>
        </div>
    </form>
</div>

<div class='pm-card' style='padding:0; border-color: var(--c-border-strong); overflow:hidden;'>
    <div class='pm-table-wrap table-scroll-wrapper' style='border:none;'>
        <table class='pm-table master-table'>
            <thead>
                <tr>
                    <th style='width: 40px; text-align:center;'>No</th>
                    <th onclick='toggleSortName()' style='cursor:pointer; user-select:none;' title='Susun A-Z / Z-A'>
                        <div style='display:inline-flex; align-items:center; gap:6px;'>
                            Nama Pesilat 
                            <span id='sortIcon' style='display:inline-flex; align-items:center; color:var(--c-text-faint); margin-top:1px;'>
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/></svg>
                            </span>
                        </div>
                    </th>
                    <th>Jantina</th>
                    <th>Tahun</th>
                    <th>Cawangan</th>
                    <th>Peringkat</th>
                    <th>Sidang</th>
                    <th>Markah (%)</th>
                    <th>Juri Bertugas</th>
                </tr>
            </thead>
            <tbody id='master_tbody'>
                <tr>
                    <td colspan='9' style='text-align:center;padding:30px;color:var(--c-text-faint);'>Memuatkan data secara langsung...</td>
                </tr>
            </tbody>
        </table>
    </div>
    <!-- Silibus-style pagination footer -->
    <div class="pagination-container" id="masterPaginationContainer" style="display:none;">
        <div class="pagination-left">
            <select id="masterRowsPerPage" class="pm-select" style="padding:4px 8px; height:auto; width:auto; font-size:0.8rem;" onchange="changeMasterRowsPerPage()">
                <option value="10">10 / mukasurat</option>
                <option value="15" selected>15 / mukasurat</option>
                <option value="30">30 / mukasurat</option>
            </select>
            <div class="pagination-info" id="masterPageInfo">Memaparkan 0 rekod</div>
        </div>
        <div class="pagination-controls" id="masterPaginationButtons">
            <!-- Injected by JS -->
        </div>
    </div>
</div>

<script>
    let pmMasterCurrentPage = 1;
    let pmMasterRowsPerPage = 15;
    let pmMasterRows = [];
    let pmSortNameDir = '';
    let allStudentNames = [];

    // ── Pagination render ─────────────────────────────────────────
    function updateMasterPagination() {
        const tbody = document.getElementById('master_tbody');
        pmMasterRows = tbody ? Array.from(tbody.querySelectorAll('tr')).filter(tr => tr.cells.length > 1) : [];

        const container = document.getElementById('masterPaginationContainer');
        if (pmMasterRows.length === 0) { container.style.display = 'none'; return; }
        container.style.display = 'flex';

        const totalRows  = pmMasterRows.length;
        const totalPages = Math.ceil(totalRows / pmMasterRowsPerPage) || 1;

        if (pmMasterCurrentPage > totalPages) pmMasterCurrentPage = totalPages;
        if (pmMasterCurrentPage < 1)          pmMasterCurrentPage = 1;

        const start = (pmMasterCurrentPage - 1) * pmMasterRowsPerPage;
        const end   = start + pmMasterRowsPerPage;

        pmMasterRows.forEach((row, i) => { row.style.display = (i >= start && i < end) ? '' : 'none'; });

        const startText = totalRows === 0 ? 0 : start + 1;
        const endText   = Math.min(end, totalRows);
        document.getElementById('masterPageInfo').innerHTML =
            `Memaparkan <b>${startText} - ${endText}</b> daripada <b>${totalRows}</b> rekod`;

        // Build numbered page buttons
        let html = '';
        html += `<button class="page-btn" ${pmMasterCurrentPage === 1 ? 'disabled' : ''} onclick="masterGoToPage(${pmMasterCurrentPage - 1})">«</button>`;

        let sp = Math.max(1, pmMasterCurrentPage - 2);
        let ep = Math.min(totalPages, sp + 4);
        if (ep - sp < 4) sp = Math.max(1, ep - 4);

        if (sp > 1) {
            html += `<button class="page-btn" onclick="masterGoToPage(1)">1</button>`;
            if (sp > 2) html += `<span style="color:var(--c-text-faint); margin:0 2px; align-self:end;">...</span>`;
        }
        for (let i = sp; i <= ep; i++) {
            html += `<button class="page-btn ${i === pmMasterCurrentPage ? 'active' : ''}" onclick="masterGoToPage(${i})">${i}</button>`;
        }
        if (ep < totalPages) {
            if (ep < totalPages - 1) html += `<span style="color:var(--c-text-faint); margin:0 2px; align-self:end;">...</span>`;
            html += `<button class="page-btn" onclick="masterGoToPage(${totalPages})">${totalPages}</button>`;
        }
        html += `<button class="page-btn" ${pmMasterCurrentPage === totalPages || totalPages === 0 ? 'disabled' : ''} onclick="masterGoToPage(${pmMasterCurrentPage + 1})">»</button>`;

        document.getElementById('masterPaginationButtons').innerHTML = html;
    }

    window.masterGoToPage = function(page) {
        pmMasterCurrentPage = page;
        updateMasterPagination();
        document.querySelector('.table-scroll-wrapper').scrollTo({ top: 0, behavior: 'smooth' });
    };

    function changeMasterRowsPerPage() {
        pmMasterRowsPerPage = parseInt(document.getElementById('masterRowsPerPage').value);
        pmMasterCurrentPage = 1;
        updateMasterPagination();
    }

    // ── Sort ─────────────────────────────────────────────────────
    function toggleSortName() {
        if (pmSortNameDir === '') pmSortNameDir = 'ASC';
        else if (pmSortNameDir === 'ASC') pmSortNameDir = 'DESC';
        else pmSortNameDir = '';

        const icon = document.getElementById('sortIcon');
        if (pmSortNameDir === 'ASC') {
            icon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--c-red)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m6 15 6-6 6 6"/></svg>';
        } else if (pmSortNameDir === 'DESC') {
            icon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--c-red)" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';
        } else {
            icon.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m7 15 5 5 5-5"/><path d="m7 9 5-5 5 5"/></svg>';
        }
        fetchMasterData(true);
    }

    // ── Searchable name dropdown ──────────────────────────────────
    function toggleNameDropdown() {
        const box = document.getElementById('nameDropdownBox');
        box.classList.toggle('open');
        if (box.classList.contains('open')) {
            document.getElementById('nameDropdownSearch').focus();
            filterNameOptions('');
        }
    }

    function filterNameOptions(keyword) {
        const list = document.getElementById('nameDropdownList');
        const kw = keyword.toLowerCase();
        const current = document.getElementById('nameSearchValue').value;

        // "Semua Pesilat" always first
        let html = `<div class="dd-option ${current === '' ? 'selected' : ''}" onclick="selectNameOption('', 'Semua Pesilat')">Semua Pesilat</div>`;

        const filtered = allStudentNames.filter(n => n.toLowerCase().includes(kw));
        if (filtered.length === 0 && kw !== '') {
            html += `<div class="dd-empty">Tiada hasil ditemui</div>`;
        } else {
            filtered.forEach(name => {
                const sel = current === name ? 'selected' : '';
                html += `<div class="dd-option ${sel}" onclick="selectNameOption('${name.replace(/'/g, "\'")}', '${name.replace(/'/g, "\'")}')">${name}</div>`;
            });
        }
        list.innerHTML = html;
    }

    function selectNameOption(value, label) {
        document.getElementById('nameSearchValue').value = value;
        document.getElementById('nameDropdownTrigger').value = label;
        document.getElementById('nameDropdownBox').classList.remove('open');
        fetchMasterData(true);
    }

    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
        const wrapper = document.getElementById('nameDropdownWrapper');
        if (wrapper && !wrapper.contains(e.target)) {
            document.getElementById('nameDropdownBox').classList.remove('open');
        }
    });

    // ── Fetch ─────────────────────────────────────────────────────
    function fetchMasterData(isManual = false) {
        const form = document.getElementById('masterFilterForm');
        const params = new URLSearchParams(new FormData(form));
        if (pmSortNameDir !== '') params.append('sort_name', pmSortNameDir);

        fetch('pic_master_list.php?ajax_master_list=1&' + params.toString())
            .then(r => r.text())
            .then(html => {
                document.getElementById('master_tbody').innerHTML = html;
                if (isManual) pmMasterCurrentPage = 1;

                // Rebuild name list from current results (unfiltered — fetch all names once)
                if (isManual && document.getElementById('nameSearchValue').value === '') {
                    const rows = document.querySelectorAll('#master_tbody tr.master-row');
                    const names = [];
                    rows.forEach(row => {
                        const nameEl = row.querySelector('.student-name');
                        if (nameEl) names.push(nameEl.textContent.trim());
                    });
                    allStudentNames = [...new Set(names)].sort();
                    filterNameOptions('');
                }

                updateMasterPagination();
            }).catch(err => console.error(err));
    }

    fetchMasterData(true);
    setInterval(() => fetchMasterData(false), 3000);
</script>
</main>
</body>

</html>