<?php
session_start();
include 'db.php';
$conn = getDB();


// PIC only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {
    header("Location: login.php");
    exit();
}

$pm_page = 'view_marks';
include 'layout.php';

/* FILTER DATA — scoped to "Siri Aktif" so the dropdowns and the marks table
   below only ever show data from the currently selected siri. */
$active_siri = (int)($_SESSION['active_siri_id'] ?? 0);
$siri_sessions_sub = "(SELECT session_id FROM sessions WHERE siri_id = $active_siri)";

if ($active_siri > 0) {
    $groups = $conn->query("SELECT group_id, group_name FROM `groups` WHERE session_id IN $siri_sessions_sub ORDER BY group_name");
    $tests  = $conn->query("SELECT t.test_id, t.test_name FROM tests t JOIN levels l ON t.level_id = l.level_id WHERE l.session_id IN $siri_sessions_sub ORDER BY t.test_name");
} else {
    $groups = $conn->query("SELECT group_id, group_name FROM `groups` ORDER BY group_name");
    $tests  = $conn->query("SELECT test_id, test_name FROM tests ORDER BY test_name");
}

$filter_group   = isset($_GET['group_id']) ? (int)$_GET['group_id'] : 0;
if ($filter_group > 0) {
    $students = $conn->query("SELECT DISTINCT s.student_id, s.student_name FROM group_students gs JOIN students s ON gs.student_id = s.student_id WHERE gs.group_id = $filter_group ORDER BY s.student_name");
} elseif ($active_siri > 0) {
    $students = $conn->query("SELECT student_id, student_name FROM students WHERE level_id IN (SELECT level_id FROM levels WHERE session_id IN $siri_sessions_sub) ORDER BY student_name");
} else {
    $students = $conn->query("SELECT student_id, student_name FROM students ORDER BY student_name");
}

$filter_student = isset($_GET['student_id']) ? (int)$_GET['student_id'] : 0;
$filter_test    = isset($_GET['test_id']) ? (int)$_GET['test_id'] : 0;

/* FETCH MARKS */
$where = [];
// Change from looking at 'sc' (scores) to looking at 'g' (groups) and 's' (students) so we don't filter out unscored students
if ($filter_group)   $where[] = "g.group_id = $filter_group";
if ($filter_student) $where[] = "s.student_id = $filter_student";
// If a test filter is applied, show rows matching the test, OR show students with no scores at all
if ($filter_test)    $where[] = "(sc.test_id = $filter_test OR sc.test_id IS NULL)";
if ($active_siri > 0) $where[] = "s.level_id IN (SELECT level_id FROM levels WHERE session_id IN $siri_sessions_sub)";

$where_sql = $where ? "WHERE " . implode(" AND ", $where) : "";

$sql = "
SELECT 
    COALESCE(g.group_name, 'Tiada Kumpulan') AS group_name, 
    s.student_name, 
    COALESCE(t.test_name, 'Belum Dinilai') AS test_name, 
    COALESCE(c.criteria_name, '-') AS criteria_name, 
    COALESCE(sc.mark, 0) AS mark
FROM students s
LEFT JOIN group_students gs ON s.student_id = gs.student_id
LEFT JOIN `groups` g ON gs.group_id = g.group_id
LEFT JOIN scores sc ON s.student_id = sc.student_id
LEFT JOIN criteria c ON sc.criteria_id = c.criteria_id
LEFT JOIN tests t ON sc.test_id = t.test_id
$where_sql
ORDER BY g.group_name, s.student_name, t.test_name, c.criteria_name
";
$res = $conn->query($sql);

$marks = [];
while ($r = $res->fetch_assoc()) {
    $marks[$r['group_name']][$r['student_name']][] = $r;
}
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<style>
/* ── PREMIUM SELECT2 DARK THEME ── */
.select2-container .select2-selection--single { background: var(--c-surface-2) !important; border: 1px solid var(--c-border-strong) !important; border-radius: 6px !important; height: 38px !important; }
.select2-container--default .select2-selection--single .select2-selection__rendered { color: var(--c-white) !important; line-height: 36px !important; padding-left: 12px !important; font-size: 0.85rem !important; }
.select2-container--default .select2-selection--single .select2-selection__arrow { height: 36px !important; }
.select2-dropdown { background: var(--c-surface-1) !important; border: 1px solid var(--c-border-strong) !important; }
.select2-results__option { color: var(--c-white) !important; font-size: 0.85rem !important; }
.select2-results__option--highlighted { background: var(--c-red) !important; }
.select2-search__field { background: var(--c-surface-0) !important; color: var(--c-white) !important; border: 1px solid var(--c-border-strong) !important; }

/* ── LAYOUT ── */
.filter-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}

/* ── MODERN ACCORDION STYLES (COMPACT) ── */
.group-title {
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--c-text-faint);
    text-transform: uppercase;
    letter-spacing: 1.5px;
    margin: 20px 0 10px 0;
    display: flex;
    align-items: center;
    gap: 8px;
}
.group-title svg {
    stroke: var(--c-text-faint);
    width: 14px;
    height: 14px;
}
.group-title::after {
    content: '';
    flex: 1;
    height: 1px;
    background: linear-gradient(90deg, var(--c-border-strong), transparent);
}

.student-card {
    background: var(--c-surface-1);
    border: 1px solid var(--c-border);
    border-radius: 8px;
    margin-bottom: 8px;
    overflow: hidden;
    transition: all 0.2s ease;
}
.student-card:hover {
    border-color: var(--c-border-strong);
    background: var(--c-surface-2);
}

.student-header {
    padding: 10px 14px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    background: transparent;
}

.student-name {
    font-size: 0.9rem;
    font-weight: 600;
    color: var(--c-white);
    letter-spacing: 0.2px;
}

.chevron {
    transition: transform 0.2s ease;
    color: var(--c-text-faint);
    font-size: 0.7rem;
}
.student-card.is-open .chevron {
    transform: rotate(180deg);
    color: var(--c-red);
}

/* ── COMPACT BADGES ── */
.score-badge {
    background: var(--c-surface-0);
    border: 1px solid var(--c-border-strong);
    color: var(--c-white);
    padding: 3px 12px;
    border-radius: 20px; 
    font-weight: 700;
    font-size: 1rem;
    font-family: 'DM Mono', monospace;
    display: flex;
    align-items: baseline;
    gap: 4px;
}
.score-badge span {
    font-family: 'DM Sans', sans-serif;
    font-size: 0.65rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: var(--c-text-faint);
}

/* Unrated: Red tint (Still indicates action needed) */
.status-badge {
    background: rgba(214, 40, 40, 0.1);
    color: #F87171;
    border: 1px solid rgba(214, 40, 40, 0.3);
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

/* Rated: High-contrast White/Gray (Indicates completion) */
.status-badge-success {
    background: rgba(255, 255, 255, 0.12);
    color: var(--c-white);
    border: 1px solid var(--c-border-strong);
    box-shadow: 0 0 8px rgba(255, 255, 255, 0.15);
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 0.65rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
    gap: 4px;
}

.student-details {
    display: none;
    padding: 0 14px 14px 14px;
    border-top: 1px solid var(--c-border);
    margin-top: 4px;
}

/* ── COMPACT INNER TABLE ── */
.modern-table {
    width: 100%;
    border-collapse: separate;
    border-spacing: 0 4px;
}
.modern-table th {
    color: var(--c-text-faint);
    font-weight: 600;
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    padding: 0 10px 6px 10px;
    border-bottom: 1px solid var(--c-border);
    text-align: left;
}
.modern-table td {
    padding: 8px 10px;
    background: var(--c-surface-0);
    color: var(--c-text-muted);
    font-size: 0.85rem;
}
.modern-table tr td:first-child { border-top-left-radius: 6px; border-bottom-left-radius: 6px; }
.modern-table tr td:last-child {
    border-top-right-radius: 6px;
    border-bottom-right-radius: 6px;
    text-align: center;
    font-weight: 700;
    color: var(--c-white);
    font-family: 'DM Mono', monospace;
    font-size: 0.95rem;
}

/* ── DRILLDOWN PICKER ── */
.drilldown-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 12px;
    margin-bottom: 20px;
}
.drilldown-grid label {
    color: var(--pm-text-muted);
    font-size: 0.8rem;
    margin-bottom: 4px;
    display: block;
    text-transform: uppercase;
    font-weight: 600;
}
.drilldown-empty {
    text-align: center;
    padding: 40px 20px;
    color: var(--c-text-faint);
    background: var(--c-surface-1);
    border-radius: 8px;
    border: 1px dashed var(--c-border-strong);
    margin-top: 20px;
}
.select2-container--disabled .select2-selection--single {
    opacity: 0.5;
    cursor: not-allowed;
}
</style>

<h2 class="pm-page-heading">📊 Semak Markah</h2>

<div class="pm-card">
    <form method="GET" class="filter-grid">
        <div>
            <label style="color:var(--pm-text-muted); font-size:0.8rem; margin-bottom:4px; display:block; text-transform: uppercase; font-weight: 600;">Kumpulan</label>
            <select name="group_id" class="select-search" onchange="this.form.submit()">
                <option value="">Semua Kumpulan</option>
                <?php while($g=$groups->fetch_assoc()): ?>
                <option value="<?= $g['group_id'] ?>" <?= $filter_group==$g['group_id']?'selected':'' ?>><?= htmlspecialchars($g['group_name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div>
            <label style="color:var(--pm-text-muted); font-size:0.8rem; margin-bottom:4px; display:block; text-transform: uppercase; font-weight: 600;">Pelajar</label>
            <select name="student_id" class="select-search" onchange="this.form.submit()">
                <option value="">Semua Pelajar</option>
                <?php while($s = $students->fetch_assoc()): ?>
                <option value="<?= $s['student_id'] ?>" <?= $filter_student == $s['student_id'] ? 'selected' : '' ?>><?= htmlspecialchars($s['student_name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>

        <div>
            <label style="color:var(--pm-text-muted); font-size:0.8rem; margin-bottom:4px; display:block; text-transform: uppercase; font-weight: 600;">Ujian</label>
            <select name="test_id" class="select-search" onchange="this.form.submit()">
                <option value="">Semua Ujian</option>
                <?php while($t=$tests->fetch_assoc()): ?>
                <option value="<?= $t['test_id'] ?>" <?= $filter_test==$t['test_id']?'selected':'' ?>><?= htmlspecialchars($t['test_name']) ?></option>
                <?php endwhile; ?>
            </select>
        </div>
    </form>

    <div style="margin-top: 10px;">
        <?php if($marks): ?>
            <div class="drilldown-grid">
                <div>
                    <label>Kumpulan</label>
                    <select id="drilldownGroup" class="select-search-drilldown">
                        <option value="">— Pilih Kumpulan —</option>
                        <?php foreach($marks as $group => $studentsArr): ?>
                        <option value="<?= htmlspecialchars($group) ?>"><?= htmlspecialchars($group) ?> (<?= count($studentsArr) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label>Pelajar</label>
                    <select id="drilldownStudent" class="select-search-drilldown" disabled>
                        <option value="">— Pilih Kumpulan dahulu —</option>
                    </select>
                </div>
            </div>

            <div id="drilldownDetails"></div>

            <div id="drilldownPlaceholder" class="drilldown-empty">
                <p style="margin:0; font-size: 0.9rem;">Sila pilih kumpulan dan pelajar untuk melihat markah.</p>
            </div>

            <script>
            window.MARKS_DATA = <?= json_encode($marks, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
            </script>
        <?php else: ?>
            <div class="drilldown-empty">
                <p style="margin:0; font-size: 0.9rem;">Tiada pelajar ditemui untuk carian ini.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
$(document).ready(function() {
    $('.select-search').select2({
        width:'100%'
    });
});
</script>

<script>
(function() {
    var data = window.MARKS_DATA || {};
    var groupSelect = document.getElementById('drilldownGroup');
    var studentSelect = document.getElementById('drilldownStudent');
    var detailsBox = document.getElementById('drilldownDetails');
    var placeholder = document.getElementById('drilldownPlaceholder');
    if (!groupSelect) return;

    function escapeHtml(str) {
        return String(str).replace(/[&<>"']/g, function(c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function initSelect2() {
        $('#drilldownGroup, #drilldownStudent').select2({
            width: '100%',
            placeholder: function() { return $(this).find('option:first').text(); }
        });
    }

    function refreshStudentOptions() {
        // select2 needs destroy+reinit (or .trigger('change.select2')) to pick up new <option> nodes
        $('#drilldownStudent').select2('destroy');
        $('#drilldownStudent').select2({ width: '100%' });
    }

    function populateStudents(group) {
        studentSelect.innerHTML = '';
        detailsBox.innerHTML = '';
        if (!group || !data[group]) {
            studentSelect.disabled = true;
            studentSelect.innerHTML = '<option value="">— Pilih Kumpulan dahulu —</option>';
            placeholder.style.display = '';
            refreshStudentOptions();
            return;
        }
        studentSelect.disabled = false;
        studentSelect.innerHTML = '<option value="">— Pilih Pelajar —</option>';
        Object.keys(data[group]).forEach(function(student) {
            var opt = document.createElement('option');
            opt.value = student;
            opt.textContent = student;
            studentSelect.appendChild(opt);
        });
        placeholder.style.display = '';
        refreshStudentOptions();
    }

    function renderStudent(group, student) {
        detailsBox.innerHTML = '';
        if (!group || !student || !data[group] || !data[group][student]) {
            placeholder.style.display = '';
            return;
        }
        placeholder.style.display = 'none';

        var rows = data[group][student];
        var totalMark = 0, isEvaluated = false;
        rows.forEach(function(r) {
            totalMark += parseFloat(r.mark) || 0;
            if (r.test_name !== 'Belum Dinilai') isEvaluated = true;
        });

        var statusHtml = isEvaluated
            ? '<span class="status-badge-success"><svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>Sudah Dinilai</span>'
            : '<span class="status-badge">Belum Dinilai</span>';

        var rowsHtml = rows.map(function(r) {
            return '<tr><td style="color:var(--c-text-faint);">' + escapeHtml(r.test_name) + '</td><td>' + escapeHtml(r.criteria_name) + '</td><td>' + escapeHtml(r.mark) + '</td></tr>';
        }).join('');

        detailsBox.innerHTML =
            '<div class="student-card is-open">' +
                '<div class="student-header" style="cursor:default;">' +
                    '<div style="display:flex; align-items:center; gap:12px;">' +
                        '<span class="student-name">' + escapeHtml(student) + '</span>' +
                        statusHtml +
                    '</div>' +
                    '<div class="score-badge">' + totalMark + ' <span>Markah</span></div>' +
                '</div>' +
                '<div class="student-details" style="display:block;">' +
                    '<table class="modern-table">' +
                        '<thead><tr><th>Ujian</th><th>Kriteria</th><th style="width:80px; text-align:center;">Markah</th></tr></thead>' +
                        '<tbody>' + rowsHtml + '</tbody>' +
                    '</table>' +
                '</div>' +
            '</div>';
    }

    initSelect2();

    $('#drilldownGroup').on('change', function() {
        populateStudents(this.value);
    });
    $('#drilldownStudent').on('change', function() {
        renderStudent(groupSelect.value, this.value);
    });

    // Auto-select if there's only one group, to save a click
    var groupKeys = Object.keys(data);
    if (groupKeys.length === 1) {
        $('#drilldownGroup').val(groupKeys[0]).trigger('change');
    }
})();
</script>

</main>
</body>
</html>