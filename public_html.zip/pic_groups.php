<?php
ini_set('display_errors', 0); ini_set('display_startup_errors', 0);
error_reporting(E_ALL); ini_set('log_errors', 1);

session_start();
include 'db.php';
$conn = getDB();


if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {
    header("Location: login.php"); exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_write_close();
    if ($_POST['action'] === 'delete') {
        $gid = (int)$_POST['group_id'];
        foreach (["DELETE FROM group_students WHERE group_id=?","DELETE FROM `groups` WHERE group_id=?"] as $sql) {
            $stmt = $conn->prepare($sql); $stmt->bind_param('i', $gid); $stmt->execute(); $stmt->close();
        }
    }
    if ($_POST['action'] === 'save_all' && isset($_POST['groups'])) {
        $stmtUpd = $conn->prepare("UPDATE `groups` SET group_name=?, judge_id=? WHERE group_id=?");
        $stmtDel = $conn->prepare("DELETE FROM group_students WHERE group_id=?");
        $stmtIns = $conn->prepare("INSERT INTO group_students (group_id, student_id) VALUES (?, ?)");
        foreach ($_POST['groups'] as $gid => $g) {
            $gid = (int)$gid;
            $judge_id = !empty($g['judge_id']) ? (int)$g['judge_id'] : NULL;
            $stmtUpd->bind_param('sii', $g['group_name'], $judge_id, $gid); $stmtUpd->execute();
            $stmtDel->bind_param('i', $gid); $stmtDel->execute();
            if (!empty($g['students'])) {
                foreach ($g['students'] as $sid) {
                    $sid = (int)$sid; $stmtIns->bind_param('ii', $gid, $sid); $stmtIns->execute();
                }
            }
        }
        $stmtUpd->close(); $stmtDel->close(); $stmtIns->close();
    }
    if ($_POST['action'] === 'add') {
        $judge_id = !empty($_POST['judge_id']) ? (int)$_POST['judge_id'] : NULL;
        $stmt = $conn->prepare("INSERT INTO `groups` (session_id, level_id, group_name, judge_id) VALUES (?, ?, ?, ?)");
        $stmt->bind_param('iisi', $_POST['session_id'], $_POST['level_id'], $_POST['group_name'], $judge_id);
        $stmt->execute(); $stmt->close();
    }
    header("Location: pic_groups.php"); exit();
}

session_write_close();

// "Semua Siri" (0) is ambiguous across sessions with duplicate names — show a
// Siri picker only in that case so the PIC can narrow down which siri to browse.
$active_siri_id = (int)($_SESSION['active_siri_id'] ?? 0);
$show_siri_picker = $active_siri_id === 0;

// ── AJAX: returns accordion HTML ──────────────────────────────────────────
if (isset($_GET['ajax'])) {
    $filter_group   = $_GET['group_id']   ?? '';
    $filter_session = $_GET['session_id'] ?? '';
    $filter_level   = $_GET['level_id']   ?? '';
    $filter_siri    = $show_siri_picker ? (int)($_GET['siri_id'] ?? 0) : $active_siri_id;

    $gWhereArr = ["1=1"]; $gTypes = ''; $gVals = [];
    if ($filter_group   !== '') { $gWhereArr[] = "g.group_id = ?";   $gTypes .= 'i'; $gVals[] = (int)$filter_group;   }
    if ($filter_session !== '') { $gWhereArr[] = "g.session_id = ?"; $gTypes .= 'i'; $gVals[] = (int)$filter_session; }
    if ($filter_level   !== '') { $gWhereArr[] = "g.level_id = ?";   $gTypes .= 'i'; $gVals[] = (int)$filter_level;   }
    // Uses a subquery rather than "s.siri_id = ?" because this WHERE array
    // gets reused (merged) below for queries that don't join the sessions
    // table under alias "s" — only g.session_id is guaranteed to exist.
    if ($filter_siri     > 0)    { $gWhereArr[] = "g.session_id IN (SELECT session_id FROM sessions WHERE siri_id = ?)"; $gTypes .= 'i'; $gVals[] = $filter_siri; }
    $gWhereSql = implode(" AND ", $gWhereArr);

    $stmt = $conn->prepare("SELECT DISTINCT s.session_id, s.session_name, si.siri_name FROM `groups` g JOIN sessions s ON g.session_id=s.session_id LEFT JOIN siri si ON s.siri_id = si.siri_id WHERE $gWhereSql ORDER BY s.session_name");
    if ($gTypes) $stmt->bind_param($gTypes, ...$gVals);
    $stmt->execute(); $sessions_g = $stmt->get_result(); $stmt->close();

    // Fetched once and reused everywhere below — was previously re-queried for
    // every single group row, which is what made the page lag.
    $judgesList = [];
    $jres = $conn->query("SELECT id, name FROM judges ORDER BY name");
    while ($j = $jres->fetch_assoc()) $judgesList[] = $j;
    $judgeOptionsHtml = "<option value=''>Pilih Juri</option>";
    foreach ($judgesList as $j) {
        $judgeOptionsHtml .= "<option value='{$j['id']}'>" . htmlspecialchars($j['name']) . "</option>";
    }

    $found = false;
    while ($s = $sessions_g->fetch_assoc()) {
        $cur_session_id = $s['session_id'];
        $found = true;
        $siriLabel = $s['siri_name'] ? htmlspecialchars($s['siri_name']) : 'Tiada Siri';
        echo "<div class='accordion-card'>
                <div class='school-header' onclick=\"toggleBlock('session_grp_{$cur_session_id}')\">
                    <span class='arrow'>▶</span><span>" . htmlspecialchars($s['session_name']) . "</span>
                    <span class='siri-tag'>$siriLabel</span>
                </div>
                <div id='session_grp_{$cur_session_id}' style='display:none;padding:12px;'>";

        $lWhereArr = array_merge($gWhereArr, ["g.session_id=?"]);
        $lTypes    = $gTypes . 'i';
        $lVals     = array_merge($gVals, [$cur_session_id]);
        $lStmt     = $conn->prepare("SELECT DISTINCT l.level_id, l.level_name FROM `groups` g JOIN levels l ON g.level_id=l.level_id WHERE " . implode(" AND ", $lWhereArr) . " ORDER BY l.level_name");
        $lStmt->bind_param($lTypes, ...$lVals); $lStmt->execute();
        $levels_g = $lStmt->get_result(); $lStmt->close();

        while ($l = $levels_g->fetch_assoc()) {
            $uid = "grp_lvl_{$cur_session_id}_{$l['level_id']}";
            echo "<div class='accordion-sub-card' id='card_$uid'>
                    <div class='accordion-sub-header' onclick=\"toggleBlock('$uid')\">
                        <span class='arrow'>▶</span><span>" . htmlspecialchars($l['level_name']) . "</span>
                        <div style='margin-left:auto;display:flex;gap:8px;align-items:center;'>
                            <button type='button' class='btn-grp-discard' onclick=\"event.stopPropagation();discardGroup('$uid')\">Batal</button>
                            <button type='submit' form='form_$uid' class='pm-btn pm-btn-primary grp-save-btn' style='font-size:0.78rem;padding:5px 12px;' onclick='event.stopPropagation()'>💾 Simpan</button>
                        </div>
                    </div>
                    <div id='$uid' style='display:none;'>
                        <form id='form_$uid' method='POST'>
                        <input type='hidden' name='action' value='save_all'>
                        <div class='table-responsive' style='border:none;overflow-x:auto;'><table class='students-table'>
                            <thead><tr><th style='width:40px;text-align:center;'>No</th><th>Nama Kumpulan</th><th style='min-width:150px;'>Juri</th><th>Pelajar Dinilai</th><th style='width:90px;'>Tindakan</th></tr></thead><tbody>";

            $grpWhereArr = array_merge($gWhereArr, ["g.session_id=?","g.level_id=?"]);
            $grpTypes    = $gTypes . 'ii';
            $grpVals     = array_merge($gVals, [$cur_session_id, $l['level_id']]);
            $grpStmt     = $conn->prepare("SELECT * FROM `groups` g WHERE " . implode(" AND ", $grpWhereArr) . " ORDER BY g.group_name");
            $grpStmt->bind_param($grpTypes, ...$grpVals); $grpStmt->execute();
            $groups = $grpStmt->get_result(); $grpStmt->close();
            $groupRows = $groups->fetch_all(MYSQLI_ASSOC);

            // Students for this level — queried once and reused for every group
            // below, instead of once per group (same level_id every time).
            $stStmt = $conn->prepare("SELECT student_id, student_name FROM students WHERE level_id=? ORDER BY student_name");
            $stStmt->bind_param('i', $l['level_id']); $stStmt->execute();
            $levelStudents = $stStmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stStmt->close();

            // Assigned students for ALL groups in this level — one query instead
            // of one per group.
            $assignedByGroup = [];
            if ($groupRows) {
                $gids = array_column($groupRows, 'group_id');
                $inPlaceholders = implode(',', array_fill(0, count($gids), '?'));
                $asStmt = $conn->prepare("SELECT group_id, student_id FROM group_students WHERE group_id IN ($inPlaceholders)");
                $asStmt->bind_param(str_repeat('i', count($gids)), ...$gids);
                $asStmt->execute();
                $asRes = $asStmt->get_result();
                while ($r = $asRes->fetch_assoc()) $assignedByGroup[$r['group_id']][] = $r['student_id'];
                $asStmt->close();
            }

            $no = 1;
            foreach ($groupRows as $g) {
                $gid = $g['group_id'];
                $assigned = $assignedByGroup[$gid] ?? [];

                $judgeOptions = str_replace(
                    "value='{$g['judge_id']}'",
                    "value='{$g['judge_id']}' selected",
                    $judgeOptionsHtml
                );

                echo "<tr><td style='text-align:center;color:var(--c-text-faint);'>$no</td>
                        <td><input name='groups[$gid][group_name]' value='" . htmlspecialchars($g['group_name']) . "'></td>
                        <td><select name='groups[$gid][judge_id]'>$judgeOptions</select></td>
                        <td><div class='assign-checkbox-grid' style='max-height:130px;'>";
                foreach ($levelStudents as $st) {
                    $chk = in_array($st['student_id'], $assigned) ? "checked" : "";
                    echo "<label><input type='checkbox' name='groups[$gid][students][]' value='{$st['student_id']}' $chk>" . htmlspecialchars($st['student_name']) . "</label>";
                }
                echo "  </div></td>
                        <td><div class='tbl-actions'>
                            <button class='pm-btn pm-btn-danger' name='action' value='delete' style='font-size:0.78rem;padding:5px 10px;' onclick=\"this.form.group_id.value='$gid';return confirm('Padam kumpulan ini?')\">Padam</button>
                            <input type='hidden' name='group_id' value='$gid'>
                        </div></td></tr>";
                $no++;
            }
            echo "</tbody></table></div>
                  </form></div></div>";
        }
        echo "</div></div>";
    }
    if (!$found) echo "<p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Tiada kumpulan ditemui.</p>";
    exit();
}

$pm_page = 'groups';
include 'layout.php';
?>

<style>
    .pic-section-header {
     display:flex;
     justify-content:space-between;
     align-items:center;
     flex-wrap:wrap;
     gap:12px;
     margin-bottom:20px;
    }
     .pic-section-header h2 {
         font-family:'Bebas Neue',sans-serif;
         font-size:1.8rem;
         color:var(--c-white);
         letter-spacing:0.05em;
         margin:0;
    }
     .pic-section-sub {
         color:var(--c-text-faint);
         font-size:0.82rem;
         margin-top:2px;
    }
    .students-table {
         width:100%;
         border-collapse:collapse;
         font-size:0.875rem;
         min-width:600px;
    }
    @media (max-width: 768px) {
         .students-table { font-size:0.78rem; min-width:560px; }
         .students-table th, .students-table td { padding:7px 8px; }
         .students-table select { min-width:130px; }
         .students-table input:not([type=checkbox]) { min-width:100px; }
         .assign-checkbox-grid { grid-template-columns:1fr; min-width:120px; }
     }
     .students-table th {
         background:rgba(0,0,0,0.6);
         color:var(--c-text-muted);
         font-size:0.75rem;
         font-weight:600;
         text-transform:uppercase;
         letter-spacing:0.08em;
         padding:11px 14px;
         text-align:left;
         white-space:nowrap;
         border-bottom:2px solid var(--c-red);
         position:sticky;
         top:0;
         z-index:5;
    }
     .students-table td {
         padding:9px 14px;
         color:var(--c-text-muted);
         background:rgba(0,0,0,0.25);
         border-bottom:1px solid rgba(0,0,0,0.8);
         vertical-align:middle;
    }
     .students-table tbody tr:hover td {
         background:rgba(0,0,0,0.5);
    }
     .students-table input:not([type=checkbox]), .students-table select {
         background:var(--c-surface-0)!important;
         border:1px solid var(--c-border-strong)!important;
         color:var(--c-white)!important;
         border-radius:4px!important;
         padding:5px 8px!important;
         font-size:0.82rem!important;
         outline:none!important;
         width:100%;
    }
     .students-table input:focus, .students-table select:focus {
         border-color:var(--c-red)!important;
    }
     .students-table select option {
         background:var(--c-surface-2);
         color:var(--c-white);
    }
     .tbl-actions {
         display:flex;
         gap:6px;
         align-items:center;
    }
     .tbl-toolbar {
         display:flex;
         justify-content:flex-end;
         align-items:center;
         padding:10px 14px;
         border-bottom:1px solid var(--c-border);
         gap:8px;
    }
    .accordion-card {
         background:var(--c-surface-1);
         border:1px solid var(--c-border);
         border-radius:10px;
         margin-bottom:12px;
         overflow:hidden;
    }
     .table-responsive { width:100%; overflow-x:auto; -webkit-overflow-scrolling:touch; }
     .school-header {
         display:flex;
         align-items:center;
         gap:10px;
         padding:12px 16px;
         background:var(--c-surface-1);
         border:1px solid var(--c-border);
         border-radius:8px;
         cursor:pointer;
         color:var(--c-white);
         font-weight:600;
         font-size:0.92rem;
    }
     .school-header .arrow {
         color:var(--c-red);
         font-size:0.9rem;
    }
     .school-header .siri-tag {
         margin-left:auto;
         font-size:0.7rem;
         font-weight:600;
         text-transform:uppercase;
         letter-spacing:0.05em;
         color:var(--c-text-faint);
         background:rgba(214, 40, 40, 0.08);
         border:1px solid var(--c-red-border);
         padding:2px 8px;
         border-radius:10px;
    }
     html.pm-light .school-header .siri-tag {
         background:#fdecec;
         color:#b91c1c;
         border-color:#fca5a5;
    }
     .accordion-sub-card {
         background:var(--c-surface-0);
         border:1px solid var(--c-border);
         border-left:3px solid var(--c-red);
         border-radius:8px;
         margin-bottom:12px;
         overflow:hidden;
    }
    .accordion-sub-header {
         display:flex;
         align-items:center;
         gap:10px;
         padding:10px 14px;
         cursor:pointer;
         color:var(--c-white);
         font-weight:600;
         font-size:0.88rem;
         transition:background .15s;
         user-select:none;
         flex-wrap:wrap;
    }
     @media (max-width: 600px) {
         .accordion-sub-header { gap:6px; padding:8px 10px; }
         .accordion-sub-header > div[style*='margin-left:auto'] { margin-left:0 !important; width:100%; justify-content:flex-end; }
     }
     .accordion-sub-header:hover {
         background:var(--c-surface-1);
    }
     .accordion-sub-header .arrow {
         color:var(--c-red);
         font-size:0.8rem;
    }
     .assign-checkbox-grid {
         display:grid;
         grid-template-columns:repeat(auto-fill,minmax(190px,1fr));
         gap:6px;
         max-height:220px;
         overflow-y:auto;
         padding:12px;
         background:var(--c-surface-0);
         border:1px solid var(--c-border);
         border-radius:6px;
         scrollbar-width:thin;
         scrollbar-color:var(--c-surface-3) transparent;
         margin-bottom:12px;
    }
     .assign-checkbox-grid label {
         display:flex;
         align-items:center;
         gap:8px;
         font-size:0.85rem;
         color:var(--c-text-muted);
         cursor:pointer;
         margin:0;
         padding:4px 6px;
         border-radius:4px;
    }
     .assign-checkbox-grid label:hover {
         background:var(--c-surface-1);
         color:var(--c-white);
    }
     .assign-checkbox-grid input[type=checkbox] {
         accent-color:var(--c-red);
         width:15px;
         height:15px;
         margin:0;
         flex-shrink:0;
    }
     .pic-add-card {
         display:none;
         background:var(--c-surface-1);
         border:1px solid var(--c-red-border);
         border-radius:10px;
         padding:20px;
         margin-bottom:18px;
    }
     .pic-add-card h3 {
         font-family:'Bebas Neue',sans-serif;
         font-size:1.1rem;
         color:var(--c-white);
         margin-bottom:14px;
         letter-spacing:0.05em;
    }
    .pic-add-form {
         display:grid;
         grid-template-columns: 1fr 1fr 1fr 1fr auto;
         gap:10px;
         align-items:end;
    }
     @media (max-width: 768px) {
         .pic-add-form {
             grid-template-columns: 1fr 1fr;
         }
         .pic-add-form button {
             width: 100%;
         }
     }
     @media (max-width: 480px) {
         .pic-add-form {
             grid-template-columns: 1fr;
         }
     }
     .pic-add-form input, .pic-add-form select {
         background:var(--c-surface-2);
         border:1px solid var(--c-border-strong);
         color:var(--c-white);
         border-radius:6px;
         padding:0 12px;
         height:38px;
         font-size:0.875rem;
         outline:none;
         width:100%;
         box-sizing:border-box;
    }
     .pic-add-form button {
         height:38px;
         padding:0 16px;
         font-size:0.875rem;
         box-sizing:border-box;
         line-height:1;
    }
     .pic-add-form input:focus, .pic-add-form select:focus {
         border-color:var(--c-red);
         box-shadow:0 0 0 3px var(--c-red-dim);
    }
     .pic-add-form select option {
         background:var(--c-surface-2);
    }
     .filter-select {
         background:var(--c-surface-2);
         border:1px solid var(--c-border-strong);
         color:var(--c-white);
         border-radius:6px;
         padding:8px 10px;
         font-size:0.875rem;
         outline:none;
         width:100%;
         cursor:pointer;
         transition:border-color .2s;
    }
     .filter-select:focus {
         border-color:var(--c-red);
    }
     .filter-select option {
         background:var(--c-surface-2);
         color:var(--c-white);
    }
     .filter-label {
         display:block;
         font-size:0.75rem;
         font-weight:600;
         text-transform:uppercase;
         color:var(--c-text-faint);
         margin-bottom:4px;
    }
     .filter-grid {
         display:grid;
         grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
         gap:12px;
         align-items:end;
    }
     .filter-card {
         background:var(--c-surface-1);
         border:1px solid var(--c-border-strong);
         border-radius:12px;
         padding:20px;
         margin-bottom:24px;
         box-shadow:0 4px 12px rgba(0,0,0,.08);
    }
     .filter-card-title {
         font-size:.72rem;
         font-weight:700;
         text-transform:uppercase;
         letter-spacing:.12em;
         color:var(--c-text-faint);
         margin-bottom:16px;
    }
     html.pm-light .filter-card {
         background: #fff;
         border-color: #e5e7eb;
         box-shadow: 0 1px 4px rgba(0,0,0,0.06);
    }
     html.pm-light .filter-card-title {
         color: #888;
    }
    /* ── Light mode fixes ── */
     html.pm-light .pic-section-header h2 {
         color: #111;
    }
     html.pm-light .pic-section-sub {
         color: #555;
    }
     html.pm-light .card {
         background: #fff;
         border-color: #e5e7eb !important;
    }
     html.pm-light .filter-label {
         color: #555;
    }
     html.pm-light .filter-select {
         background: #f9fafb;
         border-color: #d1d5db;
         color: #111;
    }
     html.pm-light .filter-select option {
         background: #fff;
         color: #111;
    }
     html.pm-light .pic-add-card {
         background: #fff;
         border-color: var(--c-red-border);
    }
     html.pm-light .pic-add-card h3 {
         color: #111;
    }
     html.pm-light .pic-add-form label {
         color: #555;
    }
     html.pm-light .pic-add-form input, html.pm-light .pic-add-form select {
         background: #f9fafb;
         border-color: #d1d5db;
         color: #111;
    }
     html.pm-light .pic-add-form select option {
         background: #fff;
         color: #111;
    }
     html.pm-light .accordion-card {
         background: #fff;
         border-color: #e5e7eb;
    }
     html.pm-light .school-header {
         background: #f9fafb;
         border-color: #e5e7eb;
         color: #111;
    }
     html.pm-light .accordion-sub-card {
         background: #fff;
         border-color: #e5e7eb;
    }
     html.pm-light .accordion-sub-header {
         color: #111;
    }
     html.pm-light .accordion-sub-header:hover {
         background: #f3f4f6;
    }
     html.pm-light .students-table th {
         background: #374151;
         color: #f9fafb;
         border-bottom-color: var(--c-red);
    }
     html.pm-light .students-table td {
         background: #fff;
         color: #222;
         border-bottom-color: #e5e7eb;
    }
     html.pm-light .students-table tbody tr:hover td {
         background: #f9fafb;
    }
     html.pm-light .students-table input:not([type=checkbox]), html.pm-light .students-table select {
         background: #f9fafb !important;
         border-color: #d1d5db !important;
         color: #111 !important;
    }
     html.pm-light .students-table select option {
         background: #fff !important;
         color: #111 !important;
    }
     html.pm-light .assign-checkbox-grid {
         background: #f9fafb;
         border-color: #e5e7eb;
    }
     html.pm-light .assign-checkbox-grid label {
         color: #333;
    }
     html.pm-light .assign-checkbox-grid label:hover {
         background: #f3f4f6;
         color: #111;
    }
     html.pm-light .tbl-toolbar {
         background: #f3f4f6;
         border-top-color: #e5e7eb;
         border-bottom-color: #e5e7eb;
    }
     .grp-save-btn {
         transition: opacity .2s;
    }
     .accordion-sub-card.has-changes .accordion-sub-header {
         border-bottom: 2px solid var(--c-red);
    }
     .btn-grp-discard {
         display:none;
         padding:5px 12px;
         background:transparent;
         border:1px solid var(--c-border-strong);
         color:var(--c-text-faint);
         font-size:0.78rem;
         border-radius:6px;
         cursor:pointer;
    }
     .accordion-sub-card.has-changes .btn-grp-discard {
         display:inline-flex;
    }
    @media (max-width: 600px) {
         .school-header { font-size:0.82rem; padding:10px 12px; }
         .accordion-card > div[style*='padding:12px'] { padding:8px !important; }
         .accordion-sub-card { margin-bottom:8px; }
         .pic-section-header { gap:8px; }
         .pic-section-header h2 { font-size:1.4rem; }
         .filter-grid { grid-template-columns:1fr; }
     }
</style>

<div class='pic-section-header'>
    <div>
        <h2>👥 Kumpulan Juri</h2>
        <div class='pic-section-sub'>Tetapkan juri kepada kumpulan pelajar mengikut peringkat</div>
    </div>
    <button type='button' class='pm-btn pm-btn-primary' onclick="toggleBlock('addGroup')">+ Tambah Kumpulan</button>
</div>

<!-- Filters (instant AJAX on change) -->
<div class='filter-card' style='margin-bottom:18px;'>
    <div class='filter-card-title'>Penapis Kumpulan</div>
    <div class='filter-grid'>
        <?php if ($show_siri_picker): ?>
        <div>
            <label class='filter-label'>Siri</label>
            <select id='f_siri' class='filter-select' onchange='onSiriFilterChange()'>
                <option value=''>Semua Siri</option>
                <?php
                $siris = $conn->query("SELECT siri_id, siri_name, siri_year FROM siri ORDER BY siri_year DESC, siri_name ASC");
                while ($si = $siris->fetch_assoc()) {
                    echo "<option value='{$si['siri_id']}'>" . htmlspecialchars($si['siri_name']) . " (" . htmlspecialchars($si['siri_year']) . ")</option>";
                }
                ?>
            </select>
        </div>
        <?php endif; ?>
        <div>
            <label class='filter-label'>Kumpulan</label>
            <select id='f_group' class='filter-select' onchange='ajaxFilter()'>
                <option value=''>Semua Kumpulan</option>
                <?php $grps = $conn->query("SELECT group_id, group_name FROM `groups` ORDER BY group_name"); while ($g=$grps->fetch_assoc()) echo "<option value='{$g['group_id']}'>" . htmlspecialchars($g['group_name']) . "</option>"; ?>
            </select>
        </div>
        <div>
            <label class='filter-label'>Sidang</label>
            <select id='f_session' class='filter-select' onchange='ajaxFilter()'>
                <option value=''>Semua Sidang</option>
                <?php
                $sessions = $conn->query("SELECT se.*, si.siri_name FROM sessions se LEFT JOIN siri si ON se.siri_id = si.siri_id ORDER BY se.session_name");
                while ($s=$sessions->fetch_assoc()) {
                    $siriLbl = $s['siri_name'] ? $s['siri_name'] : 'Tiada Siri';
                    echo "<option value='{$s['session_id']}' data-siri='{$s['siri_id']}'>" . htmlspecialchars($s['session_name']) . " — " . htmlspecialchars($siriLbl) . "</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label class='filter-label'>Peringkat</label>
            <select id='f_level' class='filter-select' onchange='ajaxFilter()'>
                <option value=''>Semua Peringkat</option>
                <?php $lvls = $conn->query("SELECT * FROM levels ORDER BY level_name"); while ($l=$lvls->fetch_assoc()) echo "<option value='{$l['level_id']}'>" . htmlspecialchars($l['level_name']) . "</option>"; ?>
            </select>
        </div>
    </div>
</div>

<!-- Add form -->
<div id='addGroup' class='pic-add-card'>
    <h3>+ Tambah Kumpulan Baru</h3>
    <form method='POST' class='pic-add-form'>
        <input type='hidden' name='action' value='add'>
        <div>
            <label style='display:block;font-size:0.75rem;color:var(--c-text-faint);margin-bottom:4px;text-transform:uppercase;font-weight:600;'>Sidang</label>
            <select name='session_id' required>
                <?php $sessions = $conn->query("SELECT * FROM sessions ORDER BY session_name"); while ($s=$sessions->fetch_assoc()) echo "<option value='{$s['session_id']}'>" . htmlspecialchars($s['session_name']) . "</option>"; ?>
            </select>
        </div>
        <div>
            <label style='display:block;font-size:0.75rem;color:var(--c-text-faint);margin-bottom:4px;text-transform:uppercase;font-weight:600;'>Peringkat</label>
            <select name='level_id' required>
                <?php $lvls = $conn->query("SELECT * FROM levels ORDER BY level_name"); while ($l=$lvls->fetch_assoc()) echo "<option value='{$l['level_id']}'>" . htmlspecialchars($l['level_name']) . "</option>"; ?>
            </select>
        </div>
        <div>
            <label style='display:block;font-size:0.75rem;color:var(--c-text-faint);margin-bottom:4px;text-transform:uppercase;font-weight:600;'>Nama Kumpulan</label>
            <input name='group_name' placeholder='Nama Kumpulan' required>
        </div>
        <div>
            <label style='display:block;font-size:0.75rem;color:var(--c-text-faint);margin-bottom:4px;text-transform:uppercase;font-weight:600;'>Juri</label>
            <select name='judge_id'>
                <option value=''>Pilih Juri (Pilihan)</option>
                <?php $judges = $conn->query("SELECT * FROM judges ORDER BY name"); while ($j=$judges->fetch_assoc()) echo "<option value='{$j['id']}'>" . htmlspecialchars($j['name']) . "</option>"; ?>
            </select>
        </div>
        <div>
            <label style='display:block;font-size:0.75rem;color:var(--c-text-faint);margin-bottom:4px;text-transform:uppercase;font-weight:600;'>&nbsp;</label>
            <div style='display:flex;gap:8px;'>
                <button class='pm-btn pm-btn-primary'>Tambah</button>
                <button type='button' class='pm-btn' style='background:transparent;border:1px solid var(--c-border-strong);color:var(--c-text-faint);' onclick="toggleBlock('addGroup')">Batal</button>
            </div>
        </div>
    </form>
</div>
<div id='groupList'><p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Memuatkan...</p></div>

<script>
function ajaxFilter() {
    const siriEl = document.getElementById('f_siri');
    const params = new URLSearchParams({
        ajax:'1',
        group_id:   document.getElementById('f_group').value,
        session_id: document.getElementById('f_session').value,
        level_id:   document.getElementById('f_level').value,
        siri_id:    siriEl ? siriEl.value : '',
    });
    const el = document.getElementById('groupList');
    el.style.opacity = '0.4';
    fetch('pic_groups.php?' + params)
        .then(r => r.text())
        .then(html => {
            el.innerHTML = html;
            el.style.opacity = '1';
            attachGroupListeners();
        });
}

// Selecting a Siri narrows the Sidang dropdown to that siri's sessions only,
// since session names can repeat across siri and would otherwise be ambiguous.
function onSiriFilterChange() {
    const siriId = document.getElementById('f_siri').value;
    const sessionSelect = document.getElementById('f_session');
    sessionSelect.querySelectorAll('option').forEach(opt => {
        if (!opt.value) { opt.style.display = ''; return; }
        opt.style.display = (!siriId || opt.dataset.siri === siriId) ? '' : 'none';
    });
    if (sessionSelect.selectedOptions[0]?.style.display === 'none') {
        sessionSelect.value = '';
    }
    ajaxFilter();
}

function attachGroupListeners() {
    document.querySelectorAll('#groupList input:not([type=hidden]), #groupList select').forEach(el => {
        if (el.dataset.glisten) return;
        el.dataset.glisten = '1';
        // store original value
        el.dataset.orig = el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value;
        el.addEventListener(el.type === 'checkbox' ? 'change' : 'input', onGroupChange);
        if (el.tagName === 'SELECT') el.addEventListener('change', onGroupChange);
    });
}

function onGroupChange(e) {
    const form = e.target.closest('form');
    if (!form) return;
    const card = document.getElementById('card_' + form.id.replace('form_', ''));
    if (!card) return;

    const inputs = form.querySelectorAll('input:not([type=hidden]), select');
    let dirty = false;
    inputs.forEach(el => {
        const cur = el.type === 'checkbox' ? (el.checked ? '1' : '0') : el.value;
        if (cur !== el.dataset.orig) dirty = true;
    });
    card.classList.toggle('has-changes', dirty);
}

function discardGroup(uid) {
    const form = document.getElementById('form_' + uid);
    const card = document.getElementById('card_' + uid);
    if (!form) return;
    form.querySelectorAll('input:not([type=hidden]), select').forEach(el => {
        if (el.dataset.orig === undefined) return;
        if (el.type === 'checkbox') {
            el.checked = el.dataset.orig === '1';
        } else {
            el.value = el.dataset.orig;
        }
    });
    if (card) card.classList.remove('has-changes');
}

function toggleBlock(id) {
    const el = document.getElementById(id);
    if (el) el.style.display = (el.style.display === 'none' || el.style.display === '') ? 'block' : 'none';
}

document.addEventListener('DOMContentLoaded', ajaxFilter);
</script>

</main>
</body>
</html>
