<?php
include 'db.php';

$new_plain_password = 'promarkah123';
$hashed_password = md5($new_plain_password);
$target_user = 'judge';

$stmt = $conn->prepare("UPDATE users SET password = ? WHERE username = ?");
$stmt->bind_param("ss", $hashed_password, $target_user);

if ($stmt->execute()) {
    echo "Success! The password has been hashed and updated.";
} else {
    echo "Error: " . $conn->error;
}
?>