<?php
include 'db.php';
session_start();

// ------------------------------
// ✅ Only allow judges to reset
// ------------------------------
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'judge') {
    header("Location: login.php");
    exit();
}

// ------------------------------
// ✅ Confirm reset request
// ------------------------------
if (!isset($_GET['confirm']) || $_GET['confirm'] !== 'yes') {
    header("Location: judge.php");
    exit();
}

// ------------------------------
// ✅ Function to safely add 'archived' column if missing
// ------------------------------
function addArchivedColumn($conn, $table) {
    $res = $conn->query("SHOW COLUMNS FROM `$table` LIKE 'archived'");
    if ($res && $res->num_rows === 0) {
        $conn->query("ALTER TABLE `$table` ADD COLUMN `archived` TINYINT(1) DEFAULT 0");
    }
}

// ------------------------------
// ✅ Tables to archive
// ------------------------------
$tables_to_archive = ['scores', 'marking_logs', 'summary'];

foreach ($tables_to_archive as $table) {
    // Check if table exists
    $result = $conn->query("SHOW TABLES LIKE '$table'");
    if ($result && $result->num_rows > 0) {
        addArchivedColumn($conn, $table);
        $conn->query("UPDATE `$table` SET archived=1 WHERE archived=0");
    }
}

// ------------------------------
// ✅ Reset judge assignments in groups
// ------------------------------
$conn->query("UPDATE groups SET judge_name=NULL");

// ------------------------------
// ✅ Set session flag for fresh start
// ------------------------------
$_SESSION['start_fresh'] = true;

// ------------------------------
// ✅ Redirect back to judge panel
// ------------------------------
header("Location: judge.php");
exit();
?>
