<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// -------------------------------------------------------------------
// FORCE HTTPS (before session cookie is set)
// -------------------------------------------------------------------
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {
    header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
    exit();
}

// -------------------------------------------------------------------
// SESSION HARDENING & IDLE TIMEOUT
// -------------------------------------------------------------------
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');
if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
    ini_set('session.cookie_secure', 1);
}
session_start();

// Idle timeout: 15 minutes
$idle_timeout = 900;
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $idle_timeout)) {
    session_unset();
    session_destroy();
    header('Location: login.php');
    exit();
}
$_SESSION['last_activity'] = time();

// -------------------------------------------------------------------
// SECURITY HEADERS
// -------------------------------------------------------------------
header("X-Frame-Options: DENY");
header("X-XSS-Protection: 1; mode=block");
header("X-Content-Type-Options: nosniff");
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");

// -------------------------------------------------------------------
// DATABASE
// -------------------------------------------------------------------
include 'db.php';
$conn = getDB();

// Ensure audit_log table exists — only needs to run once ever, not on every
// page view. Re-running "CREATE TABLE IF NOT EXISTS" on every request still
// costs a DB round-trip before the page can start sending bytes, which was
// adding to the document's time-to-first-byte.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn->query("CREATE TABLE IF NOT EXISTS audit_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        role VARCHAR(20) NOT NULL,
        ip VARCHAR(45) NOT NULL,
        login_time DATETIME NOT NULL
    )");
}

// -------------------------------------------------------------------
// CSRF TOKEN
// -------------------------------------------------------------------
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// -------------------------------------------------------------------
// TIME TRAP (prevent instant form submission)
// -------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['form_load_time'] = time();
}

// -------------------------------------------------------------------
// RATE LIMITING (session‑based, unchanged)
// -------------------------------------------------------------------
if (!isset($_SESSION['login_attempts'])) {
    $_SESSION['login_attempts'] = 0;
    $_SESSION['last_attempt_time'] = time();
}

if ($_SESSION['login_attempts'] >= 5) {
    if ((time() - $_SESSION['last_attempt_time']) < 300) {
        die("<!DOCTYPE html><html><body style='background:#111;color:#ff5252;display:flex;justify-content:center;align-items:center;height:100vh;text-align:center;'><div><h1>SECURITY LOCKDOWN</h1><p>Too many invalid login attempts. Wait 5 minutes.</p></div></body></html>");
    } else {
        $_SESSION['login_attempts'] = 0;
    }
}

$error = '';
$step = 1;

if (!empty($_SESSION['step']) && $_SESSION['step'] === 2) {
    $step = 2;
}

// -------------------------------------------------------------------
// FORM SUBMISSION HANDLING
// -------------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        $error = "Security token expired. Please refresh the page.";
    } else {
        // Honeypot
        if (!empty($_POST['website_url'])) {
            die("Success");
        }
        // Time trap
        if (isset($_SESSION['form_load_time']) && (time() - $_SESSION['form_load_time']) < 2) {
            die("Form submitted too quickly. Bot detected.");
        }

        $_SESSION['login_attempts']++;
        $_SESSION['last_attempt_time'] = time();

        // ---------- STEP 1: normal user login ----------
        if (isset($_POST['username'], $_POST['password']) && $step === 1) {
            $username = trim($_POST['username']);
            $password_input = trim($_POST['password']);

            $stmt = $conn->prepare("SELECT id, username, password, role FROM users WHERE username=? LIMIT 1");
            $stmt->bind_param("s", $username);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($password_input, $user['password'])) {
                    // success
                    $_SESSION['login_attempts'] = 0;
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['role'] = $user['role'];

                    // Audit log
                    $ip = $_SERVER['REMOTE_ADDR'];
                    $stmtAudit = $conn->prepare("INSERT INTO audit_log (user_id, role, ip, login_time) VALUES (?, ?, ?, NOW())");
                    $stmtAudit->bind_param("iss", $user['id'], $user['role'], $ip);
                    $stmtAudit->execute();
                    $stmtAudit->close();

                    if ($user['role'] === 'pic') {
                        header('Location: pic.php'); exit;
                    } elseif ($user['role'] === 'recorder') {
                        header('Location: attendance.php'); exit;
                    } elseif ($user['role'] === 'admin') {
                        header('Location: admin.php'); exit;
                    } elseif ($user['role'] === 'judge') {
                        $_SESSION['step'] = 2;
                        header('Location: login.php'); exit;
                    }
                } else {
                    $error = "Invalid username or password.";
                }
            } else {
                $error = "Invalid username or password.";
            }
            $stmt->close();

        // ---------- STEP 2: judge login (unified error message) ----------
        } elseif (isset($_POST['judge_id'], $_POST['pin']) && $step === 2) {
            $judge_id = (int)$_POST['judge_id'];
            $pin = trim($_POST['pin']);

            $stmt = $conn->prepare("SELECT id, pin_hash, name FROM judges WHERE id = ? LIMIT 1");
            $stmt->bind_param("i", $judge_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows === 1) {
                $judge = $result->fetch_assoc();
                if (password_verify($pin, $judge['pin_hash'])) {
                    // success
                    $_SESSION['login_attempts'] = 0;
                    session_regenerate_id(true);
                    $_SESSION['user_id'] = $judge['id'];
                    $_SESSION['role'] = 'judge';
                    $_SESSION['judge_name'] = $judge['name'];
                    unset($_SESSION['step']);

                    // Audit log
                    $ip = $_SERVER['REMOTE_ADDR'];
                    $stmtAudit = $conn->prepare("INSERT INTO audit_log (user_id, role, ip, login_time) VALUES (?, 'judge', ?, NOW())");
                    $stmtAudit->bind_param("is", $judge['id'], $ip);
                    $stmtAudit->execute();
                    $stmtAudit->close();

                    header('Location: judge.php');
                    exit;
                } else {
                    // Unified error message – same for invalid PIN or wrong judge
                    $error = "Invalid credentials.";
                }
            } else {
                $error = "Invalid credentials.";
            }
            $stmt->close();
        }
    }
}

// -------------------------------------------------------------------
// Fetch judges list for step 2 (only if needed)
// -------------------------------------------------------------------
$judges_list = [];
if ($step === 2) {
    $j_res = $conn->query("SELECT id, name FROM judges ORDER BY name ASC");
    if ($j_res) {
        while ($r = $j_res->fetch_assoc()) {
            $judges_list[] = $r;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProMarkah | Secure Access</title>

    <!-- SEO: private login portal — keep it out of search results, but still
         give link-preview crawlers (WhatsApp/Telegram/etc.) something useful -->
    <meta name="robots" content="noindex, nofollow">
    <meta name="description" content="ProMarkah — sistem pengurusan dan penilaian markah silat. Log masuk untuk meneruskan.">
    <meta property="og:title" content="ProMarkah">
    <meta property="og:description" content="Sistem pengurusan dan penilaian markah silat.">
    <meta property="og:type" content="website">
    <meta property="og:image" content="img/logo_silat_1.png">

    <!-- Browser tab icon -->
    <link rel="icon" type="image/png" href="img/logo_silat_1.png">
    <link rel="apple-touch-icon" href="img/logo_silat_1.png">

    <!--
    ===================================================================
    PERFORMANCE: Non‑blocking Google Fonts
    - Preload the stylesheet, then apply on load (no render blocking)
    ===================================================================
    -->
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;700;900&display=swap" onload="this.onload=null;this.rel='stylesheet'">
    <noscript>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;700;900&display=swap">
    </noscript>

    <!-- Preconnect for faster font origin connection -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <!--
    ===================================================================
    PERFORMANCE: Preload only the desktop hero image (LCP)
    - media="(min-width: 1024px)" ensures mobile devices do NOT preload the large image
    ===================================================================
    -->
    <link rel="preload" as="image" href="img/promarkah.webp" type="image/webp" media="(min-width: 1024px)">

    <!-- Optimised Tailwind CSS (purged) -->
    <link rel="stylesheet" href="output.css?v=2">

    <style>
        @keyframes fadeIn { from { opacity: 0; transform: scale(1.02); } to { opacity: 1; transform: scale(1); } }
        @keyframes fadeSlide { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
        .visually-hidden {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }
    </style>
</head>
<body class="bg-[#111] min-h-screen overflow-hidden font-sans text-gray-800">

    <div class="flex min-h-screen w-full">

        <!--
        ===================================================================
        PERFORMANCE: Responsive Hero Image
        - Serves mobile-optimised WebP/PNG on screens ≤768px
        - Falls back gracefully if mobile variants are missing
        ===================================================================
        -->
        <div class="hidden lg:block lg:w-[55%] relative overflow-hidden animate-[fadeIn_0.8s_ease-out] bg-black">
            <picture>
                <!-- Mobile (≤768px) -->
                <source media="(max-width: 768px)" srcset="img/promarkah-mobile.webp" type="image/webp">
                <source media="(max-width: 768px)" srcset="img/promarkah-mobile.png" type="image/png">
                <!-- Desktop (default) -->
                <source srcset="img/promarkah.webp" type="image/webp">
                <img src="img/promarkah.png"
                     alt="ProMarkah Poster"
                     width="1080"
                     height="1440"
                     fetchpriority="high"
                     decoding="async"
                     class="absolute inset-0 w-full h-full object-cover object-center shadow-[10px_0_30px_rgba(0,0,0,0.8)] z-10">
            </picture>
        </div>

        <div class="w-full lg:w-[45%] flex flex-col justify-center items-center relative px-6 py-12 z-20 bg-gray-50 shadow-[-15px_0_40px_rgba(0,0,0,0.5)] border-l border-gray-200">

            <div class="w-full max-w-[400px] z-10 animate-[fadeSlide_0.5s_ease-out]">

                <div class="text-center mb-10 flex flex-col items-center">
                    <div class="bg-[#111] p-4 rounded-2xl mb-6 shadow-[0_8px_20px_rgba(0,0,0,0.3)] hover:scale-105 transition-transform duration-300 border border-gray-800">
                        <picture>
                            <source srcset="img/logo_silat_1.webp" type="image/webp">
                            <img src="img/logo_silat_1.png"
                                 alt="ProMarkah Logo"
                                 width="64"
                                 height="64"
                                 fetchpriority="high"
                                 decoding="async"
                                 class="h-16 w-auto">
                        </picture>
                    </div>
                    <p class="text-2xl font-normal text-gray-500 tracking-widest mb-1" dir="rtl">ڤروسيلت</p>
                    <h1 class="text-2xl font-bold text-gray-800 uppercase tracking-widest mb-1">PROSILAT</h1>
                    <h2 class="text-3xl text-gray-900 font-black uppercase tracking-widest mb-2 pb-2">PROMARKAH</h2>
                </div>

                <?php if ($error): ?>
                    <div class="bg-red-50 border border-red-200 text-red-600 text-sm font-medium px-4 py-3 rounded-lg mb-8 text-center shadow-sm">
                        <?= htmlspecialchars($error) ?>
                    </div>
                <?php endif; ?>

                <?php if ($step === 1): ?>
                    <form method="POST" class="space-y-5">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                        <div class="visually-hidden" aria-hidden="true">
                            <label for="website_url">Leave this field blank if you are human</label>
                            <input type="text" id="website_url" name="website_url" tabindex="-1" autocomplete="off">
                        </div>

                        <div class="relative">
                            <input type="text" id="username" name="username"
                                class="block px-4 pb-2.5 pt-6 w-full text-sm text-gray-900 bg-white rounded-xl border border-gray-300 appearance-none focus:outline-none focus:border-pmRed focus:ring-1 focus:ring-pmRed peer transition-all shadow-sm"
                                placeholder=" " required autocomplete="off">
                            <label for="username"
                                class="absolute text-sm text-gray-500 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-focus:text-pmRed peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3 select-none pointer-events-none">
                                Username
                            </label>
                        </div>

                        <div class="relative">
                            <input type="password" id="password" name="password"
                                class="block px-4 pr-12 pb-2.5 pt-6 w-full text-sm text-gray-900 bg-white rounded-xl border border-gray-300 appearance-none focus:outline-none focus:border-pmRed focus:ring-1 focus:ring-pmRed peer transition-all shadow-sm"
                                placeholder=" " required>
                            <label for="password"
                                class="absolute text-sm text-gray-500 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-focus:text-pmRed peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3 select-none pointer-events-none">
                                Password
                            </label>
                            <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 flex items-center pr-4 text-gray-400 hover:text-pmRed focus:outline-none transition-colors">
                                <svg id="eyeIcon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                    <circle cx="12" cy="12" r="3"></circle>
                                </svg>
                            </button>
                        </div>

                        <button type="submit"
                            class="w-full bg-pmRed hover:bg-[#B01F1F] active:scale-[0.98] text-white font-bold py-3.5 px-4 rounded-xl transition-all duration-200 mt-8 tracking-widest shadow-[0_4px_15px_rgba(214,40,40,0.25)] hover:shadow-[0_6px_20px_rgba(214,40,40,0.4)] border border-transparent uppercase text-sm">
                            LOG MASUK SELAMAT
                        </button>
                    </form>

                <?php elseif ($step === 2): ?>
                    <div class="text-center mb-6">
                        <p class="text-sm text-gray-600 font-medium">Selamat datang, Juri. Sila pilih nama anda dan masukkan PIN.</p>
                    </div>
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">

                        <div class="relative">
                            <select id="judge_id" name="judge_id" required
                                class="block px-4 pb-2.5 pt-6 w-full text-sm text-gray-900 bg-white rounded-xl border border-gray-300 appearance-none focus:outline-none focus:border-pmRed focus:ring-1 focus:ring-pmRed peer transition-all shadow-sm">
                                <option value="" disabled selected></option>
                                <?php foreach ($judges_list as $j): ?>
                                    <option value="<?= $j['id'] ?>"><?= htmlspecialchars($j['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <label for="judge_id"
                                class="absolute text-sm text-gray-500 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-focus:text-pmRed peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3 select-none pointer-events-none">
                                Pilih Nama Anda
                            </label>
                            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-gray-500">
                                <svg class="fill-current h-4 w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M9.293 12.95l.707.707L15.657 8l-1.414-1.414L10 10.828 5.757 6.586 4.343 8z"/></svg>
                            </div>
                        </div>

                        <div class="relative">
                            <input type="password" id="pin" name="pin"
                                class="block px-4 pr-12 pb-2.5 pt-6 w-full text-center tracking-[0.5em] text-2xl text-gray-900 bg-white rounded-xl border border-gray-300 appearance-none focus:outline-none focus:border-pmRed focus:ring-1 focus:ring-pmRed peer transition-all shadow-sm"
                                placeholder=" " required autofocus>
                            <label for="pin"
                                class="absolute text-sm text-gray-500 duration-300 transform -translate-y-3 scale-75 top-4 z-10 origin-[0] left-4 peer-focus:text-pmRed peer-placeholder-shown:scale-100 peer-placeholder-shown:translate-y-0 peer-focus:scale-75 peer-focus:-translate-y-3 select-none pointer-events-none">
                                PIN KESELAMATAN
                            </label>
                            <button type="button" id="togglePin" class="absolute inset-y-0 right-0 flex items-center pr-4 text-gray-400 hover:text-pmRed focus:outline-none transition-colors">
                                <svg id="eyeIconPin" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                    <circle cx="12" cy="12" r="3"></circle>
                                </svg>
                            </button>
                        </div>

                        <button type="submit"
                            class="w-full bg-pmRed hover:bg-[#B01F1F] active:scale-[0.98] text-white font-bold py-3.5 px-4 rounded-xl transition-all duration-200 mt-6 tracking-widest shadow-[0_4px_15px_rgba(214,40,40,0.25)] hover:shadow-[0_6px_20px_rgba(214,40,40,0.4)] border border-transparent uppercase text-sm">
                            SAHKAN PIN
                        </button>

                        <div class="text-center mt-6">
                            <a href="logout.php" class="text-xs text-gray-500 hover:text-gray-800 transition-colors border-b border-transparent hover:border-gray-800 pb-0.5 font-medium">Batal & Kembali</a>
                        </div>
                    </form>
                <?php endif; ?>

                <div class="mt-12 text-center">
                    <div class="text-[11px] text-gray-400 font-medium uppercase tracking-widest">
                        &copy; <?= date('Y') ?> ProMarkah • Encrypted Connection
                    </div>
                </div>

            </div>
        </div>

    </div>

    <script>
        function setupPasswordToggle(toggleBtnId, inputId, iconId) {
            const toggleBtn = document.getElementById(toggleBtnId);
            if (!toggleBtn) return;
            toggleBtn.addEventListener('click', function () {
                const input = document.getElementById(inputId);
                const icon = document.getElementById(iconId);
                if (input.type === 'password') {
                    input.type = 'text';
                    icon.innerHTML = '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line>';
                } else {
                    input.type = 'password';
                    icon.innerHTML = '<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle>';
                }
            });
        }
        setupPasswordToggle('togglePassword', 'password', 'eyeIcon');
        setupPasswordToggle('togglePin', 'pin', 'eyeIconPin');
    </script>
</body>
</html>