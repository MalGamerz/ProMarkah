<?php
// import_students.php

$skipped_rows = []; // to store skipped rows info
$csv = __DIR__ . '/file/senaraipesilatsiri3.csv';

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$mysqli = new mysqli('localhost', 'root', '', 'promarkah');
$mysqli->set_charset('utf8mb4');

if (!file_exists($csv)) {
    die("CSV not found: $csv");
}

// ---------------- HELPERS ----------------
function detect_delimiter(string $file): string {
    $candidates = [",",";","\t","|"];
    $scores = array_fill_keys($candidates, 0);

    $h = fopen($file, 'r');
    if (!$h) return ',';

    $lines = 0;
    while (($line = fgets($h)) !== false && $lines < 10) {
        $trim = trim($line);
        if ($trim === '') continue;
        foreach ($candidates as $d) { $scores[$d] += substr_count($trim, $d); }
        $lines++;
    }
    fclose($h);
    arsort($scores);
    $best = array_key_first($scores);
    return $best ?: ',';
}

function norm_header(string $s): string {
    $s = str_replace(["\xEF\xBB\xBF", "\xC2\xA0"], '', $s);
    $s = preg_replace('/[\'"`\.]/','',$s);
    $s = trim(mb_strtolower($s));
    $s = preg_replace('/\s+/', '_', $s);
    $s = preg_replace('/[^a-z0-9_]/', '_', $s);
    $s = preg_replace('/_+/', '_', $s);
    return $s;
}

function normalize_name(string $raw): string {
    $s = trim(str_replace(["\xEF\xBB\xBF", "\xC2\xA0"], '', $raw));
    $s = preg_replace('/["\']/', '', $s);
    $s = preg_replace('/\s+/', ' ', $s);
    return mb_convert_case($s, MB_CASE_TITLE);
}
// ---------------- /HELPERS ----------------

$delim = detect_delimiter($csv);
$debug = isset($_GET['debug']);

// Prepare insert statement (without date)
$stmt = $mysqli->prepare("
  INSERT INTO students (student_name, level_id, school_id, gender)
  VALUES (?,?,?,?)
");

$inserted = 0;
$skipped  = 0;
$line     = 0;

$mysqli->begin_transaction();

if (($h = fopen($csv, 'r')) !== false) {
    // Read header
    $header = fgetcsv($h, 0, $delim);
    $line = 1;
    if ($header === false) die('Empty CSV');

    // Map header
    $map = [];
    foreach ($header as $i => $col) {
        $map[norm_header($col)] = $i;
    }

    // Required columns (no date)
    $need = [
        'student_name' => ['student_name','name','student name'],
        'level_id'     => ['level_id','level id'],
        'school_id'    => ['school_id','school id'],
        'gender'       => ['gender','jantina'],
    ];

    $idx = [];
    foreach ($need as $key => $aliases) {
        $found = null;
        foreach ($aliases as $a) {
            $a_norm = norm_header($a);
            if (isset($map[$a_norm])) { $found = $map[$a_norm]; break; }
        }
        if ($found === null) {
            fclose($h);
            $mysqli->rollback();
            die("Missing required column in CSV header: $key");
        }
        $idx[$key] = $found;
    }

    if ($debug) {
        echo "<pre>Detected delimiter: $delim\nHeader map:\n"; print_r($map); echo "</pre>";
    }

    // Read rows
    while (($row = fgetcsv($h, 0, $delim)) !== false) {
        $line++;

        $student_name = normalize_name($row[$idx['student_name']] ?? '');
        $level_id     = intval($row[$idx['level_id']] ?? 0);
        $school_id    = intval($row[$idx['school_id']] ?? 0);
        $gender       = trim($row[$idx['gender']] ?? 'Male');

        // Skip empty name
        if ($student_name === '') {
            $skipped_rows[] = [
                'line' => $line,
                'student_name' => $student_name,
                'reason' => 'Student name empty'
            ];
            $skipped++;
            continue;
        }

        $stmt->bind_param("siis", $student_name, $level_id, $school_id, $gender);
        $stmt->execute();
        $inserted++;

        if ($debug && $inserted <= 5) {
            echo "<pre style='color:#8f8'>Inserted line $line: $student_name</pre>";
        }
    }

    fclose($h);
}

$mysqli->commit();
$stmt->close();
$mysqli->close();

// Display skipped rows
if (!empty($skipped_rows)) {
    echo "<h3>Skipped Rows</h3><table border='1' cellpadding='5'>
            <tr><th>Line</th><th>Name</th><th>Age</th><th>Reason</th></tr>";
    foreach ($skipped_rows as $r) {
        echo "<tr><td>{$r['line']}</td><td>{$r['student_name']}</td><td>{$r['age']}</td><td>{$r['reason']}</td></tr>";
    }
    echo "</table>";
}

echo "<br>Done. Inserted: $inserted, Skipped: $skipped";
?>
