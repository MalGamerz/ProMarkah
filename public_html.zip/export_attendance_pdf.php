<?php
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
ini_set('session.cookie_samesite', 'Strict');
session_start();

include 'db.php';
$conn = getDB();

// Use $_GET because the link from attendance.php is a GET request
$sidang_id = isset($_GET['sidang_id']) ? intval($_GET['sidang_id']) : 0;

// Fetch attendance data
// FIXED: Changed st.age to st.year. 
// FIXED: Joined sessions directly via the attendance table (a.session_id) to avoid duplicates.
$query = "
    SELECT 
        se.session_name,
        sc.school_name,
        st.student_name,
        st.year,
        a.status,
        a.timestamp
    FROM attendance a
    JOIN students st ON a.student_id = st.student_id
    LEFT JOIN schools sc ON st.school_id = sc.school_id
    JOIN sessions se ON a.session_id = se.session_id
";

if ($sidang_id > 0) {
    $query .= " WHERE se.session_id = $sidang_id ";
}
$query .= " ORDER BY se.session_name ASC, sc.school_name ASC, st.student_name ASC";

$result = $conn->query($query);
?>
<!DOCTYPE html>
<html lang="ms">
<head>
    <meta charset="UTF-8">
    <title>Laporan Kehadiran</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            color: #333;
            margin: 20px;
        }
        .header-title {
            text-align: center;
            margin-bottom: 20px;
        }
        .header-title h2 {
            margin: 0 0 5px 0;
            color: #b30000;
        }
        .header-title p {
            margin: 0;
            font-size: 0.9rem;
            color: #666;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px 10px;
            text-align: left;
        }
        th {
            background-color: #b30000;
            color: #ffffff;
            text-transform: uppercase;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .status-hadir {
            color: #059669;
            font-weight: bold;
        }
        /* Hide buttons when printing */
        @media print {
            .no-print { display: none !important; }
            body { margin: 0; }
        }
        .controls {
            margin-bottom: 20px;
            text-align: right;
        }
        .btn {
            padding: 8px 16px;
            background: #b30000;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
            font-size: 0.9rem;
        }
        .btn-back {
            background: #666;
            margin-right: 10px;
        }
    </style>
</head>
<body>

    <div class="controls no-print">
        <button class="btn btn-back" onclick="window.close()">Tutup Maklumat</button>
        <button class="btn" onclick="window.print()">🖨️ Cetak / Simpan sebagai PDF</button>
    </div>

    <div class="header-title">
        <h2>Laporan Penuh Kehadiran Pesilat</h2>
        <p>Tarikh Dijana: <?= date('d/m/Y H:i:s') ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th style="width: 5%;">Bil</th>
                <th style="width: 15%;">Sidang</th>
                <th style="width: 20%;">Cawangan</th>
                <th style="width: 30%;">Nama Pesilat</th>
                <th style="width: 10%;">Tahun</th>
                <th style="width: 10%;">Status</th>
                <th style="width: 10%;">Tarikh / Masa</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            if ($result && $result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    $date = date('d/m/Y H:i', strtotime($row['timestamp']));
                    $status = $row['status'] === 'Present' ? '<span class="status-hadir">Hadir</span>' : 'Tidak Hadir';
                    
                    echo "<tr>
                            <td>{$no}</td>
                            <td>" . htmlspecialchars($row['session_name']) . "</td>
                            <td>" . htmlspecialchars($row['school_name'] ?? 'Tiada') . "</td>
                            <td>" . htmlspecialchars($row['student_name']) . "</td>
                            <td>" . htmlspecialchars($row['year'] ?? '-') . "</td>
                            <td>{$status}</td>
                            <td>{$date}</td>
                          </tr>";
                    $no++;
                }
            } else {
                echo "<tr><td colspan='7' style='text-align:center; padding: 20px;'>Tiada rekod kehadiran dijumpai.</td></tr>";
            }
            ?>
        </tbody>
    </table>

    <script>
        window.onload = function() {
            setTimeout(function() {
                window.print();
            }, 500);
        };
    </script>

</body>
</html>