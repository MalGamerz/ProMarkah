<?php
// ══════════════════════════════════════════════════════════════════
//  attendance_helpers.php — Shared helpers for attendance pages
// ══════════════════════════════════════════════════════════════════

define('QR_SECRET_KEY', 'promarkah_secure_qr_2026');
define('QR_TTL_SECONDS', 2 * 3600); // 2 hours

// ── Generate a signed QR URL ─────────────────────────────────────
function makeQrUrl(int $school_id, int $session_id): string {
    $exp = time() + QR_TTL_SECONDS;
    $sig = hash_hmac('sha256', "$school_id-$session_id-$exp", QR_SECRET_KEY);
    $base = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
          . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['PHP_SELF'];
    return "$base?mode=student&school_id=$school_id&session_id=$session_id&exp=$exp&sig=$sig";
}

// ── Verify a signed QR token ─────────────────────────────────────
function verifyQrToken(int $school_id, int $session_id, int $exp, string $sig): bool {
    if (time() > $exp) return false;
    $expected = hash_hmac('sha256', "$school_id-$session_id-$exp", QR_SECRET_KEY);
    return hash_equals($expected, $sig);
}

// ── Render an expired/invalid QR page and exit ───────────────────
function renderExpiredPage(): never {
    http_response_code(403);
    echo <<<HTML
    <!DOCTYPE html>
    <html lang="ms">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pautan Tamat Tempoh</title>
    </head>
    <body style="background:#f3f4f6;color:#111827;display:flex;flex-direction:column;
                 justify-content:center;align-items:center;height:100vh;text-align:center;
                 font-family:sans-serif;padding:20px;">
        <div style="font-size:4rem;margin-bottom:10px;">⏱️</div>
        <h1 style="color:#b30000;margin-bottom:10px;">Pautan Tamat Tempoh</h1>
        <p style="color:#6b7280;line-height:1.5;">
            Kod QR ini telah tamat tempoh atau tidak sah.<br>
            Sila minta kod QR baharu daripada urusetia bertugas.
        </p>
    </body>
    </html>
    HTML;
    exit;
}

// ── Fetch session name by ID ──────────────────────────────────────
function getSessionName(mysqli $conn, int $session_id): string {
    $stmt = $conn->prepare("SELECT session_name FROM sessions WHERE session_id = ? LIMIT 1");
    $stmt->bind_param("i", $session_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['session_name'] ?? 'Sidang';
}

// ── Fetch the siri name a session belongs to, by session ID ───────
function getSessionSiriName(mysqli $conn, int $session_id): string {
    $stmt = $conn->prepare("
        SELECT si.siri_name FROM sessions se
        LEFT JOIN siri si ON se.siri_id = si.siri_id
        WHERE se.session_id = ? LIMIT 1
    ");
    $stmt->bind_param("i", $session_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['siri_name'] ?? '';
}

// ── Fetch school name by ID ───────────────────────────────────────
function getSchoolName(mysqli $conn, int $school_id): string {
    $stmt = $conn->prepare("SELECT school_name FROM schools WHERE school_id = ? LIMIT 1");
    $stmt->bind_param("i", $school_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['school_name'] ?? 'Cawangan';
}

// ── Fetch schools linked to a session ────────────────────────────
function getSessionSchools(mysqli $conn, int $session_id): array {
    $stmt = $conn->prepare("
        SELECT s.school_id, s.school_name,
               (SELECT COUNT(*) FROM students st WHERE st.school_id = s.school_id) AS total_students,
               (SELECT COUNT(DISTINCT a.student_id)
                FROM attendance a
                JOIN students st ON a.student_id = st.student_id
                WHERE st.school_id = s.school_id AND a.status = 'Present') AS present_students
        FROM schools s
        JOIN session_schools ss ON s.school_id = ss.school_id
        WHERE ss.session_id = ?
        ORDER BY s.school_name ASC
    ");
    $stmt->bind_param("i", $session_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// ── Fetch students for a specific school, with attendance status ──
function getStudentsForSchool(mysqli $conn, int $session_id, int $school_id): array {
    $stmt = $conn->prepare("
        SELECT st.student_id, st.student_name, st.gender,
               (SELECT status FROM attendance
                WHERE student_id = st.student_id AND session_id = ? AND status = 'Present'
                LIMIT 1) AS is_present
        FROM students st
        WHERE st.school_id = ?
        ORDER BY st.student_name ASC
    ");
    $stmt->bind_param("ii", $session_id, $school_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
}

// ── Fetch all students grouped by school (global QR) ─────────────
function getAllStudentsBySchool(mysqli $conn, int $session_id): array {
    $stmt = $conn->prepare("
        SELECT st.student_id, st.student_name, st.school_id,
               (SELECT status FROM attendance
                WHERE student_id = st.student_id AND session_id = ? AND status = 'Present'
                LIMIT 1) AS is_present
        FROM students st
        JOIN session_schools ss ON st.school_id = ss.school_id
        WHERE ss.session_id = ?
        ORDER BY st.student_name ASC
    ");
    $stmt->bind_param("ii", $session_id, $session_id);
    $stmt->execute();

    $grouped = [];
    $result  = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $grouped[(int)$row['school_id']][] = $row;
    }
    return $grouped;
}
