<?php
session_start();
include 'db.php';
$conn = getDB();

// Ensure only PIC can access
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pic') {
    header("Location: login.php");
    exit();
}

$pm_page = 'manual_marks';
include 'layout.php';
?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

<style>
/* ── SELECT2 NATIVE THEME (Adapts to Light/Dark Mode) ── */
.select2-container .select2-selection--single {
    background: var(--c-surface-2) !important;
    border: 1px solid var(--c-border-strong) !important;
    border-radius: var(--radius-sm) !important;
    height: 42px !important;
}
.select2-container--default .select2-selection--single .select2-selection__rendered {
    color: var(--c-text) !important;
    line-height: 40px !important;
    padding-left: 12px !important;
}
.select2-container--default .select2-selection--single .select2-selection__arrow {
    height: 40px !important;
}
.select2-dropdown {
    background: var(--c-surface-1) !important;
    border: 1px solid var(--c-border-strong) !important;
}
.select2-results__option {
    color: var(--c-text) !important;
}
.select2-results__option--highlighted {
    background: var(--c-red) !important; 
    color: #fff !important;
}
.select2-search__field {
    background: var(--c-surface-2) !important;
    color: var(--c-text) !important; 
    border: 1px solid var(--c-border-strong) !important;
    padding: 6px !important;
    outline: none !important;
    border-radius: var(--radius-sm) !important;
}
.select2-search__field:focus {
    border-color: var(--c-red) !important;
}

/* ── LAYOUT TWEAKS ── */
.pic-section-header {
    margin-bottom: 24px;
}
.pic-section-header h2 {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 1.8rem;
    color: var(--c-text);
    letter-spacing: 0.05em;
    margin: 0;
    text-transform: uppercase;
    display: flex;
    align-items: center;
    gap: 8px;
}
.pic-section-sub {
    color: var(--c-text-faint);
    font-size: 0.85rem;
    margin-top: 4px;
    max-width: 600px;
}

.context-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
}

.criteria-row {
    display: grid;
    grid-template-columns: 1fr 120px 48px;
    gap: 12px;
    align-items: center;
    margin-bottom: 12px;
}

/* ── CUSTOM BUTTONS ── */
.btn-outline {
    background: transparent;
    border: 1px solid var(--c-border-strong);
    color: var(--c-text);
    padding: 6px 12px;
    border-radius: var(--radius-sm);
    cursor: pointer;
    font-size: 0.8rem;
    font-weight: 500;
    transition: all 0.2s;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    text-decoration: none;
}
.btn-outline:hover {
    background: var(--c-surface-2);
    border-color: var(--c-text-muted);
}

.btn-delete-row {
    background: transparent;
    border: 1px solid #fca5a5; /* Soft red border */
    color: var(--c-red);
    height: 42px;
    width: 100%;
    border-radius: var(--radius-sm);
    cursor: pointer;
    font-size: 1.1rem;
    transition: all 0.2s;
    display: flex;
    align-items: center;
    justify-content: center;
}
.btn-delete-row:hover {
    background: var(--c-red);
    color: #fff;
    border-color: var(--c-red);
}

.btn-add-row {
    background: transparent;
    border: 1px solid var(--c-border-strong);
    color: var(--c-text-muted);
    width: 100%;
    padding: 10px;
    border-radius: var(--radius-sm);
    cursor: pointer;
    font-size: 0.85rem;
    font-weight: 600;
    transition: all 0.2s;
    margin-top: 8px;
}
.btn-add-row:hover {
    background: var(--c-surface-2);
    color: var(--c-text);
}

@media (max-width: 600px) {
    .criteria-row {
        grid-template-columns: 1fr 90px 42px;
    }
}
</style>

<div class="pic-section-header">
    <h2>✍️ Isi Markah Manual</h2>
    <div class="pic-section-sub">
        Tetapkan parameter dan pastikan markah yang dimasukkan tepat sebelum simpan.
    </div>
</div>

<?php if (isset($_GET['msg'])): ?>
<div class="pm-alert pm-alert-success">
    ✅ <?= htmlspecialchars($_GET['msg']) ?>
</div>
<?php endif; ?>

<div class="pm-card">
    <div style="margin-bottom: 20px;">
        <h3 style="margin: 0; font-size: 1.1rem; font-weight: 500;">Pilih Parameter</h3>
    </div>

    <?php
    if (!empty($_POST['group_id']) && empty($_POST['level_id'])) {
        $gid = (int)$_POST['group_id'];
        $gRes = $conn->query("SELECT level_id FROM `groups` WHERE group_id=$gid");
        if ($gRes && $gRes->num_rows > 0) $_POST['level_id'] = $gRes->fetch_assoc()['level_id'];
    }
    ?>

    <form method="POST" class="context-grid">
        <div>
            <label style="font-size:0.75rem; color: var(--c-text-faint); margin-bottom:6px; display:block;">Kumpulan</label>
            <select name="group_id" class="select-search" onchange="this.form.submit()" required>
                <option value="">Pilih kumpulan...</option>
                <?php
                $active_siri = (int)($_SESSION['active_siri_id'] ?? 0);
                $groups = $active_siri > 0
                    ? $conn->query("SELECT group_id, group_name FROM `groups` WHERE session_id IN (SELECT session_id FROM sessions WHERE siri_id = $active_siri) ORDER BY group_name")
                    : $conn->query("SELECT group_id, group_name FROM `groups` ORDER BY group_name");
                while ($g = $groups->fetch_assoc()):
                ?>
                <option value="<?= $g['group_id'] ?>" <?=($_POST['group_id']??'')==$g['group_id']?'selected':''?>>
                    <?= htmlspecialchars($g['group_name']) ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div>
            <label style="font-size:0.75rem; color: var(--c-text-faint); margin-bottom:6px; display:block;">Peringkat</label>
            <select name="level_id" class="select-search" onchange="this.form.submit()" required>
                <option value="">Pilih peringkat...</option>
                <?php
                $levels = $active_siri > 0
                    ? $conn->query("SELECT level_id, level_name FROM levels WHERE session_id IN (SELECT session_id FROM sessions WHERE siri_id = $active_siri) ORDER BY level_name")
                    : $conn->query("SELECT level_id, level_name FROM levels ORDER BY level_name");
                while ($l = $levels->fetch_assoc()):
                ?>
                <option value="<?= $l['level_id'] ?>" <?=($_POST['level_id']??'')==$l['level_id']?'selected':''?>>
                    <?= htmlspecialchars($l['level_name']) ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div>
            <label style="font-size:0.75rem; color: var(--c-text-faint); margin-bottom:6px; display:block;">Pelajar</label>
            <select name="student_id" class="select-search" onchange="this.form.submit()" <?= empty($_POST['group_id'])?'disabled':'' ?> required>
                <option value="">Pilih pelajar...</option>
                <?php if (!empty($_POST['group_id'])):
                $gid=(int)$_POST['group_id'];
                $students=$conn->query("
                    SELECT st.student_id, st.student_name, lv.level_name
                    FROM group_students gs
                    JOIN students st ON gs.student_id=st.student_id
                    JOIN levels lv ON st.level_id=lv.level_id
                    WHERE gs.group_id=$gid
                    ORDER BY st.student_name
                ");
                while($s=$students->fetch_assoc()): ?>
                <option value="<?= $s['student_id'] ?>" <?=($_POST['student_id']??'')==$s['student_id']?'selected':''?>>
                    <?= htmlspecialchars($s['student_name']) ?>
                </option>
                <?php endwhile; endif; ?>
            </select>
        </div>

        <div>
            <label style="font-size:0.75rem; color: var(--c-text-faint); margin-bottom:6px; display:block;">Ujian</label>
            <select name="test_id" class="select-search" onchange="this.form.submit()" <?= empty($_POST['level_id'])?'disabled':'' ?> required>
                <option value="">Pilih ujian...</option>
                <?php if (!empty($_POST['level_id'])):
                $lid=(int)$_POST['level_id'];
                $tests=$conn->query("SELECT test_id,test_name FROM tests WHERE level_id=$lid ORDER BY test_name");
                while($t=$tests->fetch_assoc()):
                ?>
                <option value="<?= $t['test_id'] ?>" <?=($_POST['test_id']??'')==$t['test_id']?'selected':''?>>
                    <?= htmlspecialchars($t['test_name']) ?>
                </option>
                <?php endwhile; endif; ?>
            </select>
        </div>
    </form>
</div>

<?php if (!empty($_POST['group_id']) && !empty($_POST['student_id']) && !empty($_POST['test_id'])): ?>

<form action="pic_save_scores.php" method="POST">
    <input type="hidden" name="group_id" value="<?= $_POST['group_id'] ?>">
    <input type="hidden" name="student_id" value="<?= $_POST['student_id'] ?>">
    <input type="hidden" name="test_id" value="<?= $_POST['test_id'] ?>">

    <div class="pm-card">
        <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; flex-wrap: wrap; gap: 12px;">
            <h3 style="margin: 0; font-size: 1.1rem; font-weight: 500;">Masukkan Markah</h3>
            <div style="display: flex; gap: 8px;">
                <a href="pic.php?section=tests" class="btn-outline">+ Ujian Baru</a>
                <a href="pic.php?section=criteria" class="btn-outline">+ Kriteria Baru</a>
            </div>
        </div>

        <div id="criteriaContainer">
            <?php
            $tid = (int)$_POST['test_id'];
            $criteria=$conn->query("SELECT c.criteria_id,c.criteria_name,t.test_name FROM criteria c LEFT JOIN tests t ON c.test_id=t.test_id WHERE c.test_id = $tid ORDER BY c.criteria_name");
            ?>

            <div class="criteria-row">
                <select name="criteria_id[]" class="select-search" required>
                    <option value="">Taip untuk cari...</option>
                    <?php while($c=$criteria->fetch_assoc()): ?>
                    <option value="<?= $c['criteria_id'] ?>">
                        <?= htmlspecialchars($c['criteria_name']) ?>
                    </option>
                    <?php endwhile; ?>
                </select>

                <input type="number" name="mark[]" class="pm-input" style="text-align: center; font-weight: bold; font-size: 1rem; height: 42px;" min="0" max="10" step="1" inputmode="numeric" placeholder="0–10" required>

                <button type="button" class="btn-delete-row" onclick="removeRow(this)">✖</button>
            </div>
        </div>

        <button type="button" class="btn-add-row" onclick="addRow()">
            + Tambah Baris Kriteria
        </button>

        <div style="margin-top: 24px; text-align: right; border-top: 1px solid var(--c-border); padding-top: 20px;">
            <button type="submit" class="pm-btn pm-btn-primary" style="padding: 10px 24px; font-size: 0.95rem;">
                💾 Simpan Markah
            </button>
        </div>
    </div>
</form>

<?php endif; ?>

<script>
function initSelect2(context = document) {
    $(context).find('.select-search').each(function () {
        if ($(this).hasClass("select2-hidden-accessible")) {
            $(this).select2('destroy');
        }
        $(this).select2({
            width: '100%',
            placeholder: 'Taip untuk cari...',
            allowClear: true,
            minimumResultsForSearch: 0
        });
    });
}

$(document).ready(function () { initSelect2(); });

function addRow() {
    const container = document.getElementById('criteriaContainer');
    const original = container.children[0];
    const row = original.cloneNode(true);
    row.querySelectorAll('input').forEach(i => i.value = '');
    row.querySelectorAll('select').forEach(s => s.selectedIndex = 0);
    row.querySelectorAll('.select2').forEach(el => el.remove());
    container.appendChild(row);
    initSelect2(row);
}

function removeRow(btn) {
    const container = document.getElementById('criteriaContainer');
    if (container.children.length > 1) {
        btn.closest('.criteria-row').remove();
    }
}
</script>

</main>
</body>
</html>