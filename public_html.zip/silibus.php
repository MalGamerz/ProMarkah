<?php
session_start();
include 'db.php';
$conn = getDB();

// ✅ Restrict access to judges only
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'judge') {
    header("Location: login.php");
    exit();
}

// ✅ Set active page for the sidebar navigation
$pm_page = 'silibus';
include 'layout.php';

// Fetch all data efficiently to avoid N+1 query problem
$sessionsStmt = $conn->prepare("
    SELECT s.session_id, s.session_name, sr.siri_year, sr.siri_name 
    FROM sessions s 
    LEFT JOIN siri sr ON s.siri_id = sr.siri_id 
    ORDER BY sr.siri_year DESC, sr.siri_name ASC, s.session_name ASC
");
$sessionsStmt->execute();
$sessions = $sessionsStmt->get_result()->fetch_all(MYSQLI_ASSOC);

$levelsStmt = $conn->prepare("SELECT level_id, session_id, level_name FROM levels ORDER BY session_id, level_name ASC");
$levelsStmt->execute();
$levels = $levelsStmt->get_result()->fetch_all(MYSQLI_ASSOC);

$testsStmt = $conn->prepare("SELECT test_id, level_id, test_name FROM tests ORDER BY level_id, test_name ASC");
$testsStmt->execute();
$tests = $testsStmt->get_result()->fetch_all(MYSQLI_ASSOC);

$criteriaStmt = $conn->prepare("SELECT criteria_id, test_id, criteria_name FROM criteria ORDER BY test_id, criteria_name ASC");
$criteriaStmt->execute();
$criteria = $criteriaStmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Organize data for easy lookup
$levelsBySession = [];
foreach ($levels as $level) $levelsBySession[$level['session_id']][] = $level;

$testsByLevel = [];
foreach ($tests as $test) $testsByLevel[$test['level_id']][] = $test;

$criteriaByTest = [];
foreach ($criteria as $criterion) $criteriaByTest[$criterion['test_id']][] = $criterion['criteria_name'];
?>

<style>
    /* ── RESPONSIVE AUTO TABLE (CONTENT-DRIVEN WIDTHS) ── */
    .pm-table-wrap {
        overflow-x: auto;
        overflow-y: auto;
        max-height: calc(100vh - 280px);
        -webkit-overflow-scrolling: touch;
        width: 100%;
        background: var(--c-surface-1);
    }

    .silibus-table {
        display: table !important; 
        width: 100% !important;
        table-layout: auto !important;  /* columns size based on content */
        border-collapse: collapse;
    }

    /* Sticky Top Header */
    .silibus-table th {
        position: sticky;
        top: 0;
        z-index: 10;
        background: #f8f9fa !important; 
        color: var(--c-text-muted);
        border-bottom: 1px solid var(--c-border) !important;
        padding: 12px 16px !important;
        text-align: left;
        white-space: nowrap;
        font-size: 0.65rem !important; 
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.1em !important; 
    }
    
    html.pm-dark .silibus-table th {
        background: var(--c-surface-2) !important;
    }

    /* Base cell styling */
    .silibus-table td {
        color: var(--c-text);
        border-bottom: 1px solid var(--c-border);
        padding: 10px 16px !important;   /* was 12px — slightly tighter */
        font-size: 0.85rem !important;
        vertical-align: top;              /* change from top to top globally */
        word-wrap: break-word;
        line-height: 1.5;
    }

    /* 🔥 FIX: Prevent wrapping in first 5 columns → no extra empty gaps inside them */
    .silibus-table td:nth-child(-n+5),
    .silibus-table th:nth-child(-n+5) {
        white-space: nowrap;
    }

    /* Allow the Kriteria column (6th) to wrap normally */
    .silibus-table td:nth-child(6),
    .silibus-table th:nth-child(6) {
        white-space: normal;
    }

    /* Clean hover effect */
    .silibus-table tbody tr:hover td {
        background-color: var(--c-surface-2) !important; 
    }
    
    /* Lists inside the criteria column */
    .silibus-table ul {
        margin: 0;
        padding-left: 18px;
        list-style-type: square;
        color: var(--c-text-muted);
    }

    .silibus-table li::marker {
        color: var(--c-red);
    }

    .silibus-table li {
        margin-bottom: 4px; 
        line-height: 1.4;
    }

    /* Sleek Badges for Siri & Year */
    .pm-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 0.65rem;
        font-weight: 700;
        text-transform: uppercase;
        padding: 4px 8px;
        border-radius: 4px;
        letter-spacing: 0.05em;
        line-height: 1;
    }
    .pm-badge-year {
        background: var(--c-surface-1);
        color: var(--c-text-muted);
        border: 1px solid var(--c-border-strong);
    }
    .pm-badge-year::before {
        content: '';
        display: inline-block;
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: var(--c-text-muted);
    }
    .pm-badge-siri {
        background: var(--c-red-dim);
        color: var(--c-red);
        border: 1px solid var(--c-red-border);
    }
    .pm-badge-siri::before {
        content: '';
        display: inline-block;
        width: 5px;
        height: 5px;
        border-radius: 50%;
        background: var(--c-red);
    }

    /* ── PAGINATION STYLES ── */
    .pagination-container {
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        padding: 12px 20px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        gap: 16px;
    }

    .pagination-left {
        display: flex;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
    }

    .pagination-info {
        font-size: 0.85rem;
        color: var(--c-text-muted);
        font-weight: 600;
    }

    .pagination-controls {
        display: flex;
        gap: 6px;
    }

    .page-btn {
        padding: 4px 12px;
        font-size: 0.85rem;
        border: 1px solid var(--c-border-strong);
        background: var(--c-surface-1);
        color: var(--c-text);
        border-radius: 4px;
        cursor: pointer;
        font-weight: 600;
        transition: 0.2s ease;
    }

    .page-btn:hover:not(:disabled) {
        background: var(--c-surface-3);
        border-color: var(--c-text-muted);
    }

    .page-btn.active {
        background: var(--c-red);
        color: #fff;
        border-color: var(--c-red);
    }

    .page-btn:disabled {
        opacity: 0.4;
        cursor: not-allowed;
    }

    @media (max-width: 600px) {
        .pagination-container {
            flex-direction: column;
            justify-content: center;
            text-align: center;
        }
        .pagination-left {
            justify-content: center;
        }
        .pagination-controls {
            width: 100%;
            justify-content: center;
            flex-wrap: wrap;
        }
    }
    
    /* ── FLEXBOX FIX: ELIMINATE GAPS AND CUTOFFS ── */
    .pm-silibus-card {
        display: flex !important;
        flex-direction: column !important;
        height: calc(100vh - 200px); 
        padding: 0 !important;
        border: none !important;
        overflow: hidden !important;
        background: var(--c-surface-1);
    }

    .pm-table-wrap {
        flex: 1 1 auto !important;
        overflow-y: auto !important;
        overflow-x: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        width: 100% !important;
        margin: 0 !important;
    }

    .silibus-table {
        margin: 0 !important;
        border-bottom: 1px solid var(--c-border);
    }

    .pagination-container {
        flex: 0 0 auto !important;
        margin: 0 !important;
        position: relative;
        z-index: 10;
    }
</style>

<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 12px;">
    <h2 class="pm-page-heading" style="margin: 0; font-size: 1.5rem;">📖 Senarai Silibus Mengikut Sidang dan Tahap</h2>
    
    <div style="flex-grow: 1; max-width: 400px; position: relative;">
        <span style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); font-size: 0.9rem;">🔍</span>
        <input type="text" id="silibusSearch" class="pm-input" placeholder="Cari tahun, siri, sidang, tahap, ujian..."
            style="width: 100%; padding: 8px 12px 8px 36px; font-size: 0.85rem; border-radius: 20px;">
    </div>
</div>

<div class="pm-alert pm-alert-warn" style="padding: 8px 12px; margin-bottom: 12px; font-size: 0.85rem; justify-content: center; text-align: center;">
    📌 Maklumat ini adalah rujukan rasmi untuk semua juri bagi memastikan pemarkahan konsisten mengikut silibus.
</div>

<div class="pm-card pm-silibus-card">
    <div class="pm-table-wrap">
        <table class="pm-table silibus-table" id="silibusTable">
            <thead>
                <tr>
                    <th>Tahun</th>
                    <th>Siri</th>
                    <th>Sidang</th>
                    <th>Peringkat (Tahap)</th>
                    <th>Nama Ujian</th>
                    <th>Kriteria / Deskripsi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($sessions as $session) {
                    $sidang_name = htmlspecialchars($session['session_name']);
                    $session_id  = $session['session_id'];
                    $year_text   = htmlspecialchars($session['siri_year'] ?? 'Tiada Tahun');
                    $siri_text   = htmlspecialchars($session['siri_name'] ?? 'Tiada Siri');
                    
                    // Clean, sleek text formatting
                    $year_html   = "<span style='font-weight: 600; color: var(--c-text-muted); font-size: 0.85rem;'>{$year_text}</span>";
                    $siri_html   = "<span style='font-weight: 700; color: var(--c-red); font-size: 0.85rem;'>{$siri_text}</span>";
                    $sidang_html = "<span style='font-weight: 700; color: var(--c-text); font-size: 0.85rem;'>{$sidang_name}</span>";

                    $sessionLevels = $levelsBySession[$session_id] ?? [];

                    // Handle empty Tahap
                    if (empty($sessionLevels)) {
                        echo "<tr class='silibus-data-row'>
                            <td style='vertical-align: top;'>{$year_html}</td>
                            <td style='vertical-align: top;'>{$siri_html}</td>
                            <td style='vertical-align: top;'>{$sidang_html}</td>
                            <td style='font-weight:600; color:var(--c-text-muted); vertical-align: top;'>{$tahap_name}</td>
                            <td style='font-weight:600; color:var(--c-text); vertical-align: top;'>{$ujian_name}</td>
                            <td>";
                        continue;
                    }

                    foreach ($sessionLevels as $level) {
                        $tahap_name = htmlspecialchars($level['level_name']);
                        $level_id = $level['level_id'];
                        $levelTests = $testsByLevel[$level_id] ?? [];

                        // Handle empty Ujian
                        if (empty($levelTests)) {
                            echo "<tr class='silibus-data-row'>
                            <td style='vertical-align: top;'>{$year_html}</td>
                            <td style='vertical-align: top;'>{$siri_html}</td>
                            <td style='vertical-align: top;'>{$sidang_html}</td>
                            <td style='font-weight:600; color:var(--c-text-muted); vertical-align: top;'>{$tahap_name}</td>
                            <td style='font-weight:600; color:var(--c-text); vertical-align: top;'>{$ujian_name}</td>
                            <td>";
                            continue;
                        }

                        // Normal Output
                        foreach ($levelTests as $test) {
                            $ujian_name = htmlspecialchars($test['test_name']);
                            $test_id = $test['test_id'];
                            $testCriteria = $criteriaByTest[$test_id] ?? [];

                            echo "<tr class='silibus-data-row'>
                            <td style='vertical-align: top;'>{$year_html}</td>
                            <td style='vertical-align: top;'>{$siri_html}</td>
                            <td style='vertical-align: top;'>{$sidang_html}</td>
                            <td style='font-weight:600; color:var(--c-text-muted); vertical-align: top;'>{$tahap_name}</td>
                            <td style='font-weight:600; color:var(--c-text); vertical-align: top;'>{$ujian_name}</td>
                            <td>";

                            if (!empty($testCriteria)) {
                                echo "<ul style='margin:0; padding-left:0; list-style-position:inside; list-style-type: disc; color: var(--c-text-muted);'>";
                                foreach ($testCriteria as $criteria_name) {
                                    echo "<li style='margin-bottom: 4px;'><span style='color: var(--c-text);'>". htmlspecialchars($criteria_name) . "</span></li>";
                                }
                                echo "</ul>";
                            } else {
                                echo "<em style='color:var(--c-text-muted); opacity: 0.7;'>Tiada kriteria direkodkan.</em>";
                            }
                            echo "</td></tr>";
                        }
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
    
    <div class="pagination-container" id="paginationWrapper">
        <div class="pagination-left">
            <select id="rowsPerPageSelect" class="pm-select" style="padding: 4px 8px; height: auto; width: auto; font-size: 0.8rem;">
                <option value="10">10 / mukasurat</option>
                <option value="15" selected>15 / mukasurat</option>
                <option value="20">20 / mukasurat</option>
                <option value="50">50 / mukasurat</option>
                <option value="100">100 / mukasurat</option>
            </select>
            <div class="pagination-info" id="pageInfo">Memaparkan 0 rekod</div>
        </div>
        <div class="pagination-controls" id="paginationButtons">
            </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('silibusSearch');
    const rowsPerPageSelect = document.getElementById('rowsPerPageSelect');
    const allRows = Array.from(document.querySelectorAll('.silibus-data-row'));
    const paginationButtons = document.getElementById('paginationButtons');
    const pageInfo = document.getElementById('pageInfo');
    
    let rowsPerPage = parseInt(rowsPerPageSelect.value);
    let currentPage = 1;
    let filteredRows = [...allRows];

    function renderTable() {
        const totalPages = Math.ceil(filteredRows.length / rowsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        if (currentPage < 1) currentPage = 1;

        const start = (currentPage - 1) * rowsPerPage;
        const end = start + rowsPerPage;

        // Hide all first
        allRows.forEach(row => row.style.display = 'none');

        // Show only the slice for the current page
        filteredRows.forEach((row, index) => {
            if (index >= start && index < end) {
                row.style.display = '';
            }
        });

        updatePaginationUI(totalPages);
    }

    function updatePaginationUI(totalPages) {
        // Update Info Text
        const startText = filteredRows.length === 0 ? 0 : ((currentPage - 1) * rowsPerPage) + 1;
        const endText = Math.min(currentPage * rowsPerPage, filteredRows.length);
        pageInfo.innerHTML = `Memaparkan <b>${startText} - ${endText}</b> daripada <b>${filteredRows.length}</b> rekod`;

        // Build Buttons
        let html = '';
        
        // Prev Button
        html += `<button class="page-btn" ${currentPage === 1 ? 'disabled' : ''} onclick="goToPage(${currentPage - 1})">«</button>`;
        
        // Logic to show a max of 5 page numbers
        let startPage = Math.max(1, currentPage - 2);
        let endPage = Math.min(totalPages, startPage + 4);
        if (endPage - startPage < 4) {
            startPage = Math.max(1, endPage - 4);
        }

        if (startPage > 1) {
            html += `<button class="page-btn" onclick="goToPage(1)">1</button>`;
            if (startPage > 2) html += `<span style="color: var(--c-text-faint); margin: 0 2px; align-self: end;">...</span>`;
        }

        for (let i = startPage; i <= endPage; i++) {
            html += `<button class="page-btn ${i === currentPage ? 'active' : ''}" onclick="goToPage(${i})">${i}</button>`;
        }

        if (endPage < totalPages) {
            if (endPage < totalPages - 1) html += `<span style="color: var(--c-text-faint); margin: 0 2px; align-self: end;">...</span>`;
            html += `<button class="page-btn" onclick="goToPage(${totalPages})">${totalPages}</button>`;
        }

        // Next Button
        html += `<button class="page-btn" ${currentPage === totalPages || totalPages === 0 ? 'disabled' : ''} onclick="goToPage(${currentPage + 1})">»</button>`;

        paginationButtons.innerHTML = html;
    }

    window.goToPage = function(page) {
        currentPage = page;
        renderTable();
        // Smooth scroll back to top of table wrapper
        document.querySelector('.pm-table-wrap').scrollTo({ top: 0, behavior: 'smooth' });
    };

    rowsPerPageSelect.addEventListener('change', function() {
        rowsPerPage = parseInt(this.value);
        currentPage = 1;
        renderTable();
    });

    searchInput.addEventListener('input', function() {
        const keyword = this.value.toLowerCase();
        
        // Filter rows based on search
        filteredRows = allRows.filter(row => row.innerText.toLowerCase().includes(keyword));
        
        // Reset to page 1 on new search
        currentPage = 1;
        renderTable();
    });

    // Initial load
    renderTable();
});
</script>

</main>
</body>
</html>