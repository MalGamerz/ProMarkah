<?php
include 'db.php';
$conn = getDB();


// Optional: filter by session if posted
$sidang_id = intval($_POST['sidang_id'] ?? 0);

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=Kehadiran_Sidang_" . ($sidang_id ?: 'Semua') . ".xls");
header("Pragma: no-cache");
header("Expires: 0");

echo "<table border='1'>";
echo "<tr>
        <th>Bil</th>
        <th>Sidang</th>
        <th>Cawangan</th>
        <th>Nama Pesilat</th>
        <th>ID Pesilat</th>
        <th>Status Kehadiran</th>
      </tr>";

// Main query — unique students only
$query = "
    SELECT 
        st.student_id,
        st.student_name,
        sc.school_name,
        MAX(se.session_name) AS session_name,
        'Hadir' AS status
    FROM attendance a
    JOIN students st ON a.student_id = st.student_id
    JOIN schools sc ON st.school_id = sc.school_id
    JOIN sessions se ON a.session_id = se.session_id
    WHERE a.status='Present'
";

if ($sidang_id > 0) {
    $query .= " AND se.session_id = $sidang_id ";
}

$query .= " GROUP BY st.student_id, st.student_name, sc.school_name
            ORDER BY st.student_name ASC";

$result = $conn->query($query);

if ($result && $result->num_rows > 0) {
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>{$no}</td>
                <td>{$row['session_name']}</td>
                <td>{$row['school_name']}</td>
                <td>{$row['student_name']}</td>
                <td>{$row['student_id']}</td>
                <td>✔ {$row['status']}</td>
              </tr>";
        $no++;
    }
} else {
    echo "<tr><td colspan='6' style='text-align:center;'>Tiada data kehadiran direkodkan.</td></tr>";
}

echo "</table>";
exit;
?>
