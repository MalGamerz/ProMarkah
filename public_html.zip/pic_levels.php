<?php
ini_set("display_errors", 0);
ini_set("display_startup_errors", 0);
error_reporting(E_ALL);
ini_set("log_errors", 1);

session_start();
include "db.php";
$conn = getDB();

if (!isset($_SESSION["role"]) || $_SESSION["role"] !== "pic") {
  header("Location: login.php");
  exit();
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
  session_write_close();

  if ($_POST["action"] === "add") {
    $name = trim($_POST["level_name"]);
    if ($name) {
      $stmt = $conn->prepare(
        "INSERT INTO levels (session_id, level_name) VALUES (?, ?)",
      );
      $stmt->bind_param("is", $_POST["session_id"], $name);
      $stmt->execute();
      $stmt->close();
    }
  }

  if ($_POST["action"] === "delete") {
    $lid = (int) $_POST["level_id"];
    $stmt = $conn->prepare("DELETE FROM levels WHERE level_id=?");
    $stmt->bind_param("i", $lid);
    $stmt->execute();
    $stmt->close();
  }

  if ($_POST["action"] === "save_all" && isset($_POST["levels"])) {
    $stmt = $conn->prepare("UPDATE levels SET level_name=? WHERE level_id=?");
    foreach ($_POST["levels"] as $id => $l) {
      $name = trim($l["level_name"]);
      $id = (int) $id;
      if ($name) {
        $stmt->bind_param("si", $name, $id);
        $stmt->execute();
      }
    }
    $stmt->close();
  }
  header("Location: pic_levels.php");
  exit();
}

session_write_close();

if (isset($_GET["ajax"])) {
  $search = $_GET["search"] ?? "";
  $sessionFilter = $_GET["session"] ?? "";

  $lWhereArr = ["1=1"];
  $lTypes = "";
  $lVals = [];
  if ($search !== "") {
    $lWhereArr[] = "l.level_name LIKE ?";
    $lTypes .= "s";
    $lVals[] = "%" . $search . "%";
  }
  if ($sessionFilter !== "") {
    $lWhereArr[] = "l.session_id = ?";
    $lTypes .= "i";
    $lVals[] = (int) $sessionFilter;
  }

  // Scope to "Siri Aktif" — only iterate sessions belonging to it.
  $active_siri = (int) ($_SESSION["active_siri_id"] ?? 0);
  $sessions = $active_siri > 0
    ? $conn->query("SELECT se.*, si.siri_name FROM sessions se LEFT JOIN siri si ON se.siri_id = si.siri_id WHERE se.siri_id = $active_siri ORDER BY se.session_name")
    : $conn->query("SELECT se.*, si.siri_name FROM sessions se LEFT JOIN siri si ON se.siri_id = si.siri_id ORDER BY se.session_name");
  $found = false;

  while ($sess = $sessions->fetch_assoc()) {
    $sid = $sess["session_id"];

    $iterArr = array_merge($lWhereArr, ["l.session_id = ?"]);
    $iterSql = implode(" AND ", $iterArr);
    $iterTypes = $lTypes . "i";
    $iterVals = array_merge($lVals, [$sid]);

    $stmt = $conn->prepare(
      "SELECT l.* FROM levels l WHERE $iterSql ORDER BY l.level_name",
    );
    $stmt->bind_param($iterTypes, ...$iterVals);
    $stmt->execute();
    $levels = $stmt->get_result();
    $stmt->close();

    if ($levels->num_rows == 0) {
      continue;
    }
    $found = true;

    $siriLabel = $sess["siri_name"] ? htmlspecialchars($sess["siri_name"]) : "Tiada Siri";
    echo "<div class='accordion-card'>
                <div class='level-header' onclick=\"toggleBlock('session_$sid', this)\">
                    <span class='acc-icon'>&#9658;</span>
                    <strong>" .
      htmlspecialchars($sess["session_name"]) .
      "</strong>
                    <span class='siri-label'>$siriLabel</span>
                    <span class='count-badge'>{$levels->num_rows} Peringkat</span>
                </div>
                <div id='session_$sid' class='acc-body' style='display:none;'>
                    <div class='table-responsive'>
                        <table class='tests-table' data-session='$sid'>
                            <thead>
                                <tr>
                                    <th style='width:50px; text-align:center;'>NO</th>
                                    <th>NAMA PERINGKAT</th>
                                    <th style='width:100px; text-align:center;'>TINDAKAN</th>
                                </tr>
                            </thead>
                            <tbody>";
    $no = 1;
    while ($l = $levels->fetch_assoc()) {
      $lid = $l["level_id"];
      $safeName = htmlspecialchars($l["level_name"], ENT_QUOTES);
      
      // Inline styles to exactly match the white red-bordered 'Padam' button from your image
      echo "<tr data-id='$lid'>
                    <td class='col-no' style='text-align:center; color:var(--c-text-faint);'>$no</td>
                    <td><input name='levels[$lid][level_name]' value='$safeName' data-orig='$safeName' class='level-input'></td>
                    <td class='col-actions' style='text-align:center;'>
                        <button type='button' class='pm-btn btn-sm' style='padding:5px 12px; font-size:0.78rem; background:#fff; color:#d62828; border:1px solid #fca5a5; border-radius:4px;' onclick=\"delRow('$lid')\">Padam</button>
                    </td>
                  </tr>";
      $no++;
    }
    echo "          </tbody>
                        </table>
                    </div>
                </div>
              </div>";
  }

  if (!$found) {
    echo "<p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Tiada peringkat ditemui untuk carian ini.</p>";
  }
  exit();
}

$pm_page = "levels";
include "layout.php";
?>

<style>
    /* ── Page header ── */
    .pic-section-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        gap: 12px;
        margin-bottom: 20px;
    }
    .pic-section-header h2 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.8rem;
        color: var(--c-white);
        letter-spacing: 0.05em;
        margin: 0;
    }
    .pic-section-sub {
        color: var(--c-text-faint);
        font-size: 0.82rem;
        margin-top: 2px;
    }

    /* ── Filter card ── */
    .filter-card{
        background:var(--c-surface-1);
        border:1px solid var(--c-border-strong);
        border-radius:12px;
        padding:20px;
        margin-bottom:24px;
        box-shadow:0 4px 12px rgba(0,0,0,.08);
    }

    .filter-card-title{
        font-size:.72rem;
        font-weight:700;
        text-transform:uppercase;
        letter-spacing:.12em;
        color:var(--c-text-faint);
        margin-bottom:16px;
    }

    .pic-filter-bar{
        display:grid;
        grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
        gap:16px;
        align-items:end;
    }

    .pic-filter-bar > div{
        min-width:0;
    }

    .pic-filter-bar label{
        display:block;
        margin-bottom:6px;
        font-size:.75rem;
        font-weight:600;
        text-transform:uppercase;
        letter-spacing:.08em;
        color:var(--c-text-faint);
    }
    .pic-filter-bar input,
    .pic-filter-bar select {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-white);
        border-radius: 6px;
        padding: 8px 10px;
        font-size: 0.875rem;
        outline: none;
        width: 100%;
        transition: border-color .2s;
        box-sizing: border-box;
    }
    .pic-filter-bar input:focus,
    .pic-filter-bar select:focus { border-color: var(--c-red); }
    .pic-filter-bar select option { background: var(--c-surface-2); color: var(--c-white); }
    .pic-filter-bar input::placeholder { color: var(--c-text-faint); }

    /* ── Add card ── */
    .pic-add-card {
        display: none;
        background: var(--c-surface-1);
        border: 1px solid var(--c-red-border);
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 18px;
    }
    .pic-add-card h3 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.1rem;
        color: var(--c-white);
        margin-bottom: 14px;
        letter-spacing: 0.05em;
    }
    .pic-add-form {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 10px;
        align-items: end;
    }
    .pic-add-form input,
    .pic-add-form select {
        background: var(--c-surface-2);
        border: 1px solid var(--c-border-strong);
        color: var(--c-white);
        border-radius: 6px;
        padding: 9px 12px;
        font-size: 0.875rem;
        outline: none;
        width: 100%;
        transition: border-color .2s;
    }
    .pic-add-form input:focus,
    .pic-add-form select:focus { border-color: var(--c-red); box-shadow: 0 0 0 3px var(--c-red-dim); }
    .pic-add-form select option { background: var(--c-surface-2); }
    .pic-add-form label {
        display: block;
        font-size: 0.75rem;
        color: var(--c-text-faint);
        margin-bottom: 4px;
        text-transform: uppercase;
        font-weight: 600;
        letter-spacing: 0.07em;
    }

    /* ── Main card & Accordions ── */
    .tests-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border-strong);
        border-radius: 10px;
        overflow: hidden;
        position: relative;
        margin-top: 20px;
    }

    /* Save bar — always visible */
    .tests-save-bar {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 10px 16px;
        background: var(--c-surface-2);
        border-bottom: 2px solid var(--c-border-strong);
        position: sticky;
        top: 0;
        z-index: 10;
        transition: border-bottom-color .25s;
    }
    .tests-save-bar.dirty {
        border-bottom-color: var(--c-red);
    }
    .tests-save-bar .save-msg { font-size: 0.82rem; color: var(--c-text-faint); flex: 1; }
    .tests-save-bar .save-msg strong { color: var(--c-white); }
    .tests-save-bar .btn-discard {
        display: none;
        padding: 5px 12px;
        background: transparent;
        color: var(--c-text-faint);
    }
    .tests-save-bar.dirty .btn-discard { display: inline-flex; }

    /* Scrollable Container */
    .tests-table-wrap {
        max-height: 520px;
        overflow-y: auto;
        overflow-x: hidden;
        scrollbar-width: thin;
        scrollbar-color: var(--c-surface-3) transparent;
        padding: 12px;
    }

    /* Accordion Style */
    .accordion-card {
        background: var(--c-surface-1);
        border: 1px solid var(--c-border);
        border-radius: 8px;
        margin-bottom: 8px;
        overflow: hidden;
        transition: border-color 0.2s;
    }
    .accordion-card.has-changes {
        border-color: var(--c-red);
        box-shadow: 0 0 0 1px var(--c-red);
    }
    .level-header {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 12px 16px;
        background: var(--c-surface-2);
        cursor: pointer;
        color: var(--c-white);
        font-weight: 600;
        font-size: 0.92rem;
        transition: background .15s;
    }
    .level-header:hover { background: var(--c-surface-3); }
    .level-header .acc-icon {
        color: var(--c-text-muted);
        font-size: 0.8rem;
        transition: transform .2s ease;
        display: inline-block;
    }
    .level-header .siri-label {
        margin-left: 10px;
        font-size: 0.72rem;
        font-weight: 600;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: var(--c-text-faint);
        background: rgba(214, 40, 40, 0.08);
        border: 1px solid var(--c-red-border);
        padding: 2px 8px;
        border-radius: 10px;
    }
    .level-header .count-badge {
        margin-left: auto;
        background: var(--c-surface-0);
        padding: 2px 8px;
        border-radius: 12px;
        font-size: 0.75rem;
        color: var(--c-text-muted);
        border: 1px solid var(--c-border);
    }

    /* ── Table inside Accordion ── */
    .table-responsive { width: 100%; overflow-x: auto; }
    .tests-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.875rem;
        min-width: 400px;
    }
    .tests-table thead th {
        background: var(--c-surface-3);
        color: var(--c-text-muted);
        font-size: 0.75rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        padding: 10px 14px;
        text-align: left;
        white-space: nowrap;
        border-bottom: 1px solid var(--c-border-strong);
    }
    .tests-table td {
        padding: 8px 14px;
        color: var(--c-text-muted);
        background: var(--c-surface-1);
        border-bottom: 1px solid var(--c-border);
        vertical-align: middle;
        transition: background .1s;
    }
    .tests-table tbody tr:last-child td { border-bottom: none; }
    .tests-table tbody tr:hover td { background: var(--c-surface-2); }
    .tests-table tbody tr.row-dirty td { background: rgba(214, 40, 40, 0.06) !important; }
    .tests-table td.col-no { width: 50px; }
    .tests-table td.col-actions { width: 100px; white-space: nowrap; }
    .tests-table input {
        background: var(--c-surface-0) !important;
        border: 1px solid var(--c-border-strong) !important;
        color: var(--c-white) !important;
        border-radius: 4px !important;
        padding: 5px 8px !important;
        font-size: 0.82rem !important;
        outline: none !important;
        width: 100%;
        transition: border-color .2s;
    }
    .tests-table input:focus { border-color: var(--c-red) !important; }

    #ajaxSpinner { display: none; padding: 30px; text-align: center; color: var(--c-text-faint); margin: 0; }

    /* ── LIGHT MODE ── */
    html.pm-light .pic-section-header h2 { color: #111; }
    html.pm-light .pic-section-sub { color: #555; }
    html.pm-light .filter-card { background: #fff; border-color: #e5e7eb; border-top-color: var(--c-red); box-shadow: 0 1px 4px rgba(0,0,0,0.06); }
    html.pm-light .filter-card-title { color: #888; }
    html.pm-light .pic-filter-bar label { color: #555; }
    html.pm-light .pic-filter-bar input, html.pm-light .pic-filter-bar select { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .pic-filter-bar input::placeholder { color: #9ca3af; }
    html.pm-light .pic-filter-bar select option { background: #fff; color: #111; }
    html.pm-light .pic-add-card { background: #fff; border-color: var(--c-red-border); }
    html.pm-light .pic-add-card h3 { color: #111; }
    html.pm-light .pic-add-form label { color: #555; }
    html.pm-light .pic-add-form input, html.pm-light .pic-add-form select { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .pic-add-form select option { background: #fff; }
    html.pm-light .tests-card { background: #fff; border-color: #e5e7eb; }
    html.pm-light .tests-save-bar { background: #f3f4f6; border-bottom-color: #e5e7eb; }
    html.pm-light .tests-save-bar.dirty { border-bottom-color: var(--c-red); }
    html.pm-light .tests-save-bar .save-msg { color: #555; }
    html.pm-light .tests-save-bar .save-msg strong { color: #111; }
    html.pm-light .accordion-card { background: #fff; border-color: #e5e7eb; }
    html.pm-light .level-header { background: #f9fafb; color: #111; }
    html.pm-light .level-header:hover { background: #f3f4f6; }
    html.pm-light .level-header .count-badge { background: #fff; color: #555; border-color: #d1d5db; }
    html.pm-light .level-header .siri-label { background: #fdecec; color: #b91c1c; border-color: #fca5a5; }
    html.pm-light .tests-table thead th { background: #374151; color: #f9fafb; border-bottom-color: #e5e7eb; }
    html.pm-light .tests-table td { background: #fff; color: #222; border-bottom-color: #e5e7eb; }
    html.pm-light .tests-table tbody tr:hover td { background: #f9fafb; }
    html.pm-light .tests-table tbody tr.row-dirty td { background: rgba(214, 40, 40, 0.04) !important; }
    html.pm-light .tests-table input { background: #fff !important; border-color: #d1d5db !important; color: #111 !important; }
    html.pm-light .tests-table input:focus { border-color: var(--c-red) !important; box-shadow: 0 0 0 2px var(--c-red-dim) !important; }

    /* ── Searchable dropdown ── */
    .dd-wrap { position: relative; }
    .dd-trigger{
        display:flex;
        align-items:center;
        justify-content:space-between;
        min-height:46px;
        width:100%;
        padding:0 14px;
        background:var(--c-surface-2);
        border:1px solid var(--c-border-strong);
        border-radius:8px;
        color:var(--c-white);
        font-size:.875rem;
        cursor:pointer;
        user-select:none;
        transition: border-color .2s, box-shadow .2s, background .2s;
    }
    .dd-trigger:hover{ border-color:var(--c-red); }
    .dd-trigger.open{ border-color:var(--c-red); box-shadow:0 0 0 3px var(--c-red-dim); }
    .dd-trigger .dd-arrow { color: var(--c-text-faint); font-size: 0.7rem; transition: transform .2s; }
    .dd-trigger.open .dd-arrow { transform: rotate(180deg); }
    
    .dd-panel{
        display:none;
        position:absolute;
        top:calc(100% + 6px);
        left:0;
        right:0;
        background:var(--c-surface-2);
        border:1px solid var(--c-red);
        border-radius:8px;
        overflow:hidden;
        z-index:999;
        box-shadow:0 10px 30px rgba(0,0,0,.25);
    }
    .dd-panel.open{ display:block; }
    .dd-search-box { padding: 8px; border-bottom: 1px solid var(--c-border-strong); }
    .dd-search-box input {
        width: 100%; background: var(--c-surface-0); border: 1px solid var(--c-border-strong);
        color: var(--c-white); border-radius: 4px; padding: 6px 8px; font-size: 0.8rem;
        outline: none; box-sizing: border-box; transition: border-color .2s;
    }
    .dd-search-box input:focus { border-color: var(--c-red); }
    .dd-search-box input::placeholder { color: var(--c-text-faint); }
    .dd-options { max-height: 180px; overflow-y: auto; scrollbar-width: thin; }
    .dd-opt { padding: 9px 12px; font-size: 0.875rem; color: var(--c-white); cursor: pointer; transition: background .1s; }
    .dd-opt:hover { background: var(--c-surface-3); }
    .dd-opt.selected { color: var(--c-red); font-weight: 600; }
    .dd-opt.hidden { display: none; }
    .dd-empty { padding: 10px 12px; color: var(--c-text-faint); font-size: 0.82rem; display: none; text-align: center; }

    html.pm-light .dd-trigger { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .dd-panel { background: #fff; box-shadow: 0 6px 20px rgba(0,0,0,0.12); }
    html.pm-light .dd-search-box { border-bottom-color: #e5e7eb; }
    html.pm-light .dd-search-box input { background: #f9fafb; border-color: #d1d5db; color: #111; }
    html.pm-light .dd-opt { color: #111; }
    html.pm-light .dd-opt:hover { background: #f3f4f6; }
</style>

<form id='saveAllForm' method='POST' style='display:none;'>
    <input type='hidden' name='action' value='save_all'>
</form>
<form id='delFrm' method='POST' style='display:none;'>
    <input type='hidden' name='action' value='delete'>
    <input type='hidden' name='level_id' value=''>
</form>

<div class='pic-section-header'>
    <div>
        <h2>🎯 Pengurusan Peringkat</h2>
        <div class='pic-section-sub'>Kawal selia dan tambah peringkat mengikut sidang</div>
    </div>
    <button type='button' class='pm-btn pm-btn-primary' onclick="toggleAddCard()">+ Tambah Peringkat</button>
</div>

<div class="filter-card">
    <div class="filter-card-title">
        Penapis Peringkat
    </div>

    <div class="pic-filter-bar">

        <div>
            <label>Pilih Sidang</label>
            <div class="dd-wrap" id="ddWrap_session">
                <div class="dd-trigger" id="ddTrigger_session" onclick="ddToggle('session')">
                    <span id="ddLabel_session" style="color:var(--c-text-faint);">
                        -- Semua Sidang --
                    </span>
                    <span class="dd-arrow">▼</span>
                </div>

                <div class="dd-panel" id="ddPanel_session">
                    <div class="dd-search-box">
                        <input type="text" placeholder="Cari sidang..." oninput="ddFilter('session',this.value)" onclick="event.stopPropagation()">
                    </div>

                    <div class="dd-options" id="ddOpts_session">
                        <div class="dd-opt selected" data-value="" onclick="ddSelect('session','','-- Semua Sidang --')">
                            -- Semua Sidang --
                        </div>
                        <?php
                        $sessions = $conn->query("SELECT * FROM sessions ORDER BY session_name");
                        while ($s = $sessions->fetch_assoc()) {
                          $id = $s["session_id"];
                          $name = htmlspecialchars($s["session_name"]);
                          echo "<div class='dd-opt' data-value='{$id}' onclick=\"ddSelect('session','{$id}','{$name}')\">{$name}</div>";
                        }
                        ?>
                    </div>
                    <div class="dd-empty" id="ddEmpty_session">Tiada hasil</div>
                </div>
                <input type="hidden" id="f_session" value="">
            </div>
        </div>

        <div>
            <label>Cari Nama Peringkat</label>
            <div class="dd-wrap" id="ddWrap_search">
                <div class="dd-trigger" id="ddTrigger_search" onclick="ddToggle('search')">
                    <span id="ddLabel_search" style="color:var(--c-text-faint);">
                        -- Semua Peringkat --
                    </span>
                    <span class="dd-arrow">▼</span>
                </div>

                <div class="dd-panel" id="ddPanel_search">
                    <div class="dd-search-box">
                        <input type="text" id="f_search" placeholder="Taip nama peringkat..." oninput="ddSearchInput(this.value)" onclick="event.stopPropagation()">
                    </div>

                    <div class="dd-options" id="ddOpts_search">
                        <div class="dd-opt selected" data-value="" onclick="ddSelect('search','','-- Semua Peringkat --')">
                            -- Semua Peringkat --
                        </div>
                        <?php
                        $dist_levels = $conn->query("SELECT DISTINCT level_name FROM levels ORDER BY level_name");
                        while ($dl = $dist_levels->fetch_assoc()) {
                          $name = htmlspecialchars($dl["level_name"]);
                          echo "<div class='dd-opt' data-value='{$name}' onclick=\"ddSelect('search','{$name}','{$name}')\">{$name}</div>";
                        }
                        ?>
                    </div>
                    <div class="dd-empty" id="ddEmpty_search">Tiada hasil</div>
                </div>
            </div>
        </div>

    </div>
</div>

<div id='addLevel' class='pic-add-card'>
    <h3>+ Tambah Peringkat Baru</h3>
    <form method='POST' class='pic-add-form'>
        <input type='hidden' name='action' value='add'>
        <div>
            <label>Pilih Sidang</label>
            <select name='session_id' required>
                <?php
                $sessions = $conn->query("SELECT * FROM sessions ORDER BY session_name");
                while ($s = $sessions->fetch_assoc()) {
                  echo "<option value='{$s["session_id"]}'>" . htmlspecialchars($s["session_name"]) . "</option>";
                }
                ?>
            </select>
        </div>
        <div>
            <label>Nama Peringkat</label>
            <input name='level_name' placeholder='Contoh: Ujian Awan Putih Cula Hijau 1' required>
        </div>
        <div style='display:flex;align-items:flex-end;'>
            <button class='pm-btn pm-btn-primary' style="width: 100%;">Tambah Peringkat</button>
        </div>
    </form>
</div>

<div class='tests-card'>
    <div class='tests-save-bar' id='saveDirtyBar'>
        <span class='save-msg' id='saveMsg'>Tiada perubahan</span>
        <button type='button' class='pm-btn btn-sm btn-discard' onclick="discardAll()">Batal</button>
        <button type='button' class='pm-btn pm-btn-primary btn-sm' style='padding:5px 12px;' onclick="submitSaveAll()">💾 Simpan Semua</button>
    </div>

    <div class='tests-table-wrap' id='levelList'>
        <p style='text-align:center;padding:30px;color:var(--c-text-faint);'>Memuatkan...</p>
    </div>
    <div id='ajaxSpinner'>⏳ Mencari...</div>
</div>

<script>
let _t = null;
let _dirtyRows = new Set();

function ajaxFilter() {
    clearTimeout(_t);
    _t = setTimeout(_load, 400);
}

function _load() {
    const params = new URLSearchParams({
        ajax: '1',
        search: document.getElementById('f_search').value,
        session: document.getElementById('f_session').value
    });

    const wrapper = document.getElementById('levelList');
    const spinner = document.getElementById('ajaxSpinner');

    wrapper.style.display = 'none';
    spinner.style.display = 'block';

    fetch('pic_levels.php?' + params)
        .then(r => r.text())
        .then(html => {
            wrapper.innerHTML = html;
            wrapper.style.display = 'block';
            spinner.style.display = 'none';
            _dirtyRows.clear();
            updateDirtyBar();
            attachListeners();
        })
        .catch(err => {
            console.error(err);
            wrapper.style.display = 'block';
            spinner.style.display = 'none';
        });
}

function attachListeners() {
    document.querySelectorAll('.level-input').forEach(el => {
        if (el.dataset.listening) return;
        el.dataset.listening = '1';
        el.addEventListener('input', onInputChange);
    });
}

function onInputChange(e) {
    const row = e.target.closest('tr');
    if (!row) return;
    const id = row.dataset.id;
    const orig = e.target.dataset.orig ?? '';
    const accCard = e.target.closest('.accordion-card');

    if (e.target.value !== orig) {
        _dirtyRows.add(id);
        row.classList.add('row-dirty');
        if(accCard) accCard.classList.add('has-changes');
    } else {
        _dirtyRows.delete(id);
        row.classList.remove('row-dirty');
        if(accCard && accCard.querySelectorAll('.row-dirty').length === 0) {
            accCard.classList.remove('has-changes');
        }
    }
    updateDirtyBar();
}

function updateDirtyBar() {
    const bar = document.getElementById('saveDirtyBar');
    const msg = document.getElementById('saveMsg');
    bar.classList.toggle('dirty', _dirtyRows.size > 0);
    msg.innerHTML = _dirtyRows.size > 0
        ? `Ada <strong>${_dirtyRows.size}</strong> perubahan belum disimpan`
        : 'Tiada perubahan';
}

function submitSaveAll() {
    const form = document.getElementById('saveAllForm');
    form.querySelectorAll('.dyn-input').forEach(el => el.remove());
    document.querySelectorAll('.level-input').forEach(el => {
        const h = document.createElement('input');
        h.type = 'hidden';
        h.name = el.name;
        h.value = el.value;
        h.className = 'dyn-input';
        form.appendChild(h);
    });
    form.submit();
}

function discardAll() {
    document.querySelectorAll('.level-input').forEach(el => {
        if (el.dataset.orig !== undefined) el.value = el.dataset.orig;
        el.closest('tr')?.classList.remove('row-dirty');
    });
    document.querySelectorAll('.accordion-card').forEach(acc => {
        acc.classList.remove('has-changes');
    });
    _dirtyRows.clear();
    updateDirtyBar();
}

function delRow(id) {
    if (!confirm('Padam peringkat ini? Amaran: Semua data berkaitan dengan peringkat ini mungkin terpadam.')) return;
    document.getElementById('delFrm').querySelector('[name=level_id]').value = id;
    document.getElementById('delFrm').submit();
}

function toggleAddCard() {
    const el = document.getElementById('addLevel');
    el.style.display = (el.style.display === 'block') ? 'none' : 'block';
    if(el.style.display === 'block'){
        setTimeout(() => { el.querySelector('input[name="level_name"]').focus(); }, 50);
    }
}

function toggleBlock(id, headerEl) {
    const bodyEl = document.getElementById(id);
    const iconEl = headerEl.querySelector('.acc-icon');
    if (bodyEl) {
        if (bodyEl.style.display === 'none' || bodyEl.style.display === '') {
            bodyEl.style.display = 'block';
            if (iconEl) iconEl.style.transform = 'rotate(90deg)';
        } else {
            bodyEl.style.display = 'none';
            if (iconEl) iconEl.style.transform = 'rotate(0deg)';
        }
    }
}

function ddToggle(name) {
    const panel = document.getElementById('ddPanel_' + name);
    const trigger = document.getElementById('ddTrigger_' + name);
    const isOpen = panel.classList.contains('open');
    document.querySelectorAll('.dd-panel.open').forEach(p => p.classList.remove('open'));
    document.querySelectorAll('.dd-trigger.open').forEach(t => t.classList.remove('open'));
    if (!isOpen) {
        panel.classList.add('open'); trigger.classList.add('open');
        setTimeout(() => panel.querySelector('.dd-search-box input')?.focus(), 50);
    }
}

function ddFilter(name, val) {
    const opts = document.querySelectorAll('#ddOpts_' + name + ' .dd-opt');
    const empty = document.getElementById('ddEmpty_' + name);
    let any = false;
    opts.forEach(o => { 
        const m = o.textContent.toLowerCase().includes(val.toLowerCase()); 
        o.classList.toggle('hidden', !m); 
        if(m) any=true; 
    });
    if(empty) empty.style.display = any ? 'none' : 'block';
}

function ddSelect(name, value, label) {
    if (name === 'session') document.getElementById('f_session').value = value;
    else if (name === 'search') document.getElementById('f_search').value = value;

    const lbl = document.getElementById('ddLabel_' + name);
    lbl.textContent = label;
    lbl.style.color = value === '' ? 'var(--c-text-faint)' : '';
    document.querySelectorAll('#ddOpts_' + name + ' .dd-opt').forEach(o => o.classList.toggle('selected', o.dataset.value === value));
    document.getElementById('ddPanel_' + name).classList.remove('open');
    document.getElementById('ddTrigger_' + name).classList.remove('open');
    ajaxFilter();
}

function ddSearchInput(val) {
    const lbl = document.getElementById('ddLabel_search');
    lbl.textContent = val || '-- Semua Peringkat --';
    lbl.style.color = val ? '' : 'var(--c-text-faint)';
    ajaxFilter();
}

document.addEventListener('click', e => {
    if (!e.target.closest('.dd-wrap')) {
        document.querySelectorAll('.dd-panel.open').forEach(p => p.classList.remove('open'));
        document.querySelectorAll('.dd-trigger.open').forEach(t => t.classList.remove('open'));
    }
});

document.addEventListener('DOMContentLoaded', _load);
</script>

</main>
</body>
</html>