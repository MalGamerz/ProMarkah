<?php
// ══════════════════════════════════════════════════════════════════
//  attendance_view_all.php — Admin: full student attendance list
//  Shows ALL students with ✔ Hadir / ✖ Tidak Hadir status
// ══════════════════════════════════════════════════════════════════

$active_siri_id = (int)($_SESSION['active_siri_id'] ?? 0);
$siri_filter    = $active_siri_id > 0 ? "AND s.siri_id = $active_siri_id" : '';

$result = $conn->query("
    SELECT DISTINCT
        st.student_id,
        st.student_name,
        st.year,
        sc.school_name,
        (SELECT a.status FROM attendance a
         JOIN sessions s2 ON a.session_id = s2.session_id
         WHERE a.student_id = st.student_id AND a.status = 'Present'
         LIMIT 1) AS attend_status
    FROM students st
    JOIN schools sc ON st.school_id = sc.school_id
    JOIN session_schools ss ON sc.school_id = ss.school_id
    JOIN sessions s ON ss.session_id = s.session_id
    WHERE 1=1 $siri_filter
    ORDER BY sc.school_name ASC, st.student_name ASC
");
?>

<h2 class="pm-page-heading">Senarai Penuh Kehadiran Pesilat</h2>

<div class="pm-card">
    <div class="flex flex-wrap gap-3 mb-5">
        <a href="attendance.php" class="pm-btn pm-btn-ghost">← Kembali</a>
        <a href="export_attendance_pdf.php" target="_blank" class="pm-btn pm-btn-danger">📄 PDF</a>
        <a href="export_attendance_excel.php" class="pm-btn pm-btn-success">📊 Excel</a>
    </div>

    <?php if ($result && $result->num_rows > 0): ?>
    <div class="pm-table-wrap">
        <table class="pm-table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pesilat</th>
                    <th>Cawangan</th>
                    <th>Tahun</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php
            $no = 1;
            while ($row = $result->fetch_assoc()):
                $is_present = ($row['attend_status'] === 'Present');
            ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($row['student_name']) ?></td>
                    <td><?= htmlspecialchars($row['school_name']) ?></td>
                    <td><?= htmlspecialchars($row['year'] ?? 'Tiada') ?></td>
                    <td>
                        <?php if ($is_present): ?>
                            <span style="color:#4ADE80;font-weight:600;">✔ Hadir</span>
                        <?php else: ?>
                            <span style="color:#F87171;font-weight:600;">✖ Tidak Hadir</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
    <?php else: ?>
        <div class="pm-empty-state">
            <p>Tiada pesilat direkodkan dalam sistem untuk sidang ini.</p>
        </div>
    <?php endif; ?>
</div>